from pathlib import Path
import json,tarfile,hashlib,shutil
r=Path('/private/tmp/blanc-journal-validation');e=Path('/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike');dest=e/'evidence/ui138-journal-validation-20261019';dest.mkdir(exist_ok=True)
names=['truncated','unknown-version','missing-identity','wrong-identity-type','invalid-active','unsafe-url','invalid-group','valid']
checks={n:json.loads((r/(n+'.json')).read_text())['pass'] for n in names};assert all(checks.values());assert not (r/'chromium-profile').exists()
summary={'checks':checks,'runtime':'normal Chromium157 binary, encrypted sessions with mock keychain','compilation':False,'guard_actions':0,'guard_seconds':4.81,'footprint':{'files':49,'hunks':114,'basis':'prior measured; no product or upstream source changes'},'limitations':['synthetic journal records, not actual disk corruption or power loss','only authored two-window cases, not arbitrary serialization or overlapping restore','native input pending; latency deferred; Electron diagnostic build unapproved'],'initial_failures':'Two seeding attempts could not use CDP because shell Node20 has no global WebSocket; preserved results. Final run uses bundled Node24.19.0.'}
(r/'results.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile('/private/tmp/blanc-cdp.mjs',r/'blanc-cdp.mjs')
text='''## Malformed Spaces recovery journals — 2026-10-19

Eight bounded native checks pass on the normal f45e4107 binary. Synthetic truncated JSON, unsupported version, missing window identity, non-string identity, out-of-range active tab, unsafe file URL and invalid group index are refused with an error. Each retains the exact journal bytes, preserves both source and decoy UUIDs/URLs and the saved store, and refuses a save while recovery is unresolved. A valid v2 control recovers the source and clears its journal while preserving the decoy and store.

The encrypted-session disposable profile uses the mock keychain and cleanly persisted two-window state. Restarts explicitly use the diagnostic crash-bubble bypass only in this test profile; no native recovery-button acceptance is claimed. Invalid journals are replaced only while the test browser is stopped. These are authored serialization negatives, not physical disk corruption, power loss, or exhaustive parser/lifecycle qualification.

Two initial seed attempts failed in the harness: the shell selected Node20 without global WebSocket, and the helper caught that error as host-not-ready. Both failures are preserved. The complete matrix uses bundled Node24.19.0. No product changes or native compilation; final check-only guard schedules zero actions (4.81s). Prior measured footprint49files/114hunks is unchanged within49/120, not re-enumerated. Owned profile/server removed; retained preview untouched and host unavailable, so original tabs not reverified.

Remaining: actual OS provider faults, hot profile deletion, arbitrary overlapping restore/writers, unsaved state and power-loss qualification; full Spaces acceptance remains open. Native input pending, latency deferred, Electron diagnostic build unapproved/unstarted. Evidence: `evidence/ui138-journal-validation-20261019/`.
'''
(r/'checkpoint.md').write_text(text)
files=[p for p in sorted(r.iterdir()) if p.is_file() and p.suffix in ['.json','.jsonl','.mjs','.cjs','.py','.log','.txt']]
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
with tarfile.open(dest/'evidence.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=p.name)
with tarfile.open(dest/'evidence.tar.gz') as t:
 for m in manifest:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in ['results.json','invocations.jsonl']:shutil.copyfile(r/n,dest/n)
text+=f'\n{len(files)} archived members verified against SHA-256. No new unit-test count claimed.\n';(dest/'README.md').write_text(text)
for n in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=e/n;p.write_text(p.read_text()+'\n'+text)
print(len(files))
