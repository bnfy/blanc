from pathlib import Path
import tarfile,gzip,io,json,hashlib,shutil,subprocess
repo=Path('/private/tmp/blanc-chromium157-work');r=repo/'experiments/chromium-extension-spike';e=r/'evidence/f12-delivery-order-20261018';b=Path('/private/tmp/blanc-all-delivery-build');rows=[]
def tree(root,prefix):return [(p,prefix+'/'+str(p.relative_to(root))) for p in root.rglob('*') if p.is_file()]
def archive(name,items):
 members=[]
 with (e/name).open('wb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
   with tarfile.open(fileobj=gz,mode='w') as t:
    for p,arc in sorted(items,key=lambda x:x[1]):
     assert not p.is_symlink();d=p.read_bytes();assert b'-----BEGIN PRIVATE KEY-----\n' not in d;info=tarfile.TarInfo(arc);info.size=len(d);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(d));members.append({'path':arc,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
 rows.append({'file':name,'bytes':(e/name).stat().st_size,'sha256':hashlib.sha256((e/name).read_bytes()).hexdigest(),'members':members})
binaries=json.loads(Path('/private/tmp/blanc-static-integration-build/binary-hashes.json').read_text())
for x in binaries:
 x['sha256']=hashlib.sha256(Path(x['path']).read_bytes()).hexdigest();x['bytes']=Path(x['path']).stat().st_size
(b/'binary-hashes.json').write_text(json.dumps({'nativeBuild':True,'files':binaries},indent=2)+'\n')
# Earlier failed/exploratory source variants remain byte-identifiable.
variants={'order01':'ordering01-source.mjs','order02':'ordering02-source.mjs','order03':'ordering03-source.mjs'}
for run,source in variants.items():
 report=json.loads((Path('/private/tmp/blanc-all-delivery-'+run)/'report.json').read_text())
 assert hashlib.sha256((b/source).read_bytes()).hexdigest()==report['sources']['delivery-order-run.mjs']
for run in ['order01','order02']:
 report=json.loads((Path('/private/tmp/blanc-all-delivery-'+run)/'report.json').read_text())
 assert hashlib.sha256((b/'ordering02-payload-source.mjs').read_bytes()).hexdigest()==report['sources']['delivery-order-payload.mjs']
runtimes=[]
for name in ['order01','order02','order03','order04','static','policy','integration']:
 root=Path('/private/tmp/blanc-all-delivery-'+name);data=json.loads((root/'report.json').read_text());assert data['cleanup']['removed'];runtimes+=tree(root,name)
for name in ['readiness','unready']:assert json.loads((b/(name+'.json')).read_text())['profileRemoved']
(b/'cleanup.json').write_text(json.dumps({'allRuntimeRootsRemoved':True,'readinessProfilesRemoved':True,'noOwnedRuntimeOrBuildProcess':True,'privateKeysExcluded':True},indent=2)+'\n')
archive('runtime-and-checks.tar.gz',tree(b,'checks')+runtimes+[(Path(__file__),'package.py')])
files=[]
for p in r.rglob('*'):
 rel=p.relative_to(r)
 if p.is_file() and not {'evidence','generated'}.intersection(rel.parts) and (p.suffix in ['.mjs','.cjs','.js','.cc','.h','.inc','.mojom','.py'] or p.name=='BUILD.gn'):files.append((p,str(p.relative_to(repo))))
archive('sources.tar.gz',files)
pin=json.loads((repo/'ublock/pinned.json').read_text());original={x['path']:x['sha256'] for x in pin['files']};items=[(repo/'ublock/pinned.json','pinned.json')];inventory={}
for dirname,alias in [('blanc-all-delivery-payload','earlier-ordinary'),('blanc-all-delivery-diagnostic','earlier-diagnostic'),('blanc-all-delivery-payload02','ordinary'),('blanc-all-delivery-diagnostic02','diagnostic'),('blanc-all-delivery-static-diagnostic','static-diagnostic'),('blanc-codeql-final-unready','unready')]:
 root=Path('/private/tmp')/dirname;inventory[alias]=[]
 for p in root.rglob('*'):
  if not p.is_file():continue
  rel=str(p.relative_to(root));h=hashlib.sha256(p.read_bytes()).hexdigest();changed=h!=original.get(rel);inventory[alias].append({'path':rel,'sha256':h,'changedOrNew':changed})
  if changed or rel=='LICENSE.txt':items.append((p,alias+'/'+rel))
(b/'payload-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n');items.append((b/'payload-inventory.json','payload-inventory.json'));archive('payload-delta.tar.gz',items)
archive('record.tar.gz',[(e/'README.md','README.md')])
for n in ['order-proof.json','static-proof.json','policy-proof.json','integration-proof.json','readiness-proof.json','binary-hashes.json','cleanup.json','invocations.jsonl','patch-budget.json']:shutil.copyfile(b/n,e/n)
(e/'archives.json').write_text(json.dumps(rows,indent=2)+'\n');dest=Path('/private/tmp/blanc-all-delivery-verified');dest.mkdir(exist_ok=True)
for row in rows:
 with tarfile.open(e/row['file']) as t:
  assert t.getnames()==[m['path'] for m in row['members']]
  for m in row['members']:
   data=t.extractfile(m['path']).read();assert hashlib.sha256(data).hexdigest()==m['sha256'];target=dest/m['path'];assert target.is_relative_to(dest);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
src=dest/'experiments/chromium-extension-spike'
for script,run,proof in [('delivery-order-verify.mjs','order04','order-proof.json'),('static-race-verify.mjs','static','static-proof.json'),('static-policy-verify.mjs','policy','policy-proof.json'),('static-integration-verify.mjs','integration','integration-proof.json')]:assert json.loads(subprocess.check_output(['node',str(src/'fixtures/replay/synthetic'/script),str(dest/run)]))==json.loads((e/proof).read_text())
subprocess.check_call(['node',str(src/'ubo-readiness-verify.mjs'),str(dest/'checks/readiness.json'),str(dest/'checks/unready.json')])
summary={'verified':True,'archives':len(rows),'members':sum(len(x['members']) for x in rows),'compressedBytes':sum(x['bytes'] for x in rows),'independentProofs':5};(e/'archive-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
