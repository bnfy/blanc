import os,subprocess,pathlib,sys,shutil
r=pathlib.Path('/private/tmp/blanc-save-lifetime');mode=sys.argv[1]
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),mode+'-'+n,*a],check=True,env=env)
for n in ['arm','release','marker.json','encryptor-arm','encryptor-held']:(r/n).unlink(missing_ok=True)
if mode.startswith('encryptor'):(r/'encryptor-arm').write_text('1');env={**os.environ,'ACK_ENCRYPTED':'1'}
else:(r/'arm').write_text('1');env={**os.environ,'INJECT':'1','SESSION_MODE':'write'}
run('start','node',str(r/'start.mjs'),env=env);run('seed','node',str(r/'check.mjs'),'seed');run('proof','node',str(r/'probe.mjs'),mode);run('cleanup','node',str(r/'cleanup.mjs'));shutil.copyfile(r/'cleanup.json',r/(mode+'-cleanup.json'))
