import fs from 'node:fs';
import assert from 'node:assert/strict';
import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const r='/private/tmp/blanc-save-lifetime', mode=process.argv[2], cs=[], p={mode};
const disk=r+'/chromium-profile/Default/BlancPrototypeSpaces.json';
const wait=async(fn,test)=>{for(let i=0;i<400;i++){const v=await fn().catch(()=>null);if(test(v))return v;await pause(50)}throw Error('timeout')};
const api=(h,m,...a)=>h.eval(`BlancPrototypeHost.api.${m}(...${JSON.stringify(a)})`);
const hosts=async()=>{const ts=await fetch('http://127.0.0.1:9258/json/list').then(x=>x.json());const out=[];for(const t of ts.filter(t=>t.url.includes('host.html'))){const h=await connect(t);cs.push(h);const s=await api(h,'getAllTabs').catch(()=>null);if(s)out.push({h,s,target:t})}return out};
try {
 const seed=JSON.parse(fs.readFileSync(r+'/seed.json'));const hs=await wait(hosts,v=>v?.length===2);
 const source=hs.find(v=>v.s.spaceWindowIdentity===seed.source.spaceWindowIdentity),decoy=hs.find(v=>v.s.spaceWindowIdentity===seed.decoy.spaceWindowIdentity);assert(source&&decoy);
 await api(source.h,'previewSpaceSave','A');
 await source.h.eval("globalThis.ackOutcome='pending';BlancPrototypeHost.api.previewSpaceOpen('B').then(()=>ackOutcome='success',e=>ackOutcome=String(e));true");
 await pause(700);assert.equal(await source.h.eval('ackOutcome'),'pending');assert(!fs.existsSync(disk+'.switch'));
 p.before=await api(source.h,'getAllTabs');assert.deepEqual(p.before.tabs.map(t=>t.url),seed.source.tabs.map(t=>t.url));
 if(mode.startsWith('encryptor')) {p.queued=Number(fs.readFileSync(r+'/encryptor-held','utf8'));assert(p.queued>=2);assert(!fs.existsSync(r+'/chromium-profile/Default/Sessions_Encrypted')||!fs.readdirSync(r+'/chromium-profile/Default/Sessions_Encrypted').some(n=>n.startsWith('Session_')));
 } else {p.marker=JSON.parse(fs.readFileSync(r+'/marker.json'));assert.equal(p.marker.pid,Number(fs.readFileSync(r+'/chromium.pid')));assert.equal(fs.statSync(p.marker.path).size,0);}
 const release=()=>{if(mode.startsWith('encryptor'))fs.unlinkSync(r+'/encryptor-arm');else fs.writeFileSync(r+'/release','1')};
 if(mode.endsWith('owner')) {
  const b=await connect(await fetch('http://127.0.0.1:9258/json/version').then(x=>x.json()));cs.push(b);
  const ts=await fetch('http://127.0.0.1:9258/json/list').then(x=>x.json());
  const st=ts.find(t=>t.url.endsWith('/source'));assert(st);const w=await b.send('Browser.getWindowForTarget',{targetId:st.id});p.closedWindow=w.windowId;
  for(const t of ts.filter(t=>t.type==='page'&&!t.url.includes('host.html'))){const tw=await b.send('Browser.getWindowForTarget',{targetId:t.id}).catch(()=>null);if(tw?.windowId===w.windowId)await b.send('Target.closeTarget',{targetId:t.id});}
  await wait(hosts,v=>v?.length===1&&v[0].s.spaceWindowIdentity===seed.decoy.spaceWindowIdentity);
  p.ownerDestroyed=true;await pause(300);p.storeAfterClose=JSON.parse(fs.readFileSync(disk));assert.deepEqual(p.storeAfterClose.items.B,seed.store.items.B);release();await pause(8500);
  const remaining=await wait(hosts,v=>v?.length===1);p.after=remaining[0].s;assert.deepEqual(p.after.tabs.map(t=>t.url),seed.decoy.tabs.map(t=>t.url));assert.equal(p.after.spaceWindowIdentity,seed.decoy.spaceWindowIdentity);assert(!fs.existsSync(disk+'.switch'));assert.deepEqual(JSON.parse(fs.readFileSync(disk)),p.storeAfterClose);
  await api(remaining[0].h,'previewSpaceSave','C');await api(remaining[0].h,'previewSpaceOpen','B');p.otherOwnerRetry=await wait(()=>api(remaining[0].h,'getAllTabs'),s=>s?.spaceName==='B'&&s.tabs.length===2&&!s.tabs.some(t=>t.isLoading)&&!fs.existsSync(disk+'.switch'));
 } else {
  if(mode.endsWith('timeout')) {p.timeout=await wait(()=>source.h.eval('ackOutcome'),v=>v?.includes('Session metadata save acknowledgement timed out'));release();await pause(1000);assert.deepEqual((await api(source.h,'getAllTabs')).tabs.map(t=>t.url),seed.source.tabs.map(t=>t.url));assert(!fs.existsSync(disk+'.switch'));p.staleIgnored=true;await api(source.h,'previewSpaceSave','A');await api(source.h,'previewSpaceOpen','B');}
  else {release();await wait(()=>source.h.eval('ackOutcome'),v=>v==='success');}
  p.after=await wait(()=>api(source.h,'getAllTabs'),s=>s?.spaceName==='B'&&s.tabs.length===2&&!s.tabs.some(t=>t.isLoading)&&!fs.existsSync(disk+'.switch'));
 }
 p.pass=true;
} catch(e){p.pass=false;p.error=String(e);p.stack=e.stack;fs.writeFileSync(r+'/release','1');fs.rmSync(r+'/encryptor-arm',{force:true});}
finally{cs.forEach(c=>c.close());fs.writeFileSync(r+'/'+mode+'.json',JSON.stringify(p,null,2));console.log({mode,pass:p.pass,error:p.error})}
if(!p.pass)process.exitCode=1;
