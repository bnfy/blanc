from pathlib import Path
import sys,hashlib,json
r=Path('/private/tmp/blanc-save-lifetime');p=Path('/Users/anthonyjloria/Projects/BlancChromium157/src/components/sessions/core/command_storage_manager.cc');before=r/'manager.before.cc'
if sys.argv[1]=='apply':
 s=p.read_text();before.write_text(s)
 anchor='  CHECK(ShouldWriteEncryptedFiles());\n  CHECK(encrypted_backend_ == nullptr);'
 patch='''  // Temporary diagnostic: only the owned disposable profile, never production.
  if (session_type_ == SessionType::kSessionRestore &&
      file_path_.value() == "/private/tmp/blanc-save-lifetime/chromium-profile/Default" &&
      base::PathExists(base::FilePath("/private/tmp/blanc-save-lifetime/encryptor-arm"))) {
    base::WriteFile(base::FilePath("/private/tmp/blanc-save-lifetime/encryptor-held"),
                    std::to_string(pending_encrypted_ops_.size()));
    base::SequencedTaskRunner::GetCurrentDefault()->PostDelayedTask(
        FROM_HERE, base::BindOnce(&CommandStorageManager::OnEncryptorReady,
            weak_factory_.GetWeakPtr(), start_time, std::move(encryptor)),
        base::Milliseconds(100));
    return;
  }
'''+anchor
 assert s.count(anchor)==1;p.write_text(s.replace(anchor,patch));(r/'diagnostic-snippet.txt').write_text(patch)
else:
 p.write_bytes(before.read_bytes());assert p.read_bytes()==before.read_bytes();(r/'source-restored.json').write_text(json.dumps({'equal':True,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
