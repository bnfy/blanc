from pathlib import Path
import hashlib,json,tarfile,subprocess
r=Path('/private/tmp/blanc-live-closed');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-live-closed-20261019'
for n in ['group-seed','group-window','interrupt-rotation','startup-rotation','restart-rotation','startup','restart']:assert json.loads((r/(n+'.json')).read_text())['pass'],n
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved'];assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-anchor-fix/binary-hashes.json').read_text())
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps({'pass':True,'fatalOrDangling':errors}));(r/'guard.log').write_bytes(Path('/private/tmp/blanc-anchor-fix/live-closed-guard.log').read_bytes());(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());(r/'scope.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productionChanges':False,'interruptedSyscall':'not proven; fs.watch notification can arrive after completed write','nativeInput':'pending unlock','latency':'deferred','electronDiagnosticBuild':'unapproved'},indent=2))
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 live persistence crash and group/window restoration

Two-tab named group closes into one entry and reopens with both URLs, group name and membership
preserved. Moving that group into its own window, orderly browser shutdown, normal launch and
Recently Closed window restoration also preserves both URLs and group membership. Native bridge
calls only; no physical menu/button acceptance or arbitrary group/window combinations claimed.

One live run SIGKILLs the exact owned browser PID when fs.watch reports Tabs_* creation/rotation
during repeated tab closure. A second content-change-only attempt observes no qualifying event
after40 closures and its bounded wait; it does not kill the browser and is not an interruption pass. The event,
file size, acknowledged-close count and PID/command are recorded. No offline mutation is used.
Notifications can arrive after a completed write: this is live persistence-adjacent crash recovery,
NOT proof of an interrupted write syscall or a torn record. The actual mid-write/power-loss gate
remains open; prior offline truncation simulations remain separate.

| Trigger | Acknowledged closes at event | Live-close entries exposed after recovery |
| --- | --- | --- |
'''
for suffix in ['-rotation']:
 x=json.loads((r/('interrupt'+suffix+'.json')).read_text());y=json.loads((r/('startup'+suffix+'.json')).read_text());text+=f"| {x['event']['event']} | {x['event']['closedAcknowledged']} | {sum('/live-close-' in z['url'] for z in y['before'])} |\n"
text+='''
The crashed browser and the non-triggering second run remain usable; new closed entries survive a subsequent clean restart
and reopen at the expected URL. No fatal/dangling diagnostics. These counts are exposed entries,
not proof of durable completion of every issued write. No general storage-integrity claim.

No production change/compile; guard zero3.74s and unchanged native hashes.40files/97hunks not
re-enumerated. Disposables removed, original preview preserved. Native input pending unlock,
latency deferred, Electron diagnostic build unapproved. Larger/mixed/private groups, group color
and collapsed-state parity, disk-full/permissions, true syscall interruption and OS restart remain
gaps. Plan item4 and earlier F12/Task0 gates remain open; cold-build column unchanged.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed members; profiles/raw browser logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-live-closed-20261019/`.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-live-closed-20261019/`.\n'+s[i:]);print(len(m),'hashed members')
