from pathlib import Path
import subprocess,json,time,struct,hashlib
r=Path('/private/tmp/blanc-group-legacy')
def run(n,*a):
 t=time.time();p=subprocess.run(['node','--experimental-websocket',str(r/n),*a],capture_output=True,text=True)
 with (r/'invocations.jsonl').open('a') as f:f.write(json.dumps(dict(script=n,args=a,seconds=time.time()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 print(n,p.returncode,p.stdout,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
if (r/'chromium.pid').exists():run('cleanup.mjs')
run('start.mjs');run('check.mjs','cross','true')
for _ in range(100):
 ps=subprocess.check_output(['ps','-axo','command='],text=True)
 if '--user-data-dir='+str(r)+'/chromium-profile' not in ps:break
 time.sleep(.2)
else:raise RuntimeError('browser still active')
proof=[];changed=0
for p in (r/'chromium-profile/Default/Sessions').glob('Tabs_*'):
 data=p.read_bytes();out=bytearray(data[:8]);i=8;records=[]
 while i<len(data):
  size=struct.unpack_from('<H',data,i)[0];payload=data[i+2:i+2+size];assert len(payload)==size;i+=2+size
  if payload[0]==13:
   assert payload[-4:] in [b'\x00'*4,b'\x01\x00\x00\x00'];records.append(dict(id=13,oldSize=size,flag=payload[-4:].hex()));payload=payload[:-4];old_pickle_size=struct.unpack_from("<I",payload,1)[0];payload=payload[:1]+struct.pack("<I",old_pickle_size-4)+payload[5:];changed+=1
  out+=struct.pack('<H',len(payload))+payload
 p.write_bytes(out);proof.append(dict(file=p.name,before=hashlib.sha256(data).hexdigest(),after=hashlib.sha256(out).hexdigest(),records=records))
assert changed>0
removed=[]
for p in (r/'chromium-profile/Default/Sessions_Encrypted').glob('Tabs_*'):removed.append(dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));p.unlink()
(r/'legacy-mutation.json').write_text(json.dumps(dict(files=proof,changed=changed,removedEncryptedCounterparts=removed,scope='synthetic legacy-shaped plaintext records; no legacy binary'),indent=2))
run('normal-relaunch.mjs');run('check.mjs','closed-crash','true');run('cleanup.mjs')
