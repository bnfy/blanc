from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-group-legacy');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-group-legacy-private-20261019'
x=json.loads((r/'closed-crash-true.json').read_text());assert x['pass'] and x['collapsedMatches']==False
assert json.loads((r/'private.json').read_text())['pass'];assert json.loads((r/'cleanup.json').read_text())['profilesRemoved']
assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-group-persist-fix/binary-hashes.json').read_text())
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps(dict(errors=errors)))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 legacy-record and private-group checks

A disposable regular profile first closes a collapsed blue two-tab group on the current
binary. With the browser stopped, the test removes the appended four-byte boolean from
kCommandCreateGroup(13), adjusting both outer command size and embedded Pickle length.
Only owned disposable encrypted Tabs counterparts are removed to force the plaintext fixture
path. The current binary reloads the legacy-shaped entry and restores both URLs, membership,
name and color, defaulting to expanded as required for an absent collapse bit. A false
collapsedMatches field records that intentional legacy fallback; expected expanded is asserted.
This is a synthetic old-format record test, NOT an older-binary or encrypted legacy migration
acceptance claim. Original and mutated file hashes/length metadata are retained, not profiles.
The first attempt omitted the Pickle length adjustment and was refused; that timeout and
malformed mutation record remain archived rather than being counted as compatibility evidence.

A fresh disposable profile verifies private groups have no Recently Closed history. Closing a
collapsed two-tab private group leaves a usable private window and no closed entry. Reopen-most-
recent returns false; a known regular group entry ID cannot be restored or forgotten through
the private bridge, and private clear returns false. The regular history stays identical before
and after those calls and private-context disposal; restoring its regular group still returns
both URLs. No private tabs appear in the regular window. Expected refusal is the private-mode
contract, not missing restoration functionality. No native mouse/keyboard checks performed.

No production changes/compile; guard0/5.24s, native binary hashes unchanged,41files/100hunks
(not re-enumerated). Test profile/server removed, original preview tabs/status preserved.
Native input pending, latency deferred, Electron diagnostic build unapproved/unstarted.
Older-binary/new-record rollback, encrypted legacy fixtures, malformed optional-field matrix,
multiple private contexts, private crash/restart leakage and wider lifecycle remain gaps.
EarlierF12/Task0 and visualitem4 gates remain open; routine testing only, cold column unchanged.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed archive members, all verified.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-group-legacy-private-20261019/`.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-group-legacy-private-20261019/`.\n'+s[i:]);print(len(m),'verified members')
