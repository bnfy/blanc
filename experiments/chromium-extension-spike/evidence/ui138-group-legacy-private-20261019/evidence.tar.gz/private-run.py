from pathlib import Path
import subprocess,json,time,struct,hashlib
r=Path('/private/tmp/blanc-group-legacy')
def run(n,*a):
 t=time.time();p=subprocess.run(['node','--experimental-websocket',str(r/n),*a],capture_output=True,text=True)
 with (r/'invocations.jsonl').open('a') as f:f.write(json.dumps(dict(script=n,args=a,seconds=time.time()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 print(n,p.returncode,p.stdout,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('start.mjs');run('private.mjs');run('cleanup.mjs')
