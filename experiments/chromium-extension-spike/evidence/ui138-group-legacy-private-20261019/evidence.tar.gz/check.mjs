import fs from 'node:fs';import assert from 'node:assert/strict';import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const r='/private/tmp/blanc-group-legacy', phase=process.argv[2], collapsed=process.argv[3]==='true', color=collapsed?'#376694':'#9b4761', clients=[], proof={phase,collapsed,color};
const urls=['http://127.0.0.1:9265/group-a','http://127.0.0.1:9265/group-b'];
const api=(h,m,...a)=>h.eval(`BlancPrototypeHost.api.${m}(...${JSON.stringify(a)})`);
const wait=async(fn,test)=>{for(let i=0;i<200;i++){let x=await fn().catch(()=>null);if(test(x))return x;await pause(100);}throw Error('timeout')};
const attach=async t=>{const c=await connect(t);clients.push(c);return c};
const list=()=>fetch('http://127.0.0.1:9258/json/list').then(x=>x.json());
async function hosts(){const out=[];for(const t of (await list()).filter(t=>t.url.includes('host.html'))){const h=await attach(t);await wait(()=>h.eval('typeof BlancPrototypeHost!=="undefined"'),Boolean);out.push({id:t.id,h,s:await api(h,'getAllTabs')});}return out;}
async function verify(){await pause(1200);const hs=await hosts();proof.after=hs.map(({id,s})=>({id,s}));const hit=hs.filter(x=>urls.every(u=>x.s.tabs.some(t=>t.url===u)));assert.equal(hit.length,1);const x=hit[0],g=x.s.groups.find(g=>g.id===x.s.tabs.find(t=>t.url===urls[0]).groupId);assert(g);assert.equal(g.name,'Recovery pair');proof.collapsedMatches=g.collapsed===collapsed;assert.equal(g.collapsed,phase==='closed-crash'?false:collapsed);assert.equal(g.color,color);assert(urls.every(u=>x.s.tabs.find(t=>t.url===u).groupId===g.id));proof.actualOwner=x.id;return {x,g};}
try{
 const b=await attach(await wait(()=>fetch('http://127.0.0.1:9258/json/version').then(x=>x.json()),Boolean));await wait(list,x=>x?.some(t=>t.url.includes('host.html')));let hs=await hosts();const a=hs[0];await pause(1500);
 if(phase==='cross'){
  await api(a.h,'clearClosedEntries');for(const url of urls){await b.send('Target.createTarget',{url});let s=await wait(()=>api(a.h,'getAllTabs'),x=>x?.tabs.some(t=>t.url===url));await api(a.h,'groupTabByName',s.tabs.find(t=>t.url===url).id,'Recovery pair');}
  let s=await api(a.h,'getAllTabs'),g=s.groups.find(g=>g.name==='Recovery pair');await api(a.h,'setGroupColor',g.id,color);if(g.collapsed!==collapsed)await api(a.h,'toggleGroupCollapsed',g.id);proof.before=await api(a.h,'getAllTabs');
  await b.send('Target.createTarget',{url:'http://127.0.0.1:9265/decoy',newWindow:true});await pause(1200);hs=await hosts();const dest=hs.find(x=>x.id!==a.id&&x.s.tabs.some(t=>t.url.endsWith('/decoy')));assert(dest);await api(dest.h,'groupTabByName',dest.s.tabs.find(t=>t.url.endsWith('/decoy')).id,'Recovery pair');proof.decoyBefore=await api(dest.h,'getAllTabs');
  await api(a.h,'closeGroup',g.id);s=await wait(()=>api(dest.h,'getAllTabs'),x=>x?.closed.some(e=>e.title==='Recovery pair'&&e.tabCount===2));const entry=s.closed.find(e=>e.title==='Recovery pair'&&e.tabCount===2);proof.caller=dest.id;proof.source=a.id;proof.restoreResult=await api(dest.h,'reopenClosedEntry',entry.id);assert(proof.restoreResult);const restored=await verify();const afterDecoy=(await hosts()).find(x=>x.id===dest.id);const dg=afterDecoy.s.groups.find(g=>g.id===proof.decoyBefore.groups[0].id);assert.deepEqual(dg,proof.decoyBefore.groups[0]);proof.decoyAfter=dg;
  await api(restored.x.h,'closeGroup',restored.g.id);await pause(6000);proof.closedBeforeCrash=(await api(restored.x.h,'getAllTabs')).closed;await b.send('Browser.close');
 }else if(phase==='closed-crash'){
  const s=await wait(()=>api(a.h,'getAllTabs'),x=>x?.closed.some(e=>e.title==='Recovery pair'&&e.tabCount===2));proof.closed=s.closed;assert(await api(a.h,'reopenClosedEntry',s.closed.find(e=>e.title==='Recovery pair'&&e.tabCount===2).id));await verify();await b.send('Browser.close');
 }else{
  const s=await wait(()=>api(a.h,'getAllTabs'),x=>x?.closed.some(e=>e.title==='Window'&&e.tabCount===2));proof.closed=s.closed;assert(await api(a.h,'reopenClosedEntry',s.closed.find(e=>e.title==='Window'&&e.tabCount===2).id));await verify();await b.send('Browser.close');
 }
 proof.completed=true;proof.pass=true;proof.outcome=proof.pass?'pass':'collapsed-state-difference';
}catch(e){proof.pass=false;proof.error=String(e);}finally{clients.forEach(c=>c.close());fs.writeFileSync(`${r}/${phase}-${collapsed}.json`,JSON.stringify(proof,null,2));console.log({phase,collapsed,pass:proof.pass,error:proof.error});}if(!proof.completed)process.exitCode=1;
