import os,subprocess,pathlib,json
r=pathlib.Path('/private/tmp/blanc-save-ack')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
for n in ['arm','release','marker.json']:(r/n).unlink(missing_ok=True)
run('late-start','node',str(r/'start.mjs'));run('late-seed','node',str(r/'check.mjs'),'seed');run('late-stop','node',str(r/'stop.mjs'))
seed=json.loads((r/'seed.json').read_text());store=seed['store'];(r/'chromium-profile/Default/BlancPrototypeSpaces.json.switch').write_text(json.dumps(dict(version=2,id='late-ack-regression',source_name='A',source_window=seed['source']['spaceWindowIdentity'],source=store['items']['A'],destination=store['items']['B'])))
(r/'arm').write_text('1');run('late-restart','node',str(r/'launch-injected.mjs'),env={**os.environ,'RESTORE':'1','SESSION_MODE':'read'});run('late-proof','node',str(r/'probe.mjs'),'read');run('late-cleanup','node',str(r/'cleanup.mjs'))
