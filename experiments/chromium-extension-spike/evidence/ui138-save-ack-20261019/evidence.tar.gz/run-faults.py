import os,subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-save-ack')
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True)
for mode in ['write-eio','flush-eio']:
 for n in ['arm','release','marker.json','error.json']:(r/n).unlink(missing_ok=True)
 run(mode+'-start','node',str(r/'start-fault.mjs'));run(mode+'-seed','node',str(r/'check.mjs'),'seed');run(mode+'-check','node',str(r/'fault-check.mjs'),mode);run(mode+'-cleanup','node',str(r/'cleanup.mjs'))
