import os,subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-save-ack')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
for n in ['arm','release','marker.json']:(r/n).unlink(missing_ok=True)
(r/'arm').write_text('1');run('held-start','node',str(r/'start.mjs'),env={**os.environ,'INJECT':'1','SESSION_MODE':'write'});run('held-seed','node',str(r/'check.mjs'),'seed');run('held-proof','node',str(r/'probe.mjs'),'write');run('held-cleanup','node',str(r/'cleanup.mjs'))
