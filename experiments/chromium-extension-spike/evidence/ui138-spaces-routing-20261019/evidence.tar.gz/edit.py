from pathlib import Path
p=Path('experiments/chromium-extension-spike/native/blanc_prototype_ui.cc')
s=p.read_text().replace('#include "base/files/file_util.h"','#include "base/files/file_util.h"\n#include "base/files/important_file_writer.h"\n#include "base/json/json_reader.h"\n#include "base/json/json_writer.h"\n#include "base/task/sequenced_task_runner.h"')
s=s.replace('  bool vertical = false;','''  int glance_main = -1;
  int glance_reference = -1;
  // Session IDs never outlive their tabs; validate the native split each read.
  int MainIndex() {
    auto* model = browser->GetTabStripModel();
    int main = -1, reference = -1;
    for (int i = 0; i < model->count(); ++i) {
      const int id = sessions::SessionTabHelper::IdForTab(model->GetWebContentsAt(i)).id();
      if (id == glance_main) main = i;
      if (id == glance_reference) reference = i;
    }
    if (main < 0 || reference < 0 || !model->GetSplitForTab(main) ||
        model->GetSplitForTab(main) != model->GetSplitForTab(reference)) {
      glance_main = glance_reference = -1;
      return model->active_index();
    }
    return model->active_index() == main || model->active_index() == reference
        ? main : model->active_index();
  }
  bool vertical = false;''')
s=s.replace('  auto* active = model->GetActiveWebContents();\n  base::Value active_id', '''  const int main_index = owner->MainIndex();
  auto* active = main_index >= 0 ? model->GetWebContentsAt(main_index) : nullptr;
  auto* focused = model->GetActiveWebContents();
  base::Value active_id''')
s=s.replace('.Set("glanceTabId", base::Value())', '''.Set("glanceTabId", owner->glance_reference >= 0 ? base::Value(owner->glance_reference) : base::Value())
      .Set("focusedTabId", focused ? base::Value(sessions::SessionTabHelper::IdForTab(focused).id()) : base::Value())''')
s=s.replace('      if (reverse) model->ReverseTabsInSplit(split);','''      if (reverse) model->ReverseTabsInSplit(split);
      owner->glance_main = args[0].GetInt();
      owner->glance_reference = args[1].GetInt();''')
p.write_text(s)
p=Path('experiments/chromium-extension-spike/prototype/host.js');s=p.read_text().replace('      const items = strip.contentWindow?', '''      for (const key of ['focusedTabId', 'glanceTabId']) {
        if (snapshot[key] != null) snapshot[key] = String(snapshot[key]);
      }
      const items = strip.contentWindow?''').replace('    findTabId = snapshot.activeTabId;', '    findTabId = snapshot.focusedTabId ?? snapshot.activeTabId;')
s=s.replace("    listWorkspaces: async () => ({ items: [], tint: 'mark' }),",'''    previewSpaceSave: name => request('previewSpaceSave', [name]),
    previewSpaceList: () => request('previewSpaceList'),
    previewSpaceOpen: name => request('previewSpaceOpen', [name]),
    listWorkspaces: async () => ({ items: [], tint: 'mark' }),''')
# Explicit tab-row actions retain their ID. Island page commands address main and route to focus.
s=s.replace('      await request(method, [nativeId(id)]);', '''      const pageCommand = ['goBack', 'goForward', 'reload', 'stop'].includes(method);
      const routed = pageCommand && String(id) === snapshot?.activeTabId
        ? snapshot.focusedTabId ?? id : id;
      await request(method, [nativeId(routed)]);''')
p.write_text(s)
