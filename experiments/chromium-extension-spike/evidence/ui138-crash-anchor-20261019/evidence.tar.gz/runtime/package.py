from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-anchor-runtime');b=Path('/private/tmp/blanc-anchor-fix');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-crash-anchor-20261019'
for name in ['seed','clean-restored','entry-restored','bubble','final-log-check']:
 assert json.loads((r/(name+'.json')).read_text())['pass'],name
assert json.loads((r/'preview.json').read_text())['status']==''
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved']
(r/'source.patch').write_text(subprocess.check_output(['git','diff','--','experiments/chromium-extension-spike/native','experiments/chromium-extension-spike/prepare.mjs'],cwd=w,text=True))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
(r/'attempt1/lifetime-diagnostic.txt').write_text((r/'attempt1/chromium.log').read_text().split('[DanglingSignature]')[1].split('Please check')[0])
(r/'outcome.json').write_text(json.dumps({'anchorCrashFixed':True,'normalRestore':True,'recoveryBubbleShownHistogram':True,'crashBubbleButton':'not run: Mac locked','postCrashRecentlyClosedPasswordSearch':True,'privateExcluded':True,'latency':'deferred','electronDiagnosticBuild':'unapproved/unstarted','attempt1':'shutdown dangling toolbar pointer; repaired with ViewObserver','harnessFailures':['premature CDP read','host API not ready','incorrect expectation of automatic restore after crash','entry helper top-level await syntax corrected before invocation']},indent=2))
e.mkdir(parents=True,exist_ok=True)
files={}
for p in r.rglob('*'):
 if p.is_file() and (p.suffix in ['.mjs','.cjs','.py','.json','.pdf','.patch','.txt']) and 'profile' not in p.parts:files['runtime/'+str(p.relative_to(r))]=p
for p in b.iterdir():
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.py']:files['build/'+p.name]=p
m={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 crash-recovery anchor repair

The existing BrowserView toolbar-provider integration now delegates through a Blanc-owned
adapter. App-menu bubbles receive the Island View anchor; other toolbar/menu operations
forward to Chromium. The recovery bubble is preserved, not suppressed. No new upstream
file: inventory is 40 files / 97 hunks (one additional BrowserView hunk; below 120).
The first implementation compiled but exposed a shutdown dangling toolbar pointer because
ToolbarView dies before the Island owner. A ViewObserver now clears that pointer at deletion.
The failed attempt and diagnostic are retained; final normal shutdown has no fatal/dangling report.

Two guarded incremental builds: 62.76 seconds (15 executed steps), then 38.61 seconds
(six steps) for the lifetime repair. Final guard: zero actions in 4.06 seconds. No cold
output, toolchain, GN-argument or latency changes. The inventory was measured before the
Blanc-owned lifetime repair, which adds no upstream file/hunk; final source patch is archived.

Actual normal same-profile session restoration passes: regular protected PDF restored without
manual navigation, empty password re-prompt, no observed positive pre-unlock result, two matches
after re-entry, private PDF excluded. The owned browser was then SIGKILLed and relaunched.
It survives, and Session.SessionCrashed.Bubble records SHOWN=1, ERROR=0. The harness initially
expected automatic crash restoration; that assertion correctly failed because the real recovery
bubble waits for user choice. Mac locked, so its native Restore button and visual placement
remain NOT RUN. No automatic crash-restore/password pass is claimed.

Separately, the existing Recently Closed bridge restores the saved window after the crash:
regular PDF password field is empty, re-entry yields two matches, private URL absent. This
is saved-entry restoration, not acceptance of the recovery bubble button. Harness readiness
failures and the corrected asynchronous helper are recorded in outcome.json. Disposable profile
and server removed; original preview New Tab/Web Store tabs restored on final binary with empty
status. Native input pending unlock; latency deferred; Electron diagnostic build unapproved.
Broader recovery/UI/accessibility and prior F12/Task0 gates remain open. Plan item4 incomplete.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed archive members; profiles/raw browser logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-crash-anchor-20261019/`. Routine incremental cost only; Task0 cold column unchanged.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-crash-anchor-20261019/`.\n'+s[i:])
print(len(m),'hashed members')
