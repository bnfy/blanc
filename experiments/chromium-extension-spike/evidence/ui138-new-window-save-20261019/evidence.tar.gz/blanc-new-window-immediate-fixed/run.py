import os,subprocess,pathlib,json
r=pathlib.Path('/private/tmp/blanc-new-window-immediate-fixed');env={**os.environ,'PATH':'/Users/anthonyjloria/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
def run(n,*a,extra={}):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env={**env,**extra})
try:
 run('helper-build','clang','-dynamiclib',str(r/'barrier.c'),'-o',str(r/'barrier.dylib'))
 run('start','node',str(r/'start.mjs'));run('seed','node',str(r/'check.mjs'),'seed');run('close','node',str(r/'close.mjs'))
 seed=json.loads((r/'seed.json').read_text());store=seed['store'];p=r/'chromium-profile/Default/BlancPrototypeSpaces.json.switch';p.write_text(json.dumps(dict(version=2,id='overlap-restore',source_name='A',source_window=seed['source']['spaceWindowIdentity'],source=store['items']['A'],destination=store['items']['B'])))
 (r/'arm').write_text('1');run('held-restart','node',str(r/'launch-injected.mjs'),extra={'RESTORE':'1','SESSION_MODE':'read'});run('overlap-proof','node',str(r/'probe.mjs'),'read')
 run('state-proof','node',str(r/'state.mjs'))
finally:
 (r/'release').write_text('1');run('cleanup','node',str(r/'cleanup.mjs'))
