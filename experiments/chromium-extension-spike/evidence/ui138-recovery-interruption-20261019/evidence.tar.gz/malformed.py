import os,subprocess,pathlib,shutil
r=pathlib.Path('/private/tmp/blanc-window-recovery')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
for mode in ['invalid','uppercase']:
 run(mode+'-start','node',str(r/'start.mjs'));run(mode+'-seed','node',str(r/'check.mjs'),'seed');run(mode+'-stop','node',str(r/'stop.mjs'))
 run(mode+'-mutate','node',str(r/'malformed-mutate.mjs'),env={**os.environ,'MALFORMED_KIND':mode});run(mode+'-launch','node',str(r/'launch.mjs'),env={**os.environ,'RESTORE':'1'});run(mode+'-check','node',str(r/'malformed-check.mjs'))
 for n in ['seed','malformed','duplicate-mutation']:shutil.copyfile(r/(n+'.json'),r/(mode+'-'+n+'.json'))
 run(mode+'-cleanup','node',str(r/'cleanup.mjs'))
