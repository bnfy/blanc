import os,subprocess,pathlib,json,time,shutil
r=pathlib.Path('/private/tmp/blanc-window-recovery')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
for mode in ['stage-first','stage-all','remove-first','remove-all']:
 run(mode+'-start','node',str(r/'start.mjs'));run(mode+'-seed','node',str(r/'check.mjs'),'seed');run(mode+'-stop','node',str(r/'stop.mjs'))
 env={**os.environ,'RESTORE':'1','SPACES_CRASH_MODE':'stage-first'}
 run(mode+'-launch','node',str(r/'launch.mjs'),env=env);run(mode+'-initial-crash','node',str(r/'check.mjs'),'crash',env=env)
 journal=r/'chromium-profile/Default/BlancPrototypeSpaces.json.switch';before=journal.read_bytes();offset=(r/'chromium.log').stat().st_size
 run(mode+'-recovery-launch','node',str(r/'launch.mjs'),env={**os.environ,'RESTORE':'1','SPACES_CRASH_MODE':mode})
 for i in range(200):
  text=(r/'chromium.log').read_bytes()[offset:].decode(errors='replace');rows=[x.split('SPACES_CRASH:',1)[1] for x in text.splitlines() if 'SPACES_CRASH:' in x]
  if rows:break
  time.sleep(.1)
 else:raise Exception('no recovery crash')
 marker=json.loads(rows[-1]);assert marker['point']==mode;assert journal.read_bytes()==before;time.sleep(.5)
 run(mode+'-final-launch','node',str(r/'launch.mjs'),env={**os.environ,'RESTORE':'1'});run(mode+'-recover','node',str(r/'check.mjs'),'recover')
 (r/(mode+'-repeat.json')).write_text(json.dumps({'pass':True,'recovery_crash':marker,'journal_unchanged':True}))
 for n in ['seed','crash','recover']:shutil.copyfile(r/(n+'.json'),r/(mode+'-'+n+'.json'))
 run(mode+'-cleanup','node',str(r/'cleanup.mjs'))
