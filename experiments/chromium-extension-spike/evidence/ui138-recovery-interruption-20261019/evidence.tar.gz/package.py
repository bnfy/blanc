from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-window-recovery');b=Path('experiments/chromium-extension-spike');d=b/'evidence/ui138-recovery-interruption-20261019';d.mkdir(parents=True,exist_ok=True)
results={}
for mode in ['stage-first','stage-all','remove-first','remove-all']:
 x=json.loads((r/(mode+'-repeat.json')).read_text());y=json.loads((r/(mode+'-recover.json')).read_text());assert x['pass'] and y['pass'];results[mode]=x
for mode in ['invalid','uppercase']:
 x=json.loads((r/(mode+'-malformed.json')).read_text());assert x['pass'];results[mode]={'pass':True,'savedRecordsUnchanged':x['savedRecordsUnchanged']}
assert (b/'native/blanc_prototype_ui.cc').read_bytes()==(r/'normal.cc').read_bytes()
assert 'Dry-run scheduled actions: 0' in (r/'guard.log').read_text()
rows=[json.loads(s) for s in (r/'invocations.jsonl').read_text().splitlines()];times={x['name']:round(x['seconds'],2) for x in rows if x['name'] in ['build','normal-build','guard']}
s=f'''## Interrupted recovery and malformed identity — October 19, 2026

Four version-2 recovery interruption schedules pass. Each starts with two regular windows, persists their distinct UUIDs, crashes after the first destination tab during a switch, then restarts with real session restoration and crashes again during automatic source recovery: first/all source tabs staged, first/all prior tabs removed. The exact recovery marker is recorded and the journal remains byte-identical across the second crash. A third launch without the crash flag restores exactly the saved source content under its original UUID, preserves the decoy and saved records, and clears the journal. This is bounded process-crash coverage, not power-loss or every callback interleaving.

Two synthetic malformed persisted identity cases pass on the restored normal binary: 36 invalid characters and an uppercase UUID. Only owned disposable plaintext/mock-encrypted session records are mutated using Chromium's public mock keychain. Restored source identity is empty, the decoy retains its valid identity/content, both windows and saved records remain unchanged, recovery reports no unique match, and the valid journal remains. No fallback UUID is invented. This does not qualify malformed serialized lengths, missing metadata save acknowledgement, or late-arriving restore windows.

Temporary diagnostics removed byte-for-byte and normal binary rebuilt. Incremental wrappers: diagnostic {times['build']}s, normal restore {times['normal-build']}s; final guard0/{times['guard']}s. Product source unchanged; prior measured44files/107hunks remains unchanged within44/120, not re-enumerated. Owned profiles and fixture server cleaned; retained preview untouched, host unavailable so its original tabs not reverified.

Remaining: metadata save acknowledgement/crash before initial identity persistence, late or overlapping restores, malformed session serialization and journal variants, groups/pins/unsaved state at these boundaries, arbitrary scheduling and power-loss/deletion durability. Full Spaces acceptance/public controls remain open. Native input pending; latency deferred; Electron diagnostic build unapproved. Task0/F12 gates unchanged. Routine testing evidence only; cold-build accounting unchanged.

Evidence: `evidence/ui138-recovery-interruption-20261019/`.
'''
(d/'README.md').write_text(s);(d/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for n in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 with(b/n).open('a')as f:f.write('\n'+s)
ms=[]
with(d/'evidence.tar.gz').open('wb')as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.name=='normal.cc':continue
    data=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data));ms.append(dict(path=p.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(d/'evidence.tar.gz')as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members',times)
