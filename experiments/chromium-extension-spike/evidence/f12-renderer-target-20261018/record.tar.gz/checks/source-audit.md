# Renderer token guard audit

The extension API's `DocumentId` is checked against the ScriptExecutor's own
WebContents/frame after asynchronous helper loading. A narrow content helper
then returns RFHImpl's Blink DocumentToken only for active, live, non-error
committed documents. IsActive is false during pending lifecycle updates and
accepts only kActive, excluding GetDocumentToken's forbidden pending/speculative
states. These browser steps execute synchronously on the browser UI sequence.

The optional token travels in ExecuteCodeParams as an immutable string. It is
compared with the destination WebDocument.Token() in CanExecuteOnFrame when the
programmatic injection becomes eligible. Inject repeats the check for this
component immediately before executing, covering OnPermissionGranted's direct
entry. A previously granted withheld permission stays granted; a newly denied
(token mismatch or permissions) request finishes without execution. Other
extensions' permission-reply path is unchanged. Programmatic JS remains Blink
synchronous execution; this does not cover delayed effects caused by that JS.

The additional browser switch `blanc-renderer-token-mismatch-probe` only corrupts
an already-present token for the exact experiment component and an exact marked
JS source prefix. It does not expose a token API or permit execution. Native
mismatch tests are deliberate fault injection, not a claim that an uninstrumented
navigation produced the IPC race. Queued runAt cancellation uses real held page
loading and navigation separately. Permission-dialog, BFCache/prerender, renderer
crash and original caller event identity remain outside these bounded checks.

Initial incremental build passed. One renderer-only follow-up narrows the final
permission recheck to the component identity. No new cold output or GN-argument,
toolchain, Electron or latency work. Five added existing upstream paths bring the
tranche footprint to its 40-file ceiling; the new Blanc header is separately
inventoried as Blanc-owned source.
