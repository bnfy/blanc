# Redirect/worker and latency measurement plan

Same frozen 5,123-candidate corpus and real Electron decisions as the native checkpoint. Two fresh runs per regular/private profile for redirect and worker paths. Frame-less shared/service worker observations are recorded, never given a fabricated top-frame identity. A context gap is not an admitted parity pass.

Formal timing: full corpus each repetition, one discarded warm-up then five measured repetitions in the same engine/browser process per profile. Nearest-rank p50/p95/p99 and median-of-five. First 200 decisions in log order reported separately; native initial navigation includes engine startup wait. Native factory-entry-through-application TimeTicks includes Mojo. Electron JS hrtime provider observer is a reference only; native dispatch before JS is not exposed.

The initial one-page uncapped burst failed with actual ERR_PROXY_CONNECTION_FAILED. It is retained as invalid. The measured page layout partitions the original candidate order into 26 pages of 200 (last partial). Within each page all candidates are submitted immediately; there is no per-request queue or pacing. Both browsers use the same authored page sequence and complete response graph. Root URLs repeat per page; repeats/children/controls never enlarge the distinct-candidate floor. Every page has an independent log/arrival boundary and must match the frozen oracle.

Record up to five idle snapshots before each repetition; >=90% aggregate CPU idle is an explicit operational check, not a change to the approved 5 ms bound. Background activity is not killed or hidden. A run that completes with a noisy baseline can report timing observations but does not close the otherwise-idle protocol gate.
