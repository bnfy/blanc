// One discarded warm-up, then five full page loads in the SAME engine session.
// No harness concurrency cap: resource scheduling belongs to the browser.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';
import {sha} from './generate.mjs';import {startSynthetic} from './transport.mjs';import {createCertificateSet} from './certificate-set.mjs';import {pageUrl,pageResponse} from './page.mjs';import {openSession,pause} from './session.mjs';
export function percentiles(values){assert(values.length);const a=[...values].sort((a,b)=>a-b);return Object.fromEntries([['p50',.5],['p95',.95],['p99',.99]].map(([key,q])=>[key,a[Math.ceil(q*a.length)-1]]));}
function idleSnapshot(){const text=execFileSync('/usr/bin/top',['-l','2','-s','1','-n','0'],{encoding:'utf8'});const matches=[...text.matchAll(/CPU usage: ([\d.]+)% user, ([\d.]+)% sys, ([\d.]+)% idle/g)];assert(matches.length);const m=matches.at(-1);return {at:new Date().toISOString(),user:Number(m[1]),system:Number(m[2]),idle:Number(m[3])};}
const [configPath,oraclePath,evidence,only='both']=process.argv.slice(2),config=JSON.parse(fs.readFileSync(configPath));assert(evidence&&!fs.existsSync(evidence));fs.mkdirSync(evidence);
const manifest=JSON.parse(fs.readFileSync(path.join(oraclePath,'candidate-manifest.json'))),fixtures=new Map(JSON.parse(fs.readFileSync(path.join(oraclePath,'responses.json'))));
fixtures.set(pageUrl,pageResponse(manifest.candidates,{concurrency:'natural'}));
const root=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'blanc-f12-latency-'))),certificates=createCertificateSet(path.join(root,'certificates'),[...new Set([...fixtures.keys()].map(u=>new URL(u).hostname))]);
const report={started:new Date().toISOString(),completed:false,protocol:'one discarded full warm-up then five full repetitions per profile in the same process; browser natural concurrency; nearest-rank percentiles and median-of-five','nativeClock':'base::TimeTicks from factory entry or redirect receipt through decision application; Mojo included','electronClock':'process.hrtime.bigint at JS provider-observer entry through real provider result; excludes preceding native Electron dispatch; reference only','fixtureSha256':sha(JSON.stringify([...fixtures])),fullAcceptance:false,sources:{},runs:[],profiles:{},gaps:['Electron native-entry TimeTicks is not exposed by this JS observer','engine-internal timing not exposed separately']};
for(const name of ['latency-run.mjs','session.mjs','page.mjs'])report.sources[name]=sha(fs.readFileSync(new URL(name,import.meta.url)));
fs.writeFileSync(path.join(evidence,'page-response.json'),JSON.stringify(fixtures.get(pageUrl),null,2));
let session,replay;
try{
 for(const browserKind of (only==='both'?['electron','chromium']:[only]))for(const kind of ['regular','private']){
  const label=browserKind+'-'+kind;const oracle=JSON.parse(fs.readFileSync(path.join(oraclePath,kind+'-stability.json')));assert(oracle.stable);const expected=new Map(oracle.oracle.map(r=>[r.context.url,r]));
  replay=await startSynthetic({fixtures,tlsMaterial:certificates});const idleBeforeSession=idleSnapshot();
  session=await openSession({config,browserKind,kind,label,root,transport:replay,certificates});
  const browserFailures=[];session.page.on('requestfailed',r=>browserFailures.push({url:r.url(),error:r.failure()?.errorText}));
  report.profiles[label]={source:session.source,idleBeforeSession,repetitions:[],boundMs:browserKind==='chromium'?5:null};
  for(let rep=0;rep<6;rep++){
   await session.page.goto('about:blank');await pause(1000);
   const startFailures=browserFailures.length;const idle=idleSnapshot(),startRecords=session.records().length,startArrivals=replay.arrivals.length,startFaults=replay.faults.length,started=new Date().toISOString();
   await session.page.goto(pageUrl,{waitUntil:'commit',timeout:60000});
   await session.page.waitForFunction(()=>window.pilot?.done,null,{timeout:240000});
   await session.page.waitForFunction(()=>(window.blancFixtureChildren||[]).length===(window.blancFixtureExecuted||[]).length,null,{timeout:30000});await pause(500);
   const rows=session.records().slice(startRecords),records=rows.filter(r=>fixtures.has(r.url));
   const dom=await session.page.evaluate(()=>({loads:window.pilot.loads,executed:window.blancFixtureExecuted||[],children:window.blancFixtureChildren||[]}));
   const arrivals=replay.arrivals.slice(startArrivals),transportFaults=replay.faults.slice(startFaults),faults=[];
   const services=new Set(['clients2.google.com','www.google.com:443','accounts.google.com:443']);
   if(transportFaults.some(f=>!(['plaintext-refused','connect-refused'].includes(f.code)&&services.has(f.authority))))faults.push('transport-fault');
   if(rows.some(r=>r.fault))faults.push('observer-fault');
   const byUrl=new Map(),seenArrivals=new Map();for(const r of records){if(byUrl.has(r.url))faults.push('duplicate-observation');byUrl.set(r.url,r);}for(const a of arrivals){if(seenArrivals.has(a.url))faults.push('duplicate-arrival');seenArrivals.set(a.url,a);}
   const latencies=[];
   for(const [url,ref] of expected){const r=byUrl.get(url);if(!r){faults.push('missing-observation:'+url);continue;}
    const decision=browserKind==='electron'?(r.result?.cancel===true?'block':'allow'):r.decision;
    if(decision!==ref.decision)faults.push('decision-difference:'+url);
    const ctx=browserKind==='electron'?{url:r.url,method:r.method,resource_type:r.resourceType,initiator_origin:r.initiatorOriginPresent?r.initiatorOrigin:'absent',top_frame_origin:r.resourceType==='mainFrame'?new URL(r.url).origin:r.frame?.topOrigin,frame_role:'main',profile_kind:r.profileKind,redirect_index:0}:r;
    for(const key of Object.keys(ref.context))if(ctx[key]!==ref.context[key])faults.push('context-mismatch:'+key+':'+url);
    if(browserKind==='chromium'&&(r.status!=='ready'||![0,1].includes(r.engine_result)))faults.push('engine-failure:'+url);
    if(decision==='allow'&&seenArrivals.get(url)?.sha256!==sha(fixtures.get(url).body))faults.push('allowed-response:'+url);
    if(decision==='block'&&seenArrivals.has(url))faults.push('blocked-arrival:'+url);
    const us=browserKind==='electron'?r.observer_to_result_us:r.hook_to_decision_us;if(!Number.isFinite(us)||us<0)faults.push('missing-timing');else latencies.push(us/1000);
   }
   for(const url of byUrl.keys())if(!expected.has(url))faults.push('extra-observation:'+url);
   const executed=[];for(const c of manifest.candidates){const d=expected.get(c.url)?.decision;const loads=dom.loads.filter(l=>l.id===c.id);if(loads.length!==1||loads[0].event!==(d==='block'?'error':'load'))faults.push('DOM-load:'+c.id);if(c.resourceType==='script'&&d==='allow')executed.push(c.id);}
   if(JSON.stringify([...dom.executed].sort())!==JSON.stringify(executed.sort())||JSON.stringify([...dom.children].sort())!==JSON.stringify(executed.sort()))faults.push('script-child-completion');
   // First 200 uses actual decision log order, never sorted by URL or timing.
   const first200=records.slice(0,200).map(r=>(browserKind==='electron'?r.observer_to_result_us:r.hook_to_decision_us)/1000);
   const result={label,rep,warmup:rep===0,started,finished:new Date().toISOString(),idleBefore:idle,count:latencies.length,valid:faults.length===0,faults,percentilesMs:percentiles(latencies),...(rep===0?{first200Ms:percentiles(first200),first200MaximumMs:Math.max(...first200)}:{})};
   fs.writeFileSync(path.join(evidence,label+'-'+rep+'.json'),JSON.stringify({result,records,arrivals,transportFaults,dom,browserFailures:browserFailures.slice(startFailures)},null,2));report.runs.push(result);report.profiles[label].repetitions.push(result);console.log(JSON.stringify({...result,faults:result.faults.slice(0,5),faultCount:result.faults.length}));assert(result.valid,JSON.stringify(faults.slice(0,8)));
  }
  const reps=report.profiles[label].repetitions.slice(1);report.profiles[label].medianMs=Object.fromEntries(['p50','p95','p99'].map(k=>[k,reps.map(r=>r.percentilesMs[k]).sort((a,b)=>a-b)[2]]));
  report.profiles[label].timingBoundMet=browserKind==='chromium'?report.profiles[label].medianMs.p99<5:null;
  report.profiles[label].idleConditionMet=report.profiles[label].repetitions.every(r=>r.idleBefore.idle>=90);
  await session.close();session=null;await replay.close();replay=null;
 }
 report.completed=true;
}catch(e){report.error=String(e);process.exitCode=1;if(session)fs.writeFileSync(path.join(evidence,'partial.json'),JSON.stringify({records:session.records().filter(r=>fixtures.has(r.url)),arrivals:replay?.arrivals,faults:replay?.faults,dom:await session.page.evaluate(()=>({pilot:window.pilot,executed:window.blancFixtureExecuted,children:window.blancFixtureChildren})).catch(()=>null)},null,2));}
finally{if(session)await session.close();if(replay)await replay.close();fs.rmSync(root,{recursive:true,force:true});report.cleanup={removed:!fs.existsSync(root)};report.finished=new Date().toISOString();fs.writeFileSync(path.join(evidence,'report.json'),JSON.stringify(report,null,2));}
