from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-closed-corrupt');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-closed-corrupt-20261019';rows=json.loads((r/'matrix.json').read_text());assert len(rows)==5
for x in rows:assert x['startup']['pass'] and x['restart']['pass'] and x['restart']['restore']
assert any(x['url'].endswith('/old-closed') for x in rows[0]['startup']['before'])
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved'];assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-anchor-fix/binary-hashes.json').read_text())
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps({'pass':True,'fatalOrDangling':errors},indent=2));(r/'guard.log').write_bytes(Path('/private/tmp/blanc-anchor-fix/closed-corrupt-guard.log').read_bytes());(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());(r/'scope.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'mutation':'Tabs_* in Sessions and Sessions_Encrypted, browser stopped','partialWrite':'offline truncation simulation, not actual interrupted syscall/power loss','codeChanged':False,'nativeInput':'pending unlock','latency':'deferred','electronDiagnosticBuild':'unapproved'},indent=2))
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 Recently Closed corruption and torn-record checks

Five isolated cases mutate Tabs_* in both plaintext and encrypted session stores, with the
owned browser stopped: intact control, invalid eight-byte header, final-byte removal,
half-file truncation, and missing files. Original sizes and hashes and changed sizes/hashes
are recorded. Session_* files are not mutated. Truncation models a partial write; no live
write interruption, concurrent writer, fsync/durability, disk-full or power-loss claim.

| Case | Original closed fixture entries visible | Fresh entry persists and reopens |
| --- | --- | --- |
'''
for x in rows:text+='| '+x['case']+' | '+str(sum(t['url'].endswith('/old-closed') for t in x['startup']['before']))+' | pass |\n'
text+='''
The intact control establishes saved Recently Closed data. Loss of old entries after corruption
is recorded as data loss, not recovered history. In every case the browser remains usable;
clear/new-tab/close creates a fresh native entry, a clean restart preserves it, and reopening
through the native bridge yields the expected URL. The seed private-tab control does not
appear in exposed closed entries. No fatal or dangling-pointer diagnostic across the run.
This does not prove absence of private data from every underlying byte or hidden window entry.

No production changes or compilation: guard zero4.26s, native hashes unchanged; footprint
40files/97hunks not re-enumerated. Disposable profile/copies/server removed and preview original
tabs preserved. Native input pending unlock, latency deferred, Electron diagnostic build
unapproved/unstarted. Larger history/group/window entries, invalid command lengths, disk errors,
concurrent writes and native recovery choices remain gaps. Plan item4 and F12/Task0 gates open.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed evidence members; profile and session binaries/raw logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-closed-corrupt-20261019/`. Cold-build costs unchanged.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-closed-corrupt-20261019/`.\n'+s[i:]);print(len(m),'verified members')
