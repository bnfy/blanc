from pathlib import Path
import subprocess,shutil,time,json,hashlib
r=Path('/private/tmp/blanc-closed-corrupt');profile=r/'chromium-profile';seed=r/'seed-profile'
def stopped():
 for i in range(100):
  rows=subprocess.check_output(['ps','-axo','command='],text=True).splitlines()
  if not any('--user-data-dir='+str(profile) in x for x in rows):return
  time.sleep(.1)
 raise RuntimeError('owned browser remains active')
def run(script,*args):
 start=time.time();p=subprocess.run(['node','--experimental-websocket',str(r/script),*args],text=True,capture_output=True)
 with (r/'invocations.jsonl').open('a') as f:f.write(json.dumps({'script':script,'args':args,'seconds':time.time()-start,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})+'\n')
 print(script,args,p.returncode,p.stdout,flush=True)
 if p.returncode:raise RuntimeError('failed '+script)
stopped();shutil.copytree(profile,seed)
files=list((seed/'Default/Sessions').glob('Tabs_*'));assert files
summary=[]
for case in ['intact','invalid-header','tail-cut','mid-cut','missing']:
 stopped();shutil.rmtree(profile);shutil.copytree(seed,profile);changes=[]
 for f in sorted(list((profile/'Default/Sessions').glob('Tabs_*'))+list((profile/'Default/Sessions_Encrypted').glob('Tabs_*'))):
  before=f.read_bytes();after=before
  if case=='invalid-header':after=b'BROKEN!!'+before[8:]
  elif case=='tail-cut':after=before[:-1]
  elif case=='mid-cut':after=before[:max(9,len(before)//2)]
  elif case=='missing':after=b''
  if case=='missing':f.unlink()
  else:f.write_bytes(after)
  changes.append({'file':str(f.relative_to(profile)),'beforeBytes':len(before),'afterBytes':len(after),'beforeSha':hashlib.sha256(before).hexdigest(),'afterSha':hashlib.sha256(after).hexdigest(),'removed':case=='missing'})
 run('restore.mjs');run('check.mjs','startup');stopped();startup=json.loads((r/'startup.json').read_text());(r/(case+'-startup.json')).write_text(json.dumps(startup,indent=2))
 run('restore.mjs');run('check.mjs','restart');stopped();restart=json.loads((r/'restart.json').read_text());(r/(case+'-restart.json')).write_text(json.dumps(restart,indent=2));summary.append({'case':case,'mutations':changes,'startup':startup,'restart':restart});(r/'matrix.json').write_text(json.dumps(summary,indent=2))
shutil.rmtree(seed)
