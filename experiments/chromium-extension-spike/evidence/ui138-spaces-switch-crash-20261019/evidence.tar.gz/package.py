from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-spaces-switch-crash');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-switch-crash-20261019';d.mkdir(parents=True,exist_ok=True)
rows=[]
for mode in ['stage-first','stage-all','remove-first','remove-all']:
 a=json.loads((r/(mode+'-crash.json')).read_text());b=json.loads((r/(mode+'-recover.json')).read_text());assert a['pass'] and b['pass'];rows.append({'mode':mode,'marker':a['marker'],'saved_records_unchanged':True,'explicit_reopen_both_and_resave':True})
assert json.loads((r/'normal-smoke.json').read_text())['pass']
original=(r/'normal.cc').read_bytes();assert original==(base/'native/blanc_prototype_ui.cc').read_bytes()
(d/'results.json').write_text(json.dumps({'cases':rows,'normal_source_restored_sha256':hashlib.sha256(original).hexdigest(),'normal_smoke_pass':True},indent=2)+'\n')
s='''## Spaces crashes during actual staging and removal — October 19, 2026

Temporary diagnostic hooks abruptly exited the disposable browser without shutdown cleanup after first destination staging (four live tabs), all destination staging (six), first actual source removal (five), and final source removal (three). Markers record the actual live URLs and expected three-tab source/destination. Each case preserved the complete saved A/B records; restart without the crash flag explicitly reopened both Spaces at their correct three-tab contents and saved again. All four final cases pass.

CloseWebContentsAt queues some removals: the first diagnostic attempt after a close request still had six tabs. The corrected removal checkpoints run from tab-model notifications after actual removal. Completion order differs from request order, so the assertion checks the actual surviving source/destination set, not an assumed first close. Initial UI-thread blocking marker failure, request-only observation, stale-log match and close-order harness assumptions are retained. Markers are read only from the current switch's log interval in final removal runs.

This demonstrates saved-record recoverability after abrupt exit during these four UI stages. It does not demonstrate automatic completion/rollback of the interrupted live window, automatic session restoration, preservation of unsaved page state, or power-loss durability. Public Spaces controls remain hidden; broader transactional/residency acceptance remains open.

All diagnostic source edits were removed byte-for-byte and the normal prototype rebuilt. Normal A/B switching passes even with the now-inert diagnostic flag supplied. Four guarded incremental builds succeeded: wrappers39.60/38.10/38.15/38.83s; Siso35.26/34.19/34.16/34.93s. Final guard zero/3.74s. No cold build or GN/toolchain change. Final upstream footprint unchanged from measured41files/100hunks. Diagnostic patches and invocation logs are archived; no diagnostic hook is in product source. Owned profiles/servers removed; retained preview untouched, host unavailable so original-tab identity not reverified. Native input pending, latency deferred, Electron diagnostic build unapproved. Plan item4 remains incomplete. Evidence: evidence/ui138-spaces-switch-crash-20261019/.
'''
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+s)
ms=[]
with (d/'evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.name=='normal.cc':continue
    b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members')
