from pathlib import Path
import subprocess,json,time,struct,hashlib
r=Path('/private/tmp/blanc-group-encrypted')
def run(n,*a):
 t=time.time();p=subprocess.run(['node','--experimental-websocket',str(r/n),*a],capture_output=True,text=True)
 with (r/'invocations.jsonl').open('a') as f:f.write(json.dumps(dict(script=n,args=a,seconds=time.time()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 print(n,p.returncode,p.stdout,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
if (r/'chromium.pid').exists():run('cleanup.mjs')
run('start.mjs');run('check.mjs','cross','true')
for _ in range(100):
 ps=subprocess.check_output(['ps','-axo','command='],text=True)
 if '--user-data-dir='+str(r)+'/chromium-profile' not in ps:break
 time.sleep(.2)
else:raise RuntimeError('browser still active')
run('encrypt-legacy.mjs');run('normal-relaunch.mjs');run('check.mjs','closed-crash','true');run('cleanup.mjs')
