from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-group-encrypted');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-group-encrypted-private-crash-20261019'
x=json.loads((r/'closed-crash-true.json').read_text());assert x['pass'] and x['collapsedMatches']==False
assert json.loads((r/'private.json').read_text())['pass'];assert json.loads((r/'private-after.json').read_text())['pass'];assert json.loads((r/'cleanup.json').read_text())['profilesRemoved']
assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-group-persist-fix/binary-hashes.json').read_text())
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps(dict(errors=errors)))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 encrypted legacy and private crash checks

The current binary writes a closed-group fixture using its configured mock keychain. With the
owned browser stopped, the harness decrypts the encrypted command13 using Chromium's public
mock password/derivation, removes only the appended collapse flag, adjusts the Pickle length,
and re-encrypts the command and updates its outer length. All other ciphertext remains intact.
Plaintext Tabs counterparts are removed from that disposable profile so they cannot supply the
restored group. After restart the native encrypted reader restores both URLs, name, color and
membership and defaults to expanded, as required for the absent field. File hashes and record
sizes are saved. No real keychain access, profile/key upload, older-binary execution or real-key
migration is claimed. This is a synthetic encrypted legacy-shaped fixture.

A fresh disposable browser retains a regular closed group, closes one private group (history
stays empty), and leaves another two-tab private group live when the owned browser is SIGKILLed.
Before killing, the harness verifies its profile command and persisted Crashed marker. After
normal restart no private URL/group is present in exposed tabs or Recently Closed; the regular
closed group still restores both tabs. A newly created private context has no groups/history,
and reopen-most-recent returns false. Context disposal leaves regular restoration intact.
This covers exposed native session behavior, not forensic absence of private bytes on disk,
automatic crash-restore-button interaction, all incognito lifecycles or OS/power-loss recovery.

No production change or compile; zero-action guard, binary hashes unchanged;41files/100hunks
(not re-enumerated). Disposable profiles/server removed, original preview/status preserved.
Native input pending, latency deferred, Electron diagnostic build unapproved/unstarted.
Real-keychain/key rotation, older-binary rollback, malformed encrypted records, multiple private
contexts and wider concurrent/crash/visual scenarios remain gaps. Plan/evidence updated;
F12/Task0 and visualitem4 gates remain open. Routine testing only; cold column unchanged.
''' 
(e/'README.md').write_text(text+f'\n{len(m)} hashed archive members, all verified.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-group-encrypted-private-crash-20261019/`.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-group-encrypted-private-crash-20261019/`.\n'+s[i:]);print(len(m),'verified members')
