import pathlib,subprocess,os,json,copy,uuid
r=pathlib.Path('/private/tmp/blanc-partial-negatives');env={**os.environ,'ACK_ENCRYPTED':'1','PATH':'/Users/anthonyjloria/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
def run(name,*args,restore=False):subprocess.run(['python3',str(r/'invoke.py'),name,*args],env={**env,**({'RESTORE':'1'} if restore else {})},check=True)
try:
 run('start','node',str(r/'start.mjs'));run('seed','node',str(r/'check.mjs'),'seed');run('seed-close','node',str(r/'close.mjs'))
 disk=r/'chromium-profile/Default/BlancPrototypeSpaces.json';s=json.loads((r/'seed.json').read_text());(r/'store-before.txt').write_bytes(disk.read_bytes())
 base=dict(version=3,id='journal-validation',source_window=s['source']['spaceWindowIdentity'],source_name='A',source=s['store']['items']['A'],destination=s['store']['items']['B'],source_tabs=[str(uuid.uuid4()) for x in s['store']['items']['A']['tabs']])
 for mode in ['missing-tabs','duplicate-tabs','wrong-type','uppercase','short-list','valid']:
  x=copy.deepcopy(base)
  if mode=='missing-tabs':del x['source_tabs']
  if mode=='duplicate-tabs':x['source_tabs'][1]=x['source_tabs'][0]
  if mode=='wrong-type':x['source_tabs'][0]=17
  if mode=='uppercase':x['source_tabs'][0]=x['source_tabs'][0].upper()
  if mode=='short-list':x['source_tabs'].pop()
  if mode=='valid':x['version']=2;x['source_tabs']=[17]
  data=json.dumps(x);pathlib.Path(str(disk)+'.switch').write_text(data);(r/'journal-before.txt').write_text(data)
  run(mode+'-restart','node',str(r/'launch.mjs'),restore=True);run(mode+'-proof','node',str(r/'verify.mjs'),mode);run(mode+'-close','node',str(r/'close.mjs'))
finally:run('cleanup','node',str(r/'cleanup.mjs'))
