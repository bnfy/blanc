from pathlib import Path
import tarfile,hashlib,json,io
repo=Path('/private/tmp/blanc-chromium157-work');out=repo/'experiments/chromium-extension-spike/evidence/ui138-partial-state-20261019';out.mkdir(parents=True,exist_ok=True)
roots=['blanc-partial-state','blanc-partial-group','blanc-partial-negatives','blanc-immediate-repeat-baseline','blanc-immediate-repeat-spaces-1','blanc-immediate-repeat-spaces-2']
files=[]
for name in roots:
 root=Path('/private/tmp')/name
 assert not (root/'chromium-profile').exists(),name+' profile remains'
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in ['.mjs','.cjs','.py','.c','.json','.jsonl','.log','.txt']:
   files.append((name+'/'+str(p.relative_to(root)),p.read_bytes()))
files.append(('blanc-cdp.mjs',Path('/private/tmp/blanc-cdp.mjs').read_bytes()))
manifest=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in files]
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for name,data in files:
  i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o600;t.addfile(i,io.BytesIO(data))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz') as t:
 for row in manifest:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
print(json.dumps({'members':len(manifest),'archive_sha256':hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest(),'bytes':(out/'evidence.tar.gz').stat().st_size}))
