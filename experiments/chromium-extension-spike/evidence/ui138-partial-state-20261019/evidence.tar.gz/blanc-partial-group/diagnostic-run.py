import subprocess,os,pathlib
r=pathlib.Path('/private/tmp/blanc-partial-group');env={**os.environ,'PATH':'/Users/anthonyjloria/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],env=env,check=True)
try:
 run('diagnostic-start','node',str(r/'start.mjs'));run('diagnostic-seed','node',str(r/'check.mjs'),'seed');run('diagnostic-switch','node',str(r/'partial.mjs'),'switch')
finally:run('diagnostic-cleanup','node',str(r/'cleanup.mjs'))
