from pathlib import Path
import subprocess,json,time
r=Path('/private/tmp/blanc-group-collapse-runtime')

def run(script,*args):
 start=time.time();p=subprocess.run(['node','--experimental-websocket',str(r/script),*args],capture_output=True,text=True)
 with (r/'invocations.jsonl').open('a') as f:f.write(json.dumps({'script':script,'args':args,'seconds':time.time()-start,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})+'\n')
 print(script,args,p.returncode,p.stdout,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for label,color,collapsed in [('blue-collapsed','#376694','true'),('pink-expanded','#9b4761','false'),('green-recent','#426c4c','true')]:
 if (r/'chromium.pid').exists():run('cleanup.mjs')
 run('start.mjs');run('groups.mjs','seed',color,collapsed,'recent' if label=='green-recent' else 'entry');run('normal-relaunch.mjs');run('groups.mjs','window',color,collapsed)
 for name in ['group-seed','group-window']:(r/(name+'-'+label+'.json')).write_bytes((r/(name+'.json')).read_bytes())
run('cleanup.mjs')
