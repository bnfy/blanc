from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-group-collapse-runtime');b=Path('/private/tmp/blanc-group-collapse-fix');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-group-collapse-fix-20261019'
for label in ['blue-collapsed','pink-expanded','green-recent']:
 for phase in ['seed','window']:
  x=json.loads((r/f'group-{phase}-{label}.json').read_text());assert x['pass'];v=x['groupVisual' if phase=='seed' else 'windowVisual'];assert v['colorMatches'] and v['collapsedMatches']
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved']
p=json.loads((r/'preview.json').read_text());assert p['tabs']==['blanc://newtab/','https://chromewebstore.google.com/category/extensions'] and not p['status']
q=json.loads((b/'patch-budget.json').read_text());assert q['within_budget'];assert(q['upstream_files'],q['hunks'])==(40,97)
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors
(r/'log-check.json').write_text(json.dumps({'pass':True,'errors':errors}));(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
(b/'native.patch').write_bytes(subprocess.check_output(['git','diff','--','experiments/chromium-extension-spike/native/blanc_prototype_ui.cc'],cwd=w))
files={}
for root,prefix in [(r,'runtime'),(b,'build')]:
 for p in root.iterdir():
  if p.is_file() and (p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.patch'] or (prefix=='build' and p.suffix=='.log')):files[prefix+'/'+p.name]=p
m={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())};e.mkdir(parents=True,exist_ok=True)
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 closed-group collapsed-state repair

The Recently Closed bridge captures a group entry's collapsed flag before restoration consumes
it, then reapplies the flag to the restored native group. Returned LiveTab session identities
identify the group; the saved-group UUID handles Chromium's saved-group path, which can reopen
a group without returning LiveTabs. The most-recent route now reports success for that path.
Only the collapsed flag is changed; current title/color are retained. Ordinary tab and window
entries are not given a group override. No additional upstream file or hunk is patched.

Final-binary automated native bridge checks pass all six group/window cases:
- Blue collapsed: selected Recently Closed group entry and saved window both retain collapse.
- Pink expanded control: group entry and saved window remain expanded.
- Green collapsed: reopen-most-recent returns true and retains collapse; saved window retains it.
Each case checks two URLs, membership, group name and exact color. Window checks explicitly
record the intended state before clean shutdown and normal restart, independently of group
restoration. These are bounded regular-profile tests, not physical mouse/keyboard acceptance.

The first LiveTabs-only repair compiled but failed collapse preservation. The next repair passed
selected-entry checks but the most-recent success return remained false; both failures are kept.
An owned-browser shutdown/start overlap was refused and retained; cleanup now waits for exit.
A sandboxed prepare failed at icon-tool access, then succeeded with approved tool access.
Three guarded incremental builds: 34.20s, 37.14s and BUILD3_SECONDS Siso; six steps each.
Final guard zero actions. Fresh patch inventory: 40 upstream files / 97 hunks (budget40/120).
No GN/toolchain/cache change, cold build, latency run or Electron diagnostic build.

Disposable profile/server removed; original preview tabs restored on the final binary, empty
host status. Native input remains pending unlock. Cross-window group-entry routing, all colors,
private/mixed-group/crash visual persistence and wider lifecycle remain unqualified. Earlier
F12/Task0 gates and plan item4 remain open. This supersedes the bounded collapsed-state failure
in evidence/ui138-group-visual-20261019, without rewriting that historical result.
'''
import re
seconds=re.findall(r'([0-9.]+)s Build Succeeded', (b/'build3.log').read_text())[-1];text=text.replace('BUILD3_SECONDS',seconds+'s')
(e/'README.md').write_text(text+f'\n{len(m)} SHA-256-verified archive members; profiles/raw browser logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-group-collapse-fix-20261019/`. Routine repair only; cold column unchanged.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-group-collapse-fix-20261019/`.\n'+s[i:]);print(len(m),'verified archive members')
