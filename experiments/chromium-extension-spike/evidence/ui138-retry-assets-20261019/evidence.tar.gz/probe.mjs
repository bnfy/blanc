import { _electron } from '/private/tmp/blanc-electron-drag-fix/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const dir=fs.mkdtempSync('/private/tmp/blanc-retry-owned-');
fs.mkdirSync(dir+'-Dev');
fs.writeFileSync(dir+'-Dev/settings.json',JSON.stringify({onboardingVersion:1,adblockProvider:'ublock-origin',adblockEnabled:true,searchSuggestions:false,usagePing:false,onePasswordEnabled:false}));
const {ELECTRON_RUN_AS_NODE: ignored,...env}=process.env;
let app,child;
const poll=async(fn,ok)=>{for(let i=0;i<1000;i++){const v=await fn();if(ok(v))return v;await new Promise(r=>setTimeout(r,100));}throw Error('poll timeout');};
try {
app=await _electron.launch({args:[process.cwd(),`--user-data-dir=${dir}`,'--host-resolver-rules=MAP * ~NOTFOUND'],chromiumSandbox:true,env:{...env,BLANC_TEST:'1',BLANC_UBLOCK_TEST:'1'}});child=app.process();
await poll(()=>app.evaluate(()=>globalThis.__blanc?.blockingStatus()),s=>s?.phase==='ready');
await app.evaluate(()=>globalThis.__blanc.blockingExhaustRecovery());
await app.evaluate(({webContents})=>webContents.getAllWebContents().find(w=>w.getType()==='backgroundPage').forcefullyCrashRenderer());
await poll(()=>app.evaluate(()=>globalThis.__blanc.blockingStatus()),s=>s?.phase==='failed');
await app.evaluate(({net})=>{const orig=net.fetch;globalThis.probeCalls=[];net.fetch=function(url,...args){if(String(url).startsWith('file:')){probeCalls.push(String(url));return new Promise(()=>{});}return orig.call(this,url,...args);};});
await app.evaluate(()=>globalThis.__blanc.openSettings());
const page=await poll(async()=> (await app.windows()).find(p=>p.url().startsWith('blanc://settings/')),Boolean);
await page.locator('#ublockRetry').waitFor({state:'visible',timeout:12000});
assert.deepEqual(await app.evaluate(()=>probeCalls),[]);
await page.locator('#ublockRetry').click();
await poll(()=>app.evaluate(()=>globalThis.__blanc.blockingStatus()),s=>s?.phase==='ready');
console.log('PASS: failed provider -> Settings rendered without file fetch -> actual Retry click -> ready');
} finally {if(app){const timer=setTimeout(()=>child.kill('SIGKILL'),5000);try{await app.close();}finally{clearTimeout(timer);}}fs.rmSync(dir,{recursive:true,force:true});fs.rmSync(dir+'-Dev',{recursive:true,force:true});}
