import pathlib,subprocess
p=pathlib.Path('src/main/pages.js'); fixed=p.read_bytes()
try:
 p.write_bytes(subprocess.check_output(['git','show','HEAD:src/main/pages.js']))
 with open('/private/tmp/blanc-retry-fix/before-probe.log','w') as log:
  r=subprocess.run(['node','/private/tmp/blanc-retry-fix/probe.mjs'],stdout=log,stderr=subprocess.STDOUT,timeout=140)
 print('old-source probe exit',r.returncode)
finally:p.write_bytes(fixed)
