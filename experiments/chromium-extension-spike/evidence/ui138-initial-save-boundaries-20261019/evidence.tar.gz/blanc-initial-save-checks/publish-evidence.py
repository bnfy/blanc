from pathlib import Path
import json,hashlib,tarfile,io
repo=Path('/private/tmp/blanc-chromium157-work');base=repo/'experiments/chromium-extension-spike';out=base/'evidence/ui138-initial-save-boundaries-20261019';out.mkdir(exist_ok=True)
roots=[Path('/private/tmp/blanc-initial-'+m+'-'+c) for m in ['clear','encrypted'] for c in ['failure','crash','release']]+[Path('/private/tmp/blanc-initial-save-checks')]
rows=[];data=[]
for r in roots:
 assert not (r/'chromium-profile').exists()
 if (r/'result.json').exists():assert json.loads((r/'result.json').read_text())['pass']
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ['.mjs','.cjs','.py','.c','.json','.jsonl','.log','.txt']:
   b=p.read_bytes();name=r.name+'/'+p.name;data.append((name,b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=Path('/private/tmp/blanc-cdp.mjs').read_bytes();data.append(('blanc-cdp.mjs',b));rows.append({'path':'blanc-cdp.mjs','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for n,b in data:
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(out/'evidence.tar.gz') as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
text='''### October 19 — Initial-window save failures and pre-write crash boundary

Six disposable-profile schedules pass their bounded assertions on the unchanged normal binary, in explicit clear and encrypted session modes. Injected EIO at both macOS barrier-flush and fallback fsync sets `initialWindowSaveFailed=true`, while `initialWindowSaved=false`. Removing the fault leaves that failed status during the one-second observation; automatic retry is not implemented or claimed. The new window happened to restore after this flush-error process crash because writes had already reached the OS; that is not durability or power-loss evidence.

Holding the first selected Session write before its syscall keeps both saved/failed flags false. SIGKILL while held loses the new unacknowledged window in both modes, while the previously saved source and decoy return with exact UUIDs/URLs. This is a measured pre-save data-loss boundary, not a recovery pass for that new window. Paired release controls remain unsaved while held, then acknowledge success after release and restore the new window after SIGKILL. Marker PID/path evidence confirms the owned browser and expected clear/encrypted store. The crash helpers match either session store but the recorded selected path is explicitly asserted; release helpers select the exact store. No hardware or power-loss simulation is claimed.

Profiles were primed and cleanly closed before these tests. Restart uses crash-bubble bypass only in disposable profiles; native Restore remains untested. No Chromium source edit or compilation; final guard zero actions/5.16s. Last measured footprint remains49 files/117 hunks within49/120. All six task profiles and servers removed; retained preview untouched (host unavailable, tabs not reverified). Native input pending, latency deferred, Electron diagnostic build unapproved. Remaining gaps include retry after an initial save failure, actual provider/hardware failure, pre-ack recent edits, first-ever profile persistence and broader lifecycle.
'''
(out/'README.md').write_text('# Initial-window save boundary evidence\n\n'+text+'\nArchive members: '+str(len(rows))+'. SHA-256: `'+hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()+'`.\n')
for name in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=base/name;p.write_text(p.read_text()+'\n\n'+text+'\nEvidence: [initial save boundaries](evidence/ui138-initial-save-boundaries-20261019/README.md).\n')
print(len(rows),hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest())
