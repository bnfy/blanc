from pathlib import Path
import json,tarfile,gzip,io,hashlib
r=Path('/private/tmp/blanc-spaces-interrupt');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-interrupted-write-20261019';d.mkdir(parents=True,exist_ok=True)
s='''## Actual Spaces temporary-write interruption — October 19, 2026

A disposable-process write interposer stopped the actual Chromium Spaces primary temporary-file write after 96 of 192 bytes. The harness verified the owning browser PID, the native hidden temp filename, actual file size, valid checkpoint and unchanged complete primary before SIGKILL. The process was killed while the write remained blocked, before atomic replacement. Restart without injection retained the exact prior JSON generation; explicit Space reopening restored baseline URLs and excluded the unfinished navigation. After pages finished loading, a new save succeeded.

This is a real bounded process-crash/partial-primary-write check, not power-loss durability, backup-write interruption, rename/fsync boundary coverage or arbitrary concurrent recovery. No product patch or native Chromium compilation was needed. Guard: zero actions,5.22s; upstream footprint unchanged from measured41files/100hunks. Native input pending; latency deferred; Electron diagnostic build unapproved. Plan item4 remains incomplete.

The prior helper failure was recursive write interposition (stack overflow), not a signing restriction. The test-only helper now uses direct SYS_write (macOS deprecation warning retained); it does not alter signing/security settings. The first revised run missed Chromium's hidden temporary filename and timed out; corrected matching uses the owned profile directory and exact Spaces basename. Recovery attempts retained an early CDP connection failure and a save refusal while restored tabs were loading. The final resave waits for complete captures. These failures are archived, not counted as passes. Disposable profile/server removed and retained preview tabs unchanged. Evidence: evidence/ui138-spaces-interrupted-write-20261019/.
'''
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+s)
ms=[]
with (d/'evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.suffix=='.dylib':continue
    b=p.read_bytes();t=tarfile.TarInfo(p.name);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n')
for n in ['interrupted-result.json','recovery-result.json','resave-result.json','cleanup.json','invocations.jsonl']:(d/n).write_bytes((r/n).read_bytes())
print(len(ms),'verified members')
