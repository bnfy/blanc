require('node:http').createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end('<title>Mute lifecycle</title><p>local fixture</p>')}).listen(9265,'0.0.0.0');
