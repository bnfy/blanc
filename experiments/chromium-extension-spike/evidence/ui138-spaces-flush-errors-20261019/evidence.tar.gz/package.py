from pathlib import Path
import json,hashlib,tarfile,gzip,io
r=Path('/private/tmp/blanc-spaces-flush');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-flush-errors-20261019';d.mkdir(parents=True,exist_ok=True)
rows=[]
for m in ['backup-flush','primary-flush','backup-rename','primary-rename']:
 p=json.loads((r/(m+'.json')).read_text());assert p['pass'];rows.append({'mode':m,'pass':True,'marker':p['marker'],'reported_error':p['failed']['spaceAutosaveError']})
(d/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
s='''## Spaces flush and rename failure recovery — October 19, 2026

Four controlled native failure cases pass: backup and primary flush failures, plus backup and primary rename failures. On macOS Chromium tries F_BARRIERFSYNC before fsync; archived operation events prove both returned EIO in each flush case. Rename cases return EIO only for the exact owned Spaces destination. Browser PID and file paths are verified. Injection is restricted to disposable profiles; no filesystem or signing settings were changed.

Each case preserves the complete primary, reports the checkpoint or primary-write error, and stops autosave while errored. Backup failures retain the previous checkpoint; primary failures retain the previous primary in the new checkpoint. Removing injection and explicitly saving clears the error and persists the unsaved navigation; a later navigation autosaves successfully. All four passed on their first attempt. No product fix was needed.

These are injected syscall-return failures, not actual hardware flush failure, power-loss, physical media durability, permissions exhaustion or concurrent-writer qualification. Test-helper syscall deprecation warnings retained. Four owned profiles/servers removed; retained preview untouched, host unavailable so original-tab identity not reverified. No Chromium compile; guard zero/3.52s; footprint unchanged from measured41files/100hunks. Native input pending, latency deferred, Electron diagnostic build unapproved. Plan item4 and broader gates remain open. Evidence: evidence/ui138-spaces-flush-errors-20261019/.
''' 
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+s)
ms=[]
with (d/'evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.suffix=='.dylib':continue
    b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members')
