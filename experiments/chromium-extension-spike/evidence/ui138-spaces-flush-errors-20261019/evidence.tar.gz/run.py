import subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-spaces-flush')
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True)
for m in ['backup-flush','primary-flush','backup-rename','primary-rename']:
 for n in ['arm','error.json','events.jsonl']:(r/n).unlink(missing_ok=True)
 run(m+'-start','node',str(r/'start.mjs'));run(m+'-check','node',str(r/'check.mjs'),m);run(m+'-cleanup','node',str(r/'cleanup.mjs'));(r/(m+'-cleanup.json')).write_bytes((r/'cleanup.json').read_bytes())
