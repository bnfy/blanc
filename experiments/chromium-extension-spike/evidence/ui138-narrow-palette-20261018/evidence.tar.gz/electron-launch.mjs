import fs from 'node:fs';import {spawn} from 'node:child_process';
const root='/private/tmp/blanc-ui138-narrow';const profile=root+'/electron-profile';fs.mkdirSync(profile,{recursive:true});
const urls=['http://127.0.0.1:9263/Pinned-two','http://127.0.0.1:9263/Pinned-one','blanc://newtab/','http://127.0.0.1:9263/Beta','http://127.0.0.1:9263/Alpha'];
const groups=[{id:'research',name:'Research',collapsed:false}];const groupIds=[null,null,null,'research','research'];const pinned=[true,true,false,false,false];const entry={id:'primary',profileId:'default',workspaceId:null,urls,activeIndex:3,groups,groupIds,pinned,meta:urls.map(u=>({title:u.split('/').pop(),favicon:null}))};
fs.writeFileSync(profile+'/settings.json',JSON.stringify({onboardingVersion:1,migrationChecklistDismissed:true,searchSuggestions:false,usagePing:false,theme:'light',tabSleep:'off',presentationDefaultsResetVersion:1,tabLayout:'vertical',verticalTabsWidth:248}));
fs.writeFileSync(profile+'/session.json',JSON.stringify({version:2,activeWindowId:'primary',windows:[entry],...entry}));
const log=fs.openSync(root+'/electron.log','a');const p=spawn('/Applications/Blanc.app/Contents/MacOS/Blanc',[`--user-data-dir=${profile}`,'--remote-debugging-port=9256'],{detached:true,stdio:['ignore',log,log]});p.unref();fs.writeFileSync(root+'/electron.pid',String(p.pid));
