from pathlib import Path
import json,hashlib,tarfile,gzip,io
r=Path('/private/tmp/blanc-spaces-concurrent');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-concurrent-20261019';d.mkdir(parents=True,exist_ok=True)
rows=[json.loads((r/n).read_text()) for n in ['result.json','recovery.json']];assert all(x['pass'] for x in rows)
(d/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
s='''## Spaces concurrent windows and switch-read interruption — October 19, 2026

Controlled same-profile, two-window checks pass: a blocked native save keeps the profile busy and refuses the other window's save; after release, retry succeeds and all A/B/C records remain. A foreign window cannot save over the actively owned A name. During a blocked switch read, changing the source navigation causes the switch to reject with tabs unchanged, preserving the changed source instead of installing the destination.

A subsequent switch was stopped during its real stdio disk read, before UI tab staging. The harness verified the exact browser PID/file marker and killed only the disposable browser. Disk records remained unchanged; restart without injection reopened both the saved source and destination and saved again. Four live assertions plus restart/reopen/resave pass. This is same-browser window serialization and pre-dispatch crash recovery, not independent browser processes writing one profile, crash during tab staging/removal, rollback of a partially changed UI, or arbitrary concurrent external writers. Those remain gaps.

Initial helper interposed read but missed stdio's internal path; timed-out attempt retained. Corrected fread interposition reached the real read, and all final checks passed. No product changes/native compile; guard zero/3.60s; footprint unchanged from measured41files/100hunks. Owned profile/server removed; retained preview untouched, host unavailable so original-tab identity not reverified. Native input pending, latency deferred, Electron diagnostic build unapproved. Plan item4 remains incomplete. Evidence: evidence/ui138-spaces-concurrent-20261019/.
''' 
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+s)
ms=[]
with (d/'evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.suffix=='.dylib':continue
    b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members')
