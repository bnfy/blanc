#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static size_t hook(void*b,size_t size,size_t n,FILE*stream){size_t got=fread(b,size,n,stream);int f=fileno(stream);const char*r=getenv("BLANC_SPACE_WRITE_BARRIER");char path[4096],want[4096],arm[4096],release[4096],marker[4096],msg[4600];if(!r||got<=0||fcntl(f,F_GETPATH,path))return got;snprintf(want,sizeof(want),"%s/chromium-profile/Default/BlancPrototypeSpaces.json",r);snprintf(arm,sizeof(arm),"%s/arm",r);if(strcmp(path,want)||unlink(arm))return got;snprintf(marker,sizeof(marker),"%s/barrier.json",r);int out=open(marker,O_CREAT|O_TRUNC|O_WRONLY,0600);int len=snprintf(msg,sizeof(msg),"{\"pid\":%d,\"path\":\"%s\",\"bytes\":%zd}",getpid(),path,got);if(out>=0){syscall(SYS_write,out,msg,len);close(out);}snprintf(release,sizeof(release),"%s/release",r);time_t end=time(NULL)+30;while(access(release,F_OK)&&time(NULL)<end)usleep(10000);return got;}
__attribute__((used,section("__DATA,__interpose")))static struct{const void*a;const void*b;}i={(void*)hook,(void*)fread};
