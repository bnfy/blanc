# Prerender synchronous binder diagnosis and bounded mitigation

Pinned Chromium 157.0.8103.6:
- content/browser/mojo_binder_policy_applier.cc documents the known deadlock risk
  for synchronous interfaces under kDefer (its initial TODO proposes kCancel).
- The unlisted Blanc DocumentStart non-associated interface inherited that default.
  native/blocker/document_start_renderer.inc synchronously calls GetScript before
  page scripts, and Complete after synchronous execution.
- Raw01 fetched the speculation fixture but no matching target was observable.
  Raw02 also enabled discovery, then a renderer-initiated location change via an
  actual extension injection failed to return within the CDP bound. No hidden
  renderer attachment or forced feature flag was used. Those timeouts alone are
  not proof of a particular stack; the source audit and changed-policy control
  distinguish the default deferral from the new explicit cancellation behavior.
- content/browser/devtools/render_frame_devtools_agent_host.cc AddAllAgentHosts
  walks the primary frame tree. Absence from Target.getTargets cannot by itself
  prove that a prerender never existed.
- content/browser/preloading/prerender/prerender_final_status.h names status11
  kMojoBinderPolicy. The verifier requires a SpeculationRule final-status sample
  at that enum, normal-load activation values and first-inline scriptlet success.

Policy choice: the existing chrome_content_browser_client.cc hook delegates to
Blanc-owned SetDocumentStartPrerenderPolicy. Only when the experimental document
start switch is enabled, this exact interface is kCancel. No interface is granted
new prerender capability; no synchronous gate is skipped. The active navigation
still runs the authenticated gate. This mitigates the hang and intentionally
leaves real prerender support unqualified. A safe prerender-capable gate requires
separate lifecycle/selection/permission/side-effect review, not changing kCancel
to kGrant simply to get an activation pass. Existing upstream path budget stays
40; this adds one hunk (92 total). No GN/toolchain/output changes.

Lifecycle leases: diagnostic component adds only a module export to start.js,
pointing at the actual upstream API wrapper, shared barrier and reload guard.
An authored response stalls document_end. Reload is held with one real lease;
removing the iframe or crashing its renderer settles the real API, retires the
lease, and completes reload. The surviving/recovered main DOM stays clean.
This does not qualify a crash inside native synchronous execution, lost native
acknowledgements, background recreation, asynchronous side effects or private
uBO (which remains disabled). No timing thresholds are applied. Browser UMA
histograms are captured as diagnostic status evidence, not latency qualification.
