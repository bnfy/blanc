from pathlib import Path
import json,hashlib,tarfile,io
repo=Path.cwd();base=repo/'experiments/chromium-extension-spike';out=base/'evidence/f12-prerender-recovery-20261018';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
roots=[('raw%02d'%i,Path('/private/tmp/blanc-prerender-followup%02d'%i)) for i in range(1,4)]+[('leases%02d'%i,Path('/private/tmp/blanc-lifecycle-leases%02d'%i)) for i in range(1,4)]+[('lifecycle',Path('/private/tmp/blanc-prerender-lifecycle-regression')),('renderer',Path('/private/tmp/blanc-prerender-renderer-regression')),('checks',Path('/private/tmp/blanc-prerender-followup-build'))]
for label,root in roots:
 for p in root.rglob('*'):
  if p.is_file():files[label+'/'+str(p.relative_to(root))]=p
for n in ['prerender-raw-run.mjs','lifecycle-leases-run.mjs','lifecycle-followup-verify.mjs','lifecycle-followup-test.mjs','lifecycle-run.mjs','lifecycle-verify.mjs','renderer-target-run.mjs','renderer-target-verify.mjs','session.mjs','transport.mjs']:
 files['sources/'+n]=base/'fixtures/replay/synthetic'/n
for n in ['prepare.mjs','blocker_proxy.cc','blocker_proxy.h','document_start.inc','document_start_renderer.inc']:
 files['native/'+n]=base/'native/blocker'/n
old=json.loads((base/'evidence/f12-renderer-target-20261018/binary-hashes.json').read_text())
for item in old['files']:item['sha256']=sha(Path(item['path']));item['bytes']=Path(item['path']).stat().st_size
old['nativeBuild']=True;old.pop('unchangedFrom',None);(out/'binary-hashes.json').write_text(json.dumps(old,indent=2)+'\n')
prior=json.loads((base/'evidence/f12-renderer-target-20261018/inventory.json').read_text());root=Path('/private/tmp/blanc-renderer-target-payload');actual={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};assert actual==prior['payloadFiles']['ordinary']
(out/'payload-reference.json').write_text(json.dumps({'evidence':'../f12-renderer-target-20261018','archiveSha256':prior['archiveSha256'],'payload':'ordinary','files':actual,'diagnosticDelta':'leases03/diagnostic-start.js replaces js/start.js; GPL license included'},indent=2)+'\n')
archive=out/'record.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):
  data=p.read_bytes();assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in data
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;t.addfile(item,io.BytesIO(data))
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in files.items()}
with tarfile.open(archive) as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
(out/'inventory.json').write_text(json.dumps({'archiveSha256':sha(archive),'members':manifest},indent=2)+'\n')
print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'verified':True}))
