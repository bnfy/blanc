import os,subprocess,pathlib,shutil
r=pathlib.Path('/private/tmp/blanc-window-boundaries')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
shutil.copyfile(r/'duplicate.json',r/'duplicate-diagnostic-binary.json')
run('normal-duplicate-suite','python3',str(r/'duplicate-suite.py'))
run('smoke-start','node',str(r/'start.mjs'));run('smoke-seed','node',str(r/'check.mjs'),'seed');run('smoke-check','node',str(r/'smoke.mjs'),'smoke');run('smoke-cleanup','node',str(r/'cleanup.mjs'))
run('guard','node','experiments/chromium-extension-spike/build.mjs','/Users/anthonyjloria/Projects/BlancChromium157/src','--check')
