import os,subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-window-boundaries')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
run('duplicate-start','node',str(r/'start.mjs'));run('duplicate-seed','node',str(r/'check.mjs'),'seed');run('duplicate-stop','node',str(r/'stop.mjs'))
run('duplicate-mutate','node',str(r/'duplicate-mutate.mjs'));run('duplicate-launch','node',str(r/'launch.mjs'),env={**os.environ,'RESTORE':'1'});run('duplicate-check','node',str(r/'duplicate-check.mjs'));run('duplicate-cleanup','node',str(r/'cleanup.mjs'))
