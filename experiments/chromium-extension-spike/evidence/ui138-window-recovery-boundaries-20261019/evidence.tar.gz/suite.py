import os,subprocess,pathlib,json,shutil
r=pathlib.Path('/private/tmp/blanc-window-boundaries')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
for mode in ['stage-first','stage-all','remove-first','remove-all']:
 run(mode+'-start','node',str(r/'start.mjs'));run(mode+'-seed','node',str(r/'check.mjs'),'seed');run(mode+'-stop','node',str(r/'stop.mjs'))
 env={**os.environ,'RESTORE':'1','SPACES_CRASH_MODE':mode}
 run(mode+'-launch','node',str(r/'launch.mjs'),env=env);run(mode+'-crash','node',str(r/'check.mjs'),'crash',env=env)
 run(mode+'-restart','node',str(r/'launch.mjs'),env={**os.environ,'RESTORE':'1'});run(mode+'-recover','node',str(r/'check.mjs'),'recover')
 for n in ['seed','crash','recover']:shutil.copyfile(r/(n+'.json'),r/(mode+'-'+n+'.json'))
 run(mode+'-cleanup','node',str(r/'cleanup.mjs'))
