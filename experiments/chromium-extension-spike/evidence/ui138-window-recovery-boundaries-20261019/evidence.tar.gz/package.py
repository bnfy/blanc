from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-window-boundaries');b=Path('experiments/chromium-extension-spike');d=b/'evidence/ui138-window-recovery-boundaries-20261019';d.mkdir(parents=True,exist_ok=True)
results={}
for mode in ['stage-first','stage-all','remove-first','remove-all']:
 x=json.loads((r/(mode+'-crash.json')).read_text());y=json.loads((r/(mode+'-recover.json')).read_text());assert x['pass'] and y['pass'];results[mode]={'pass':True,'crash_marker':x['marker'],'journal_cleared':y['journalCleared']}
for mode in ['duplicate','smoke']:
 x=json.loads((r/(mode+'.json')).read_text());assert x['pass'];results[mode]={'pass':True}
assert (b/'native/blanc_prototype_ui.cc').read_bytes()==(r/'normal.cc').read_bytes()
assert 'Dry-run scheduled actions: 0' in (r/'guard.log').read_text()
rows=[json.loads(s) for s in (r/'invocations.jsonl').read_text().splitlines()];builds={x['name']:round(x['seconds'],2) for x in rows if x['name'] in ['diagnostic-build','normal-build','guard']}
s=f'''## Window identity and recovery boundaries — October 19, 2026

Four actual abrupt exits pass with version-2 durable identity journals: after the first destination tab, all destination tabs, first actual source removal and all source removals. Temporary profile-scoped native diagnostics record live URLs at each boundary (3,4,3,2 tabs respectively) and exit86. After real Chromium session restoration, only the matching source UUID is recovered automatically, both saved records remain byte-equivalent as parsed JSON, the unrelated window retains its UUID/content, and the journal clears. This extends the prior before-staging journal-write crash proof; it does not prove every interleaving or power-loss durability.

With the owned browser stopped, the duplicate-identity harness replaces the second window UUID with the first in both plaintext and mock-keychain-encrypted Session records. No real keychain/profile is accessed. A synthetic valid v2 intent then targets that duplicated UUID. Both restored windows expose the duplicate, recovery reports no unique match, both window contents and saved records remain unchanged, and the journal remains. Repeated on the restored normal binary. This proves bounded duplicate persisted identity refusal, not late-arriving duplicate ownership or malformed-record handling.

All four crash cases, normal-binary duplicate refusal and normal A→B→A switching with explicit completed saves pass. The initial immediate B→A attempt was refused by the complete-saved-window guard; that failure is retained. A second snapshot sampled one source-removal callback before completion; final verification waits for the journal acknowledgement and exact final tab count. Both attempts are retained. Immediate reverse-switch acceptance is not claimed. Native diagnostics removed byte-for-byte; normal binary rebuilt and tested. Two guarded incremental builds only: diagnostic wrapper {builds['diagnostic-build']}s and normal restore {builds['normal-build']}s. Final zero-action guard {builds['guard']}s. Product source unchanged from536e33bd; prior measured44files/107hunks within44/120 remains unchanged, not re-enumerated. Test profiles/server removed; retained preview untouched, host unavailable so original tabs not reverified.

Remaining: metadata save acknowledgement/crash before identity persistence, late or overlapping session restores, malformed persisted identities, crash during v2 recovery itself, groups/pins/unsaved page state across these exact boundaries, arbitrary interleavings and power-loss/deletion durability. Full multiwindow recovery acceptance and public Spaces controls remain open. Native input pending, latency deferred, Electron diagnostic build unapproved. Other Task0/F12 gates unchanged. Routine evidence/testing only; cold-build ledger unchanged.

Evidence: `evidence/ui138-window-recovery-boundaries-20261019/`.
'''
(d/'README.md').write_text(s);(d/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for n in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 with(b/n).open('a')as f:f.write('\n'+s)
ms=[]
with(d/'evidence.tar.gz').open('wb')as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.name=='normal.cc':continue
    data=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data));ms.append(dict(path=p.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(d/'evidence.tar.gz')as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members',builds)
