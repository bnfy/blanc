from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-spaces-exit'); d=Path('experiments/chromium-extension-spike/evidence/ui138-spaces-exit-20261019');d.mkdir(parents=True,exist_ok=True)
s='''## Spaces exit flush and interrupted-write investigation — October 19, 2026

Spaces captures a complete bound snapshot during Chromium's WillCloseAllTabs notification, before tab removal, and queues a value-owned save on the existing BLOCK_SHUTDOWN sequenced runner. Private, incomplete, loading, split, beforeunload-sensitive or error-stopped captures remain excluded. This is a bounded normal-close flush, not a guarantee for every shutdown path.

The real normal-exit test passed: the latest navigation was absent from the primary before Browser.close and present after process exit. Normal restart retained that snapshot. A separately authored partial temporary file did not affect the validated primary or list result. Four capture tests pass. The injected write-barrier attempt failed to start a usable browser and timed out before reaching the write; its script, helper source and failed result are retained. No actual mid-write interruption, power-loss durability or interrupted backup replacement is claimed. The synthetic temporary-file probe is not a substitute for those checks. No security settings or signatures were changed to force injection.

One incremental build passed:34.94s Siso,40.92s wrapper; prepare1.81s. Final guard zero actions/3.55s. Footprint recorded in patch-budget.json. Owned test profile/server removed and retained preview tabs preserved. Native input, latency and the Electron diagnostic build remain pending/deferred; plan item4 and broader recovery/ownership/switch-transaction gates remain open. Evidence: evidence/ui138-spaces-exit-20261019/.
'''
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 p=Path('experiments/chromium-extension-spike')/n
 with p.open('a') as f:f.write('\n'+s)
(d/'README.md').write_text(s)
