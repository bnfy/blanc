#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
static ssize_t barrier_write(int fd, const void *bytes, size_t count) {
  ssize_t (*real_write)(int,const void*,size_t)=dlsym(RTLD_NEXT,"write");
  const char *root=getenv("BLANC_SPACE_WRITE_BARRIER");
  char path[4096], expected[4096], arm[4096], marker[4096], release[4096];
  if (!root || count<4 || fcntl(fd,F_GETPATH,path)!=0) return real_write(fd,bytes,count);
  snprintf(expected,sizeof(expected),"%s/chromium-profile/Default/BlancPrototypeSpaces.json",root);
  snprintf(arm,sizeof(arm),"%s/arm",root);
  if (strncmp(path,expected,strlen(expected)) || strstr(path,".backup") || access(arm,F_OK)) return real_write(fd,bytes,count);
  // Consume one arm file. Only this disposable store's next primary temp write.
  if (unlink(arm)) return real_write(fd,bytes,count);
  ssize_t written=real_write(fd,bytes,count/2);
  snprintf(marker,sizeof(marker),"%s/barrier.json",root);
  snprintf(release,sizeof(release),"%s/release",root);
  int out=open(marker,O_CREAT|O_WRONLY|O_TRUNC,0600);
  char event[4600];int n=snprintf(event,sizeof(event),"{\"pid\":%d,\"path\":\"%s\",\"requested\":%zu,\"written\":%zd}\n",getpid(),path,count,written);
  if(out>=0){real_write(out,event,n);fsync(out);close(out);}
  const time_t until=time(NULL)+30;
  while(access(release,F_OK) && time(NULL)<until) usleep(10000);
  return written;
}
__attribute__((used)) static struct { const void *replacement; const void *replacee; } interpose
__attribute__((section("__DATA,__interpose"))) = {(const void*)barrier_write,(const void*)write};
