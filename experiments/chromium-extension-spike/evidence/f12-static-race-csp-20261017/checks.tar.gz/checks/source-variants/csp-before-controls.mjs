// Actual provider delivery under authored document policies. No injected payload.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';
import {openSession,until,pause} from './session.mjs';import {startSynthetic} from './transport.mjs';import {createCertificateSet} from './certificate-set.mjs';import {sha} from './generate.mjs';
const [configFile,payload,evidence]=process.argv.slice(2),config=JSON.parse(fs.readFileSync(configFile));assert(!fs.existsSync(evidence));fs.mkdirSync(evidence);
const host='https://page.blanc-fixture.test',filters='page.blanc-fixture.test##+js(set-constant, cspFlag, true)';
const policies=[['inline',"script-src 'unsafe-inline'"],['nonce',"script-src 'nonce-fixture'"],['none',"script-src 'none'"],['trusted-types',"require-trusted-types-for 'script'; trusted-types 'none'"],['nonce-trusted-types',"script-src 'nonce-fixture'; require-trusted-types-for 'script'; trusted-types 'none'"]];
const fixtures=new Map([[host+'/csp',{status:200,contentType:'text/html',body:'<!doctype html><link rel="icon" href="data:,"><body>authored CSP parent'}],[host+'/favicon.ico',{status:204,contentType:'image/x-icon',body:''}]]);
const bodies=Object.fromEntries(policies.map(([name,policy])=>[name,`<!doctype html><meta http-equiv="Content-Security-Policy" content="${policy}"><script nonce="fixture">window.first={flag:window.cspFlag===true,origin:window.origin};window.violations=[];addEventListener('securitypolicyviolation',e=>violations.push({directive:e.effectiveDirective,blocked:e.blockedURI,policy:e.originalPolicy}));</script><div id="ready">authored CSP fixture</div>`]));
const root=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'blanc-static-csp-'))),certificates=createCertificateSet(path.join(root,'certificates'),[new URL(host).hostname]),replay=await startSynthetic({fixtures,tlsMaterial:certificates});
const report={completed:false,diagnosticScheduling:false,latencyMeasured:false,checks:[],sources:{},errors:[],console:[]};for(const n of ['static-csp-run.mjs','session.mjs'])report.sources[n]=sha(fs.readFileSync(new URL(n,import.meta.url)));
fs.writeFileSync(path.join(evidence,'fixtures.json'),JSON.stringify({fixtures:[...fixtures],bodies,filters,policies},null,2));let session;
try{
 session=await openSession({config,browserKind:'chromium',kind:'regular',label:'csp',root,transport:replay,certificates,provider:'ublock-origin',uboPayload:payload});report.source=session.source;await session.uboConfigure();await session.uboSetFilters(filters);
 const popup=session.page.context().pages().find(p=>p.url().includes('/popup-fenix.html'));assert(popup);let currentCase='setup';
 session.page.on('pageerror',e=>report.errors.push({case:currentCase,error:String(e)}));session.page.on('console',m=>{if(m.type()==='error')report.console.push({case:currentCase,text:m.text()});});
 for(const mode of ['srcdoc','data','blob'])for(const [name,policy] of policies){
  currentCase=mode+':'+name;await session.page.goto(host+'/csp');await popup.evaluate(()=>{chrome.extension.getBackgroundPage().__blancStaticRows.length=0;});
  await session.page.evaluate(({mode,body})=>{const f=document.createElement('iframe');f.id='probe';if(mode==='srcdoc'){f.sandbox='allow-scripts';f.srcdoc=body;}else if(mode==='data')f.src='data:text/html,'+encodeURIComponent(body);else f.src=URL.createObjectURL(new Blob([body],{type:'text/html'}));document.body.append(f);},{mode,body:bodies[name]});
  const frame=await (await session.page.$('#probe')).contentFrame();await frame.waitForSelector('#ready');
  await until(()=>popup.evaluate(()=>chrome.extension.getBackgroundPage().__blancStaticRows.some(r=>'replied' in r)));await pause(200);
  const snapshot=await frame.evaluate(()=>({first:window.first??null,flag:window.cspFlag===true,counts:window.__blancScriptletGateCounts,origin:window.origin,url:location.href,policy:document.querySelector('meta')?.content,violations:window.violations??null}));
  const messages=await popup.evaluate(()=>chrome.extension.getBackgroundPage().__blancStaticRows);
  report.checks.push({mode,name,policy,snapshot,messages});assert.equal(snapshot.policy,policy);assert(snapshot.flag);assert.equal(snapshot.counts.bodies,1);assert.equal(messages.length,1);assert(messages[0].replied);
 }
 report.completed=true;
}catch(error){report.error=String(error);process.exitCode=1;}finally{if(session){report.records=session.records();await session.close();}report.arrivals=replay.arrivals;report.faults=replay.faults;await replay.close();fs.rmSync(root,{recursive:true,force:true});report.cleanup={removed:!fs.existsSync(root)};fs.writeFileSync(path.join(evidence,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({completed:report.completed,cases:report.checks.length,error:report.error}));}
