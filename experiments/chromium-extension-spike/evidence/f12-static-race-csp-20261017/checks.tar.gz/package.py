from pathlib import Path
import tarfile,gzip,io,json,hashlib,shutil,subprocess
repo=Path('/private/tmp/blanc-chromium157-work');r=repo/'experiments/chromium-extension-spike';e=r/'evidence/f12-static-race-csp-20261017';b=Path('/private/tmp/blanc-static-race-build');rows=[]
def archive(name,items):
 members=[]
 with (e/name).open('wb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
   with tarfile.open(fileobj=gz,mode='w') as t:
    for p,arc in sorted(items,key=lambda x:x[1]):
     assert p.is_file() and not p.is_symlink();d=p.read_bytes();assert b'-----BEGIN PRIVATE KEY-----\n' not in d;info=tarfile.TarInfo(arc);info.size=len(d);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(d));members.append(dict(path=arc,bytes=len(d),sha256=hashlib.sha256(d).hexdigest()))
 rows.append(dict(file=name,bytes=(e/name).stat().st_size,sha256=hashlib.sha256((e/name).read_bytes()).hexdigest(),members=members))
def tree(root,prefix):return [(p,prefix+'/'+str(p.relative_to(root))) for p in root.rglob('*') if p.is_file()]
runtime=[]
for name in ['blanc-static-race-before-run','blanc-static-race-fixed-run','blanc-static-race-final-run','blanc-static-race-final02','blanc-static-csp-run01','blanc-static-csp-run02','blanc-static-csp-final','blanc-static-csp-final02','blanc-static-race-integration']:
 root=Path('/private/tmp')/name;assert json.loads((root/'report.json').read_text())['cleanup']['removed'];runtime+=tree(root,name)
archive('runtime.tar.gz',runtime)
sources=[]
for p in r.rglob('*'):
 rel=p.relative_to(r)
 if p.is_file() and 'evidence' not in rel.parts and 'generated' not in rel.parts and (p.suffix in ['.mjs','.cjs','.js','.cc','.h','.inc','.mojom','.py'] or p.name=='BUILD.gn'):sources.append((p,str(p.relative_to(repo))))
archive('sources.tar.gz',sources)
pin=json.loads((repo/'ublock/pinned.json').read_text());original={x['path']:x['sha256'] for x in pin['files']};payloaditems=[(repo/'ublock/pinned.json','pinned.json')];inventory={}
for dirname,alias in [('blanc-ubo-static-integrated-payload','baseline'),('blanc-static-race-before-payload','diagnostic-before'),('blanc-static-race-fixed-payload','fixed'),('blanc-static-race-fixed-diagnostic','diagnostic-fixed'),('blanc-static-race-final-payload','final'),('blanc-static-race-final-diagnostic','diagnostic-final')]:
 root=Path('/private/tmp')/dirname;inventory[alias]=[]
 for p in root.rglob('*'):
  if not p.is_file():continue
  rel=str(p.relative_to(root));h=hashlib.sha256(p.read_bytes()).hexdigest();changed=h!=original.get(rel);inventory[alias].append(dict(path=rel,sha256=h,changedOrNew=changed))
  if changed or rel=='LICENSE.txt':payloaditems.append((p,alias+'/'+rel))
(b/'payload-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n');payloaditems.append((b/'payload-inventory.json','payload-inventory.json'));archive('payload-delta.tar.gz',payloaditems)
binaries=json.loads(Path('/private/tmp/blanc-static-integration-build/binary-hashes.json').read_text())
for x in binaries:
 p=Path(x['path']);assert p.stat().st_size==x['bytes'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
(b/'binary-hashes.json').write_text(json.dumps({'unchangedFrom32790e0b':True,'files':binaries},indent=2)+'\n')
archive('checks.tar.gz',tree(b,'checks')+[(Path(__file__),'package.py')])
for name in ['race-proof.json','csp-proof.json','baseline-proof.json','fixed-guard-proof.json','integration-proof.json','cleanup.json','invocations.jsonl','binary-hashes.json']:shutil.copyfile(b/name,e/name)
(e/'archives.json').write_text(json.dumps(rows,indent=2)+'\n')
extract=Path('/private/tmp/blanc-static-race-verified');extract.mkdir(exist_ok=False)
for row in rows:
 with tarfile.open(e/row['file'],'r:gz') as t:
  assert t.getnames()==[m['path'] for m in row['members']]
  for m in row['members']:
   d=t.extractfile(m['path']).read();assert hashlib.sha256(d).hexdigest()==m['sha256'];target=extract/m['path'];assert target.is_relative_to(extract);target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(d)
for name,proof,script,args in [('blanc-static-race-final02','race-proof.json','static-race-verify.mjs',[]),('blanc-static-csp-final02','csp-proof.json','static-csp-verify.mjs',[]),('blanc-static-race-before-run','baseline-proof.json','static-race-verify.mjs',['--baseline','--guard-only']),('blanc-static-race-fixed-run','fixed-guard-proof.json','static-race-verify.mjs',['--guard-only']),('blanc-static-race-integration','integration-proof.json','static-integration-verify.mjs',[])]:
 source=extract/'experiments/chromium-extension-spike/fixtures/replay/synthetic'/script
 result=json.loads(subprocess.check_output(['node',str(source),str(extract/name),*args]));assert result==json.loads((e/proof).read_text())
summary=dict(verified=True,archives=len(rows),members=sum(len(a['members']) for a in rows),compressedBytes=sum(a['bytes'] for a in rows),extractedProofsVerified=5)
(e/'archive-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
