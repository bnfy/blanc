from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-recovery-repeat');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-recovery-repeat-20261019'
for n in ['seed','clean-restored','automatic-restored','entry-restored-round1','entry-restored-round2','final','final-log-check']:assert json.loads((r/(n+'.json')).read_text())['pass'],n
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved']
assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-anchor-fix/binary-hashes.json').read_text())
(r/'guard.log').write_bytes(Path('/private/tmp/blanc-anchor-fix/repeat-guard.log').read_bytes())
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
(r/'limitations.json').write_text(json.dumps({'failedAttempts':['Initial bubble histogram absent: automatic restore observed after SIGKILL; previous disk exit marker unmeasured, persistence timing suspected not proven','CDP fetch before listener ready; fixed readiness polling','Expected no bubble after clean close failed: unresolved recovery decision offered again; no dismissal action tested'],'nativeInput':'pending unlock','latency':'deferred','electronDiagnosticBuild':'unapproved/unstarted','productionChanges':False,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2))
files=[p for p in r.iterdir() if p.is_file() and (p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.pdf'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 repeated recovery/lifecycle checks

Two same-profile crash/recovery rounds survive with Chromium's recovery-bubble SHOWN histogram.
Saved windows restored through the existing Recently Closed bridge contain the regular protected
PDF and exclude the private PDF. Both rounds re-prompt with an empty password field and return
two matches after re-entry; no positive pre-unlock matches were observed. These are bridge tests,
not activation of the native recovery button. Owned PID/command and persisted Crashed marker
are checked before subsequent kills. A third crash relaunch also shows the bubble successfully.

Closing the browser while the recovery decision is unresolved and restarting offers the bubble
again. The original assertion expecting no bubble failed and is retained as a harness assumption;
no dismiss/Restore choice was exercised. Three private PDF context creation/disposal cycles pass
without removing existing regular targets. Final orderly shutdown logs no fatal/dangling pointer.
Normal session restoration also passes again. An initial SIGKILL run automatically restored the
PDF and re-prompted, but its prior disk exit marker was not captured: suspected persistence timing
is not proven. Histogram/CDP readiness failures remain in invocation records; subsequent probes
poll readiness explicitly. No general crash policy or password-storage security claim.

Evidence-only: no production changes or compilation. Guard zero actions in5.61s; native hashes
unchanged. Footprint remains40files/97hunks, not re-enumerated. Disposable profile/server removed;
original preview New Tab/Web Store tabs preserved with empty status. Native recovery buttons,
focus/visual placement and physical input remain pending unlock. Latency deferred; Electron
diagnostic build unapproved/unstarted. Wider lifecycle/corrupt-session/OS restart behavior and
prior F12/Task0 gates remain open; plan item4 incomplete.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed archive members; profiles/raw browser logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-recovery-repeat-20261019/`. No cold-build cost change.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-recovery-repeat-20261019/`.\n'+s[i:]);print(len(m),'verified members')
