import subprocess,pathlib,json
r=pathlib.Path('/private/tmp/blanc-spaces-auto')
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True)
records=json.loads((r/'remove-all-crash.json').read_text())['before'];print(records.keys())
items=records['spaces'] if 'spaces' in records else records['items']
for m in ['malformed','unrelated']:
 d=r/'chromium-profile/Default';d.mkdir(parents=True,exist_ok=True)
 intent={'version':1,'id':'00000000-0000-4000-8000-000000000001','source_name':'A','source':items['A'],'destination':items['B']}
 (d/'BlancPrototypeSpaces.json.switch').write_text('{' if m=='malformed' else json.dumps(intent))
 launch=(r/'launch.mjs').read_text();(r/'launch-boundary.mjs').write_text(launch.replace("'chrome://newtab/'","'http://127.0.0.1:9265/unrelated'"))
 start=(r/'start.mjs').read_text();(r/'start-boundary.mjs').write_text(start.replace('launch.mjs','launch-boundary.mjs') if m=='unrelated' else start)
 run(m+'-start','node',str(r/'start-boundary.mjs'));run(m+'-test','node',str(r/'boundary.mjs'),m);run(m+'-cleanup','node',str(r/'cleanup.mjs'))
