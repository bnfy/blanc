import subprocess,pathlib,os
r=pathlib.Path('/private/tmp/blanc-spaces-auto')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
for m in ['stage-first','stage-all','remove-first','remove-all']:
 (r/'crash-marker.json').unlink(missing_ok=True)
 run(m+'-start','node',str(r/'start.mjs'),env={**os.environ,'SPACES_CRASH_MODE':m})
 run(m+'-crash','node',str(r/'check.mjs'),m,'crash')
 run(m+'-restart','node',str(r/'launch.mjs'))
 run(m+'-recover','node',str(r/'check.mjs'),m,'recover')
 run(m+'-cleanup','node',str(r/'cleanup.mjs'))
 (r/(m+'-cleanup.json')).write_bytes((r/'cleanup.json').read_bytes())
