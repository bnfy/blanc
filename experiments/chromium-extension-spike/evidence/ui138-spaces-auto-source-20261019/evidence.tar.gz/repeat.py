import subprocess,pathlib,os,time,json
r=pathlib.Path('/private/tmp/blanc-spaces-auto')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
run('repeat-start','node',str(r/'start.mjs'),env={**os.environ,'SPACES_CRASH_MODE':'stage-first'})
run('repeat-crash','node',str(r/'check.mjs'),'stage-first','crash')
journal=r/'chromium-profile/Default/BlancPrototypeSpaces.json.switch';before=journal.read_bytes();offset=(r/'chromium.log').stat().st_size
run('repeat-recovery-crash-launch','node',str(r/'launch.mjs'),env={**os.environ,'SPACES_CRASH_MODE':'stage-first'})
for i in range(200):
 text=(r/'chromium.log').read_bytes()[offset:].decode(errors='replace');rows=[x for x in text.splitlines() if x.startswith('SPACES_CRASH:')]
 if rows:break
 time.sleep(.1)
else:raise Exception('no recovery crash')
marker=json.loads(rows[-1][13:]);assert marker['source_count']==1 and marker['staged_count']==1
assert journal.read_bytes()==before
time.sleep(.5)
run('repeat-restart','node',str(r/'launch.mjs'))
run('repeat-recover','node',str(r/'check.mjs'),'stage-first','recover')
(r/'repeat.json').write_text(json.dumps({'pass':True,'recovery_crash':marker,'journal_unchanged':True}))
run('repeat-cleanup','node',str(r/'cleanup.mjs'))
