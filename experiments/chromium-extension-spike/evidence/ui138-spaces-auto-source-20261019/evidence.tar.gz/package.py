from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-spaces-auto');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-auto-source-20261019';d.mkdir(parents=True,exist_ok=True)
rows=[]
for mode in ['stage-first','stage-all','remove-first','remove-all']:
 a=json.loads((r/(mode+'-crash.json')).read_text());b=json.loads((r/(mode+'-recover.json')).read_text());assert a['pass'] and b['pass'];rows.append({'mode':mode,'marker':a['marker'],'automatic_source_restored':True,'saved_records_unchanged':True,'journal_cleared':True})
for n in ['normal-smoke','repeat','malformed','unrelated']:assert json.loads((r/(n+'.json')).read_text())['pass']
original=(r/'normal.cc').read_bytes();assert original==(base/'native/blanc_prototype_ui.cc').read_bytes()
(d/'results.json').write_text(json.dumps({'cases':rows,'normal_source_sha256':hashlib.sha256(original).hexdigest(),'repeat_recovery_crash_pass':True,'malformed_and_unrelated_refusal_pass':True,'scope':'sole empty non-session-restored startup window'},indent=2)+'\n')
inv=[json.loads(x) for x in (r/'invocations.jsonl').read_text().splitlines()];builds=[{'name':x['name'],'seconds':round(x['seconds'],2),'exit_code':x['exit_code']}for x in inv if 'build' in x['name']];print(builds)
s='''## Automatic source-Space recovery — October 19, 2026

Owner decision recorded verbatim: **Restore the source Space (recommended)**. A versioned profile-local `.switch` journal is atomically written before staging, with a random transaction ID, named source and validated source/destination captures. The source must equal its durably saved record. Pending intent blocks other saved-Space mutations. Completion waits for the exact new tab IDs and complete capture before removing the journal; a successful switch API callback alone is insufficient.

Four forced exits after first/all destination staging and first/all actual source removal automatically restore the saved source after restart, without an explicit bridge/API reopen. Saved A/B records remain unchanged, and the completed recovery clears the journal. A second crash during first-tab recovery preserves the same journal; the next restart restores exactly one three-tab source set. Malformed intent and a nonempty unrelated startup page retain the journal and leave live content unchanged. Normal A/B switching and four capture-policy tests pass. Temporary crash hooks are removed; the normal binary is rebuilt and smoke-tested.

This is bounded startup recovery into a sole empty, non-session-restored regular window. It checks SessionRestore::IsRestoring before reading and before applying recovery; it does not identify an original window across macOS restarts. Exact restored-window ownership, in-flight/multiwindow session-restore races and private-runtime recovery still need qualification. Ambiguous startup content fails closed and leaves a recovery error/journal; automatic recovery is not complete for those cases. The UI remains hidden. Intent-write/acknowledgement fault injection, crash around journal deletion, group/pin recovery, power-loss durability and unsaved page state remain gaps. Previous generic Spaces write-error tests do not qualify the new journal. Journal deletion is not claimed as power-loss-durable acknowledgement.

Only guarded incremental builds were used; no cold output, args/toolchain changes, latency tests or Electron diagnostic build. Native input remains pending. The production source contains no diagnostic crash hooks. Owned test profiles/servers are removed; retained preview was untouched (host unavailable, original tabs not reverified). Task 0/F12 gates and plan item 4 remain open.

Evidence: `evidence/ui138-spaces-auto-source-20261019/`. Build wrapper timings: BUILD_TIMES. Fresh patch budget: 41 upstream files / 100 hunks. Final zero-action guard is archived. These costs are routine implementation/testing, never the Task 0 cold-build column.
'''.replace('BUILD_TIMES',', '.join(f"{x['name']} {x['seconds']} s" for x in builds))
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md','spaces-automatic-recovery.md']:
 with(base/n).open('a')as f:f.write('\n'+s)
ms=[]
with(d/'evidence.tar.gz').open('wb')as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.name in ['normal.cc','before.cc']:continue
    b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz')as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members')
