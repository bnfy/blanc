import http from 'node:http';import fs from 'node:fs';import assert from 'node:assert/strict';import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const server=http.createServer((req,res)=>{res.setHeader('content-type','text/html');res.end('<title>Blanc UI fixture '+req.url+'</title><button id="pageButton" onclick="this.textContent=\'Clicked\'">Click page</button><input id="typing">');});await new Promise(r=>server.listen(9261,'0.0.0.0',r));
const targets=()=>fetch('http://127.0.0.1:9250/json/list').then(r=>r.json());const h=await connect((await targets()).find(t=>t.url.includes('host.html')));const call=(m,...a)=>h.eval(`BlancPrototypeHost.api[${JSON.stringify(m)}](...${JSON.stringify(a)})`);const snap=async()=>{await h.eval('BlancPrototypeHost.refresh()');await pause(350);return call('getAllTabs');};const proof={};
try {
 await call('setTabLayout','island'); await call('setVerticalTabsWidth',248);
 for (const t of (await snap()).tabs.filter(t=>t.url.startsWith('http://127.0.0.1:9261/')||t.url.startsWith('http://localhost:9261/'))) await call('closeTab',t.id);
 const s0=await snap();proof.initial=s0;
 await call('createTab','http://127.0.0.1:9261/a');await pause(300);let s=await snap();const a=s.activeTabId;
 await call('createTab','http://127.0.0.1:9261/b');await pause(300);s=await snap();const b=s.activeTabId;
 await call('toggleSiteMute',a);s=await snap();assert(s.tabs.filter(t=>[a,b].includes(t.id)).every(t=>t.muted&&t.siteMuted));
 await call('toggleTabMuted',a);s=await snap();assert(!s.tabs.find(t=>t.id===a).muted);assert(s.tabs.find(t=>t.id===b).muted);
 await call('createTab','http://127.0.0.1:9261/c');await pause(300);s=await snap();const c=s.activeTabId;assert(s.tabs.find(t=>t.id===c).muted);
 await call('navigate',a,'http://localhost:9261/d');await pause(400);s=await snap();assert(!s.tabs.find(t=>t.id===a).siteMuted);
 await call('navigate',a,'http://127.0.0.1:9261/e');await pause(400);s=await snap();assert(s.tabs.find(t=>t.id===a).muted);
 await call('toggleSiteMute',b);s=await snap();assert(s.tabs.filter(t=>[a,b,c].includes(t.id)).every(t=>!t.muted));proof.siteMute=true;
 await call('closeTab',b);s=await snap();const entry=s.closed.find(e=>e.url==='http://127.0.0.1:9261/b');assert(entry);await call('reopenClosedEntry',entry.id);await pause(300);s=await snap();assert(s.tabs.some(t=>t.url===entry.url));assert(!s.closed.some(e=>e.id===entry.id));
 await call('closeTab',c);s=await snap();const forget=s.closed.find(e=>e.url==='http://127.0.0.1:9261/c');assert(forget);await call('forgetClosedEntry',forget.id);s=await snap();assert(!s.closed.some(e=>e.id===forget.id));proof.recentlyClosed=true;
 await call('setTabLayout','vertical');await pause(350);s=await snap();assert.equal(s.tabLayout,'vertical');assert.equal(s.verticalTabsWidth,248);
 proof.rail=await h.eval(`({status:document.querySelector('#status').textContent,railHidden:document.querySelector('#strip').contentDocument.querySelector('.vertical-tabs-rail').hidden,height:innerHeight,stripHeight:document.querySelector('#strip').getBoundingClientRect().height})`);assert.equal(proof.rail.railHidden,false);
 const t=(await targets()).find(t=>t.url.startsWith('http://127.0.0.1:9261/')&&t.type==='page');const p=await connect(t);proof.viewport=await p.eval('({width:innerWidth,height:innerHeight,outerWidth})');await call('setVerticalTabsWidth',300);await pause(400);proof.resized=await p.eval('({width:innerWidth,height:innerHeight,outerWidth})');assert.equal(proof.viewport.width-proof.resized.width,52);p.close();proof.pass=true;
} finally {fs.writeFileSync('/private/tmp/blanc-webstore-check/ui-test.json',JSON.stringify(proof,null,2));h.close();server.closeAllConnections();server.close();}
console.log(JSON.stringify(proof,null,2));
