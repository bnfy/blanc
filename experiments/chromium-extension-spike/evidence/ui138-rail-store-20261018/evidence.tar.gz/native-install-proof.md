# Web Store compatibility verification — October 18, 2026 EDT

Built native rule using the existing 157 output. First build failed on Chromium's literal UTF8ToUTF16 static assertion; corrected to a UTF-16 raw literal. Cached incremental continuation succeeded (35.39 s Siso / wrapper recorded in invocation log).

Fresh disposable profile: /private/tmp/blanc-webstore-check/profile, port 9250.
- DOM diagnostic promotion.json: the exact Chrome download material-callout is an ASIDE with display:none; surrounding container remains block. No website storage or UA changed.
- Native computer-use AX check: Store categories and links remain accessible; promotional heading/buttons absent (an empty labelled wrapper remains in AX).
- Native Cmd-L and paste navigated to the official Extensity listing jjmflmamggggndanpgfnpelongoepncg.
- Add to Chrome opened Chromium's native sheet `Add "Extensity"?`, permission `Manage your apps, extensions, and themes`, Cancel and Add extension controls. Add initially disabled for the normal safety delay, then enabled.
- Native click Add extension completed with Chromium window `Extensity has been added to Chromium`.
- This is actual native-input Store installation, not unpacked loading or a mocked permission dialog.

The old UI preview instance (profile /private/tmp/blanc-ui138-build/profile) was gracefully quit via its native app menu to disambiguate same-bundle computer-use targets. Its saved session must be restored after testing. Permanent profiles and 156 were not opened or modified.

Remaining: final UI migration binary regression, restart persistence, cleanup of the disposable install profile. The unrelated detail-page inline Install Chrome banner is outside this popover-specific rule.

## UI migration runtime follow-up
The new UI build compiles (52.70 s Siso). Native bridge fixture tests pass for same-host existing/new-tab mute, per-tab exemption, host-change reset, site unmute, native Recently Closed restore and forget, rail visibility and native width reservation (952 -> 900 pixels for 248 -> 300 rail). The first harness unnecessarily called an unsupported getExtensions method and left a visible status message; this is a harness fault and must be removed before final evidence.
Native computer use on the final UI binary: clicking the fixture page button beside the rail changed its label to `Clicked`; clicking rail `/e` changed the active tab and returned page focus. A splitter click then Right did not change width (300 stayed 300); keyboard resizing is not yet verified.

## Final results
- Keyboard focus traversed page controls, Island controls, rail active row, New Tab and the resize separator. Right on the focused separator changed 300 -> 308 pixels with the announcement and persisted width. The earlier pointer click did not focus it; that was not a keyboard failure.
- Native right-click on the rail opened the tab menu; clicking Mute Site changed both matching rail rows to muted. Clicking a Recently Closed row restored its native tab and closed the Island.
- Private test: regular mute did not mute the private tab; private mute survived regular unmute independently; private Recently Closed stayed empty and reopen returned false.
- Restart: layout vertical and width 308 persisted; site mutes cleared; native closed entries persisted. Forget All cleared native entries. Corrected harness no longer calls unsupported getExtensions; final restarted host status is empty.
- Final UI binary: Store displayed Remove from Chrome after restart, confirming the installed extension persisted. Native Remove confirmation worked, then the disposable app was quit and its profile deleted. Fixture server stopped.
- Original isolated preview relaunched with --restore-last-session. New Tab and the same Chrome Web Store Extensions tab were restored, host status empty; left open. Permanent profiles and 156 untouched.

Scope/gaps: no matched Electron screenshot comparison; full group/window Recently Closed restoration and drag crossing the Recently Closed band not runtime-qualified. Native restore list is profile-wide Chromium history rather than Electron's per-window list. Site mute matches exact host, is private-profile separated, and lasts until profile destruction/browser quit. No new latency measurements. Promotion selector is narrowly tied to Google's current download campaign and may require maintenance; no claim of zero-frame flash before load callbacks. Empty promotion wrapper label remains in AX, and the separate inline Install Chrome banner remains visible. No Electron diagnostic build.
