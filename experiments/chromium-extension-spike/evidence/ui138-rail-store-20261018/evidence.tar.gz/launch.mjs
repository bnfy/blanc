import {spawn} from 'node:child_process'; import fs from 'node:fs';
const c=JSON.parse(fs.readFileSync('/private/tmp/blanc-prerender-followup-build/config.json'));
const log=fs.openSync('/private/tmp/blanc-webstore-check/browser.log','a');
const p=spawn(c.chromium,['--user-data-dir=/private/tmp/blanc-webstore-check/profile','--remote-debugging-port=9250',`--blanc-prototype-assets=${c.ui}`,'--no-first-run','--no-default-browser-check','--use-mock-keychain','--restore-last-session'],{detached:true,stdio:['ignore',log,log]});p.unref();fs.writeFileSync('/private/tmp/blanc-webstore-check/pid',String(p.pid));
