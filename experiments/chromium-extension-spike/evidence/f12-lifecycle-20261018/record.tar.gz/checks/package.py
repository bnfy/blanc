from pathlib import Path
import hashlib,json,tarfile,io
repo=Path.cwd();base=repo/'experiments/chromium-extension-spike';out=base/'evidence/f12-lifecycle-20261018';out.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
roots=[('lifecycle%02d'%i,Path('/private/tmp/blanc-lifecycle-run%02d'%i)) for i in range(1,7)]+[('prerender-raw%02d'%i,Path('/private/tmp/blanc-prerender-raw%02d'%i)) for i in range(1,5)]+[('checks',Path('/private/tmp/blanc-lifecycle-build'))]
for label,root in roots:
 if not root.exists():continue
 for p in root.rglob('*'):
  if p.is_file() and p.name!='processes.log':files[label+'/'+str(p.relative_to(root))]=p
for name in ['lifecycle-run.mjs','lifecycle-test.mjs','lifecycle-verify.mjs','prerender-raw-run.mjs','session.mjs','transport.mjs','transport-test.mjs']:
 files['sources/'+name]=base/'fixtures/replay/synthetic'/name
old=json.loads((base/'evidence/f12-renderer-target-20261018/binary-hashes.json').read_text())
for item in old['files']:assert digest(Path(item['path']))==item['sha256'],item['path']
old['nativeBuild']=False;old['unchangedFrom']='f12-renderer-target-20261018';(out/'binary-hashes.json').write_text(json.dumps(old,indent=2)+'\n')
# The ordinary component is unchanged; link its complete pinned inventory and deltas.
prior=json.loads((base/'evidence/f12-renderer-target-20261018/inventory.json').read_text())
root=Path('/private/tmp/blanc-renderer-target-payload');actual={str(p.relative_to(root)):digest(p) for p in root.rglob('*') if p.is_file()};assert actual==prior['payloadFiles']['ordinary']
(out/'payload-reference.json').write_text(json.dumps({'evidence':'../f12-renderer-target-20261018','archiveSha256':prior['archiveSha256'],'payload':'ordinary','files':actual},indent=2)+'\n')
archive=out/'record.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):
  data=p.read_bytes();assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in data
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
manifest={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in files.items()}
with tarfile.open(archive) as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
(out/'inventory.json').write_text(json.dumps({'archiveSha256':digest(archive),'members':manifest},indent=2)+'\n')
print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'verified':True,'binariesUnchanged':True}))
