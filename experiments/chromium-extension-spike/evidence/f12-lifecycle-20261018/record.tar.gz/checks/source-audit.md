# Lifecycle observer conditions

Playwright coreBundle's Chromium switches contain --disable-back-forward-cache.
The lifecycle probe alone omits it; no feature flag or native code is changed.
BFCache requires persisted pageshow, identical extension document ID and preserved
page-instance nonce/marker, not just a successful history traversal. Waiting for
a new DOMContentLoaded is invalid for a restored page.

Pinned uBO js/background.js defaults prefetchingDisabled:true, start.js passes
its inverse to browserSettings, and vapi-background.js sets networkPredictionEnabled.
Chromium preloading_prefs.cc returns kPreloadingDisabled for kNoPreloading. The
initial default run reports that exact reason. Conditional prerender coverage
sets networkPredictionEnabled:true only in the disposable offline test profile,
recording the before/after browser values. It does not claim default uBO prerender.

content/browser/devtools/devtools_instrumentation.cc IsPrerenderAllowed refuses
HasSessionsWithoutTabTargetSupport before consulting PageHandler. Direct per-frame
CDP attachments (including the session profile-kind probe) interfere. Lifecycle
mode detaches that completed probe, and the runner detaches its BFCache observer
before speculation. Browser-level Target enumeration avoids attaching to the
prerendered frame; authored initialPrerendering/activation event and navigation
activationStart must independently prove activation.

Playwright CRSession::_markAsCrashed makes subsequent sends fail. The crash event
is real, but post-crash Playwright goto/unroute failures are observer transport
limitations. Recovery uses browser-owned chrome.tabs.update and exact-document
script APIs; no permanent or unrelated tab is used. Existing browser interfaces
suffice, so no native patch or compile is required.

Raw launch attempts 02/03 attached a popup which closed during startup; the
established openSession helper recreates it, while the raw runner did not.
The final raw runner attaches only the extension background target instead.
An exploratory popup diagnostic first used Node20 (no WebSocket), then found
no popup target; target enumeration confirmed the background remained alive.
These diagnostics did not attach the fixture page and did not change native code.
