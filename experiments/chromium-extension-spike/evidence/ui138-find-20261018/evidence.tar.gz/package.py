from pathlib import Path
import hashlib,json,tarfile,subprocess
r=Path('/private/tmp/blanc-find-capsule');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-20261018';e.mkdir(parents=True,exist_ok=True)
(r/'production.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=w))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
files=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.png','.patch'] or p.is_file() and p.name in ['build.log','build2.log','plan.log','plan2.log','prepare.log','prepare2.log','final-guard2.log','tests-final.log']]
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in manifest.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
text='''## October 18 find-capsule checkpoint

The copied Electron 1.38 find capsule now uses Chromium WebContents Find/StopFinding and
window-local result events. Native Find and Find Next/Previous route through the capsule;
/find is restored. Stale request IDs, inactive/foreign tabs and navigation resets are guarded.
The query limit is 4096 UTF-8 bytes; case-insensitive search uses Chromium's engine.

Automated final-binary checks match installed Electron 1.38 on four matches including a
same-origin iframe, next/previous/wrap, Unicode and zero results. Rapid query replacement,
cross-document reset, tab switch/closure, same-document preservation, private isolation,
foreign/inactive rejection, slash listing and empty host status pass. Command helper calls
exercise the Cmd-G destination, not physical shortcuts. Capsule bounds pass at actual native
1280/800/500px widths. Component screenshots are not full composed visual parity.

Two incremental builds: 62.04s and 60.37s wrapper (58.06s and 55.07s Siso), 15 steps each.
Final guard zero actions; footprint 40 upstream files / 96 hunks, within 40/120. Four focused
regressions, syntax and focused host lint pass. No cold build, GN/toolchain change or latency run.

Failed harness attempts retained: private context requested on page endpoint instead of browser
endpoint; immediate post-restart connection before browser readiness; Node 20 invocation without
experimental WebSocket support. Final matrix and commands pass. Diagnostic background flags
were used only in disposable instances because the Mac is locked. Profiles removed and fixture
server stopped; original preview New Tab and Store restored on final binary with empty status.

Native Cmd-F/Cmd-G/Enter/Shift-Enter/Escape/button clicks, focus/passthrough, IME, VoiceOver,
DPI/full composed visual comparisons, PDF/cross-origin frames and crash/BFCache remain untested.
Native input stays pending unlock. Plan visual item 4 remains incomplete; prior F12/Task0 gates
unchanged. Latency deferred; Electron diagnostic build remains unapproved/unstarted.
'''
(e/'README.md').write_text('# Find capsule automated evidence\n\n'+text+f'\nArchive: `evidence.tar.gz`; all {len(manifest)} members verified against `manifest.json`. No profiles or private keys included.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 p=w/'experiments/chromium-extension-spike'/n
 with p.open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-20261018/`. Build times are routine incremental work, not Task 0 cold-build cost.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();marker='## October 18 find-capsule progress update\n\nFind capsule and native bridge are implemented with bounded automated Electron comparison,\nprivate isolation and 1280/800/500px geometry checks. Native input remains pending unlock;\nvisual item 4 stays in progress, not accepted. Footprint40 files /96 hunks; two incremental\nbuilds, final guard zero. Evidence: `evidence/ui138-find-20261018/`. Prior F12/Task0 gates\nunchanged. Latency deferred; Electron diagnostic build unapproved/unstarted.\n\n';p.write_text(s[:s.index('\n')+1]+'\n'+marker+s[s.index('\n')+1:])
print(len(manifest),'verified archive members')
