const http=require('node:http');const pages={
'/find':'<!doctype html><title>Find fixture</title><style>body{font:20px system-ui;padding:32px}</style><h1>Search fixture</h1><p>needle Needle needle</p><p>café résumé</p><iframe src="/frame"></iframe><input placeholder="page input">',
'/frame':'<!doctype html><p>needle</p>',
'/next':'<!doctype html><title>After navigation</title><p>replacement replacement</p>',
'/empty':'<!doctype html><title>Empty</title><p>No matching content.</p>'};
http.createServer((q,r)=>{r.setHeader('Content-Type','text/html; charset=utf-8');r.end(pages[q.url]||pages['/empty']);}).listen(9265,'127.0.0.1');
