from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/private/tmp/blanc-spaces-overlap');e=Path('/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike');d=e/'evidence/ui138-overlap-unsaved-20261019';d.mkdir(exist_ok=True)
s=json.loads((r/'state.json').read_text());assert s['beforeUnloadProtected'] and s['savedStructureRecovered'];assert json.loads((r/'read.json').read_text())['pass'];assert not (r/'chromium-profile').exists();rows=[json.loads(x) for x in (r/'invocations.jsonl').read_text().splitlines()];seconds=round(next(x['seconds'] for x in rows if x['name']=='final-guard'),2)
summary={'overlapping_restore':'bounded pass: held real Session read, two added windows, one closed before release, source and surviving decoys preserved','live_beforeunload':'switch refused, form/scroll/store preserved','saved_structure_recovery':True,'unsaved_form_recovery':s['unsavedFormRecovered'],'scroll_recovery':s['scrollRecovered'],'overall':'partial; unsaved-state recovery remains a gap','initial_crash_attempt':'timeout before all three windows/journal-clear condition; retained, cause unresolved; settled repeat passes saved structure only','guard_seconds':seconds,'compile':False,'footprint':'prior49/114 unchanged; not re-enumerated'}
(r/'results.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile('/private/tmp/blanc-cdp.mjs',r/'blanc-cdp.mjs')
text=f'''## Overlapping restore and unsaved page state — October 19, 2026

A held actual Session read overlaps two new regular-window creations and closure of one of those windows. The journal remains while held. After release, the original source UUID/URLs recover, the original and surviving new decoys remain, saved Spaces are unchanged and the journal clears. Two bounded runs pass. This is one delayed session restoration with concurrent window activity, not two independent overlapping SessionRestore operations or arbitrary interleavings.

A live authored form with a beforeunload handler refuses switching before any journal/tab/store mutation and preserves its typed value and 700px scroll. After removing the handler and crashing the owned browser, a synthetic valid v2 intent exercises source rollback. The settled-session repeat restores the saved source structure, but the form value is empty and scroll is zero: **unsaved form and scroll recovery fail**. The harness's procedural pass does not mean those acceptance cells pass. The recovery record carries URLs/group/pin/active structure, not live document state; full Spaces acceptance remains open.

An initial immediate crash attempt timed out waiting for three windows and journal clearance. It is retained as unresolved; adding four seconds of session-settling before the repeat is a narrower test, not a product fix or proof of the cause. Nonowner recovery-status errors also remain visible after successful source recovery. No arbitrary overlap, history/form serialization or power-loss claim.

Only disposable profiles and the public mock keychain were used. The Session read interposer is confined to the disposable launch; the final restart uses the normal binary without injection. Explicit crash-bubble bypass is test-only, not physical Restore acceptance. Test helper compilation is not a Chromium build. No product changes or native compilation; final guard zero actions/{seconds}s. Prior measured49files/114hunks unchanged within49/120, not re-enumerated. Owned browser/server/profile removed; retained preview untouched/unavailable.

Native input pending, latency deferred, Electron diagnostic build unapproved/unstarted. Remaining: exact concurrent restoration scheduling, immediate post-restore crash behavior, unsaved document state, real provider/hot-profile/power-loss qualification. Evidence: `evidence/ui138-overlap-unsaved-20261019/`.
'''
files=[p for p in sorted(r.iterdir()) if p.is_file() and p.suffix in ['.json','.jsonl','.log','.mjs','.cjs','.py','.c']];manifest=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in files]
with tarfile.open(d/'evidence.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=p.name)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in manifest:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in ['results.json','invocations.jsonl']:shutil.copyfile(r/n,d/n)
text+=f'\n{len(files)} archive members SHA-256 verified. No new unit-test count claimed.\n';(d/'README.md').write_text(text)
for n in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=e/n;p.write_text(p.read_text()+'\n'+text)
print(len(files))
