from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-group-visual');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-group-visual-20261019';rows=[]
for label in ['blue-collapsed','pink-expanded']:
 for phase in ['seed','window']:
  x=json.loads((r/f'group-{phase}-{label}.json').read_text());assert x['pass'];v=x['groupVisual' if phase=='seed' else 'windowVisual'];rows.append((label,phase,v))
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved'];assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-anchor-fix/binary-hashes.json').read_text())
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps({'pass':True,'errors':errors}));(r/'guard.log').write_bytes(Path('/private/tmp/blanc-anchor-fix/group-visual-guard.log').read_bytes());(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());(r/'scope.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productionChanges':False,'failedAttempts':['named blue rejected: bridge accepts hex color; retained','window check launch overlapped old shutdown, readiness timeout; relaunch waits for owned process exit'],'nativeInput':'pending unlock','latency':'deferred','electronDiagnosticBuild':'unapproved'},indent=2))
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 group visual restoration checks

Two-tab blue/collapsed and pink/expanded groups were closed and reopened through the native
Recently Closed bridge. Then each was moved into a separate window, its expected collapsed
state explicitly set and recorded before shutdown, and the saved window restored after browser
restart. This separates group-entry behavior from the state saved for window restoration.

| Fixture | Restore path | Color retained | Collapsed state retained |
| --- | --- | --- | --- |
'''
for label,phase,v in rows:text+=f"| {label} | {'group entry' if phase=='seed' else 'saved window'} | {v['colorMatches']} | {v['collapsedMatches']} |\n"
text+='''
Closed-group restoration expands the blue group: collapsed state is NOT retained on that path.
Saved-window restoration retains it. Names, two URLs and group membership remain intact in all
four cases; blue/pink colors remain exact. The expanded control remains expanded. No repair or
Electron behavior comparison is claimed; whether group expansion is the desired product policy
remains open. Harness pass flags represent completion/structural checks, not all visual parity;
the separate groupVisual/windowVisual fields retain the failed collapsed-state comparison.

Initial named-color rejection and an overlapping shutdown/relaunch timeout are retained;
final runs use hex colors and wait for owned processes to exit. No fatal/dangling diagnostics.
No production change or compile; guard zero5.42s, native hashes unchanged;40files/97hunks not
re-enumerated. Disposable profiles/server removed; preview preserved. Native input pending,
latency deferred, Electron diagnostic build unapproved. All-color/mixed-group/private/crash
visual persistence and physical rendering remain gaps. Plan item4/F12/Task0 gates remain open.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed archive members; profiles/raw logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-group-visual-20261019/`. Cold-build costs unchanged.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-group-visual-20261019/`.\n'+s[i:]);print(len(m),'verified members')
