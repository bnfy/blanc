from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/private/tmp/blanc-save-rotation');e=Path('/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike');dest=e/'evidence/ui138-save-rotation-20261019';dest.mkdir(exist_ok=True)
checks={n:json.loads((r/(n+'.json')).read_text())['pass'] for n in [stage+'-'+mode for stage in ['clear','encrypted'] for mode in ['identity','reset-before','reset-during','rotate-before','rotate-during']]+['encrypted-normal']};assert all(checks.values())
assert json.loads((r/'source-restored.json').read_text())['equal'];assert not (r/'chromium-profile').exists()
rows=[json.loads(s) for s in (r/'invocations.jsonl').read_text().splitlines()]
builds={x['name']:round(x['seconds'],2) for x in rows if x['name'] in ['diagnostic-build','normal-build','final-guard']};assert len(builds)==3
summary={'checks':checks,'build_wrapper_seconds':builds,'normal_source_restored':True,'normal_footprint':{'files':49,'hunks':114,'basis':'fresh diagnostic inventory49/114, Blanc-owned diagnostic excluded, byte-identical normal source restoration'},'diagnostic_maximum':{'files':49,'hunks':114},'limitations':['first-ever-profile crash restore failed; final matrix uses cleanly primed profiles','no power-loss or arbitrary rebuild/rotation schedule qualification','normal binary smoke is encrypted save/switch/crash restore; diagnostic operations removed'],'native_input':'pending','latency':'deferred','electron_diagnostic_build':'unapproved'}
(r/'results.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile('/private/tmp/blanc-cdp.mjs',r/'blanc-cdp.mjs')
files=[p for p in sorted(r.iterdir()) if p.is_file() and p.suffix in ['.json','.jsonl','.log','.mjs','.cjs','.py','.c','.patch','.txt']]
manifest=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with tarfile.open(dest/'evidence.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=p.name)
with tarfile.open(dest/'evidence.tar.gz') as t:
 for m in manifest:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in ['results.json','invocations.jsonl']:shutil.copyfile(r/n,dest/n)
text=(r/'checkpoint.md').read_text()+f"\nTen final diagnostic schedules and one normal-binary smoke pass. Incremental wrapper times: diagnostic {builds['diagnostic-build']}s, normal restore {builds['normal-build']}s. Final guard zero actions / {builds['final-guard']}s. {len(files)} archived members verified against SHA-256. No new unit-test pass claimed for this evidence-only checkpoint.\n"
(dest/'README.md').write_text(text)
for n in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=e/n;p.write_text(p.read_text()+'\n'+text)
print(json.dumps({'members':len(files),'builds':builds,'bytes':(dest/'evidence.tar.gz').stat().st_size}))
