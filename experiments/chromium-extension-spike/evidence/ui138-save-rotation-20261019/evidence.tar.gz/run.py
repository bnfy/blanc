import os,pathlib,subprocess,sys,shutil
r=pathlib.Path('/private/tmp/blanc-save-rotation')
for stage in (sys.argv[1:2] or ['clear','encrypted']):
 for mode in (sys.argv[2:3] or ['identity','reset-before','reset-during','rotate-before','rotate-during']):
  env={**os.environ,'INJECT':'1','SESSION_MODE':'write',('ACK_ENCRYPTED' if stage=='encrypted' else 'ACK_CLEAR'):'1'}
  for n in ['arm','release','marker.json','exit.json']:(r/n).unlink(missing_ok=True)
  prefix=stage+'-'+mode
  try:
   initial={k:v for k,v in env.items() if k!='INJECT'}
   for name,args in [('start',['start.mjs']),('seed',['check.mjs','seed']),('prime-close',['close.mjs'])]:
    subprocess.run(['python3',str(r/'invoke.py'),prefix+'-'+name,'node',str(r/args[0]),*args[1:]],env=initial,check=True)
   (r/'arm').write_text('1')
   subprocess.run(['python3',str(r/'invoke.py'),prefix+'-held-restart','node',str(r/'launch-injected.mjs')],env={**env,'RESTORE':'1'},check=True)
   subprocess.run(['python3',str(r/'invoke.py'),prefix+'-proof','node',str(r/'probe.mjs'),mode],env=env,check=True)
  finally:
   (r/'release').write_text('1');subprocess.run(['python3',str(r/'invoke.py'),prefix+'-cleanup','node',str(r/'cleanup.mjs')],check=True)
   shutil.copyfile(r/'cleanup.json',r/(prefix+'-cleanup.json'))
