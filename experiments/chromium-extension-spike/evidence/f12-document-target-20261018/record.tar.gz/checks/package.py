from pathlib import Path
import hashlib,json,tarfile,io
repo=Path.cwd();base=repo/'experiments/chromium-extension-spike';out=base/'evidence/f12-document-target-20261018';out.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for label,root in [('target01',Path('/private/tmp/blanc-document-target-run01')),('target02',Path('/private/tmp/blanc-document-target-run02')),('helpers',Path('/private/tmp/blanc-document-target-helpers')),('ordering',Path('/private/tmp/blanc-document-target-ordering')),('checks',Path('/private/tmp/blanc-document-target-build'))]:
 if not root.exists():continue
 for p in root.rglob('*'):
  if p.is_file() and p.name!='processes.log':files[label+'/'+str(p.relative_to(root))]=p
for name in ['prepare.mjs','ubo-document-target.mjs','ubo-upstream-delivery.js','ubo-upstream-test.mjs','fixtures/replay/synthetic/document-target-payload.mjs','fixtures/replay/synthetic/document-target-run.mjs','fixtures/replay/synthetic/document-target-verify.mjs','fixtures/replay/synthetic/delivery-order-payload.mjs','fixtures/replay/synthetic/helper-channels-run.mjs','fixtures/replay/synthetic/helper-channels-verify.mjs','fixtures/replay/synthetic/delivery-order-run.mjs','fixtures/replay/synthetic/delivery-order-verify.mjs','fixtures/replay/synthetic/session.mjs']:
 files['sources/'+name]=base/name
pin=json.loads((repo/'ublock/pinned.json').read_text());pinned={f['path']:f['sha256'] for f in pin['files']};inventory={}
for label,root in [('ordinary',Path('/private/tmp/blanc-document-target-payload02')),('diagnostic',Path('/private/tmp/blanc-document-target-diagnostic02')),('regression',Path('/private/tmp/blanc-document-target-regression02'))]:
 inventory[label]={}
 for p in root.rglob('*'):
  if not p.is_file():continue
  rel=str(p.relative_to(root));h=digest(p);inventory[label][rel]=h
  if pinned.get(rel)!=h or rel=='LICENSE.txt':files['payload/'+label+'/'+rel]=p
files['payload/pinned.json']=repo/'ublock/pinned.json'
archive=out/'record.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):
  data=p.read_bytes();assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in data
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
manifest={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in files.items()}
with tarfile.open(archive) as t:
 for m in t:
  assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
(out/'inventory.json').write_text(json.dumps({'archiveSha256':digest(archive),'members':manifest,'payloadFiles':inventory},indent=2)+'\n')
old=json.loads((base/'evidence/f12-helper-channels-20261018/binary-hashes.json').read_text())
for item in old['files']:item['sha256']=digest(Path(item['path']))
old.pop('unchangedFrom',None);old['nativeBuild']=True;(out/'binary-hashes.json').write_text(json.dumps(old,indent=2)+'\n')
print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'verified':True}))
