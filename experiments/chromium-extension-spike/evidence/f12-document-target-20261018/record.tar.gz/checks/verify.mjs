import fs from 'node:fs';import assert from 'node:assert/strict';
import {verifyTarget} from '/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike/fixtures/replay/synthetic/document-target-verify.mjs';
import {verifyChannels} from '/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike/fixtures/replay/synthetic/helper-channels-verify.mjs';
const r=JSON.parse(fs.readFileSync(process.argv[2]));console.log(verifyTarget(r));
let rejected=0;for(const mutate of [r=>r.checks[2].after.documentId=r.checks[2].before.documentId,r=>r.checks[3].result=[true],r=>r.checks[4].raw.error='',r=>r.checks[1].after.documentId='changed',r=>r.checks[7].result={result:[true]},r=>r.cleanup.removed=false,r=>r.faults.push({code:'unrecorded-request'})]){const broken=structuredClone(r);mutate(broken);assert.throws(()=>verifyTarget(broken));rejected++;}console.log({rejected});
if(process.argv[3])console.log(verifyChannels(JSON.parse(fs.readFileSync(process.argv[3]))));
