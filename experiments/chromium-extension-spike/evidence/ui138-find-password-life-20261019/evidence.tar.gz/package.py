from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-find-password-life');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-password-life-20261019'
assert json.loads((r/'results.json').read_text())['pass']
assert json.loads((r/'cleanup.json').read_text())['status']==''
assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-find-plugin-fix/binary-hashes.json').read_text())
(r/'source-head.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productionCodeChanged':False,'binaryUnchanged':True},indent=2))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());e.mkdir(parents=True,exist_ok=True)
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.pdf','.png'] or p.name=='guard.log')]
m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 PDF password lifecycle checkpoint

Eight actual viewer-dialog observations pass across regular/private windows: initial open,
Page.reload, closing/reopening the same URL, and reopening the same URL after a full browser
restart using the same disposable profile. Every checkpoint presents a visible password dialog
with an empty input. Pre-unlock search observations contain no positive result; correct re-entry
restores two matches. The fixture is unchanged AES-256 with a public, nonsecret test password.

The first browser exits with a private PDF open. Its PID is confirmed absent before relaunch;
the second browser has a different PID and uses the same profile directory. Startup targets
contain only New Tab and host, no prior private PDF. The post-restart regular/private URLs are
opened explicitly: this does not qualify automatic session restore, crash restore or Recently
Closed restoration. These observations establish re-prompt behavior for the tested paths, not
proof that no password bytes ever reach memory/disk or a general persistence/security audit.

No production changes or compilation. Guard zero5.64s; hashes match the PDF reset binary;
footprint remains40files/96hunks (not re-enumerated). No latency run, unit-suite repeat, Electron
comparison or physical input claim. Disposable profile/server deleted; preview original tabs
and empty host status preserved. Before/after results, PIDs, fixture and harness archived.

Remaining: automatic session/crash/RecentlyClosed restore, password-manager integration,
permissions-only encryption/other algorithms, XFA/OCR/form edits, extreme PDFs and wider
lifecycle/accessibility/fullvisual coverage. Native input pending unlock; latency deferred;
Electron diagnostic build unapproved/unstarted. Plan item4 and prior F12/Task0 gates unchanged.
'''
(e/'README.md').write_text(text+f'\n{len(m)} archive members hash verified; profiles/raw browser logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (w/'experiments/chromium-extension-spike'/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-password-life-20261019/`. No Task0 cold-cost change.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-find-password-life-20261019/`.\n'+s[i:]);print(len(m),'verified archive members')
