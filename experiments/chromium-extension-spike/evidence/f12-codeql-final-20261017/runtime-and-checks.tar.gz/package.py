from pathlib import Path
import tarfile,gzip,io,json,hashlib,shutil,subprocess
repo=Path('/private/tmp/blanc-chromium157-work');r=repo/'experiments/chromium-extension-spike';e=r/'evidence/f12-codeql-final-20261017';b=Path('/private/tmp/blanc-codeql-final-build');rows=[]
def tree(root,prefix):return [(p,prefix+'/'+str(p.relative_to(root))) for p in root.rglob('*') if p.is_file()]
def archive(name,items):
 members=[]
 with (e/name).open('wb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
   with tarfile.open(fileobj=gz,mode='w') as t:
    for p,arc in sorted(items,key=lambda x:x[1]):
     assert not p.is_symlink();d=p.read_bytes();assert b'-----BEGIN PRIVATE KEY-----\n' not in d;info=tarfile.TarInfo(arc);info.size=len(d);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(d));members.append({'path':arc,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
 rows.append({'file':name,'bytes':(e/name).stat().st_size,'sha256':hashlib.sha256((e/name).read_bytes()).hexdigest(),'members':members})
binaries=json.loads(Path('/private/tmp/blanc-static-integration-build/binary-hashes.json').read_text())
for x in binaries:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
(b/'binary-hashes.json').write_text(json.dumps({'unchanged':True,'files':binaries},indent=2)+'\n')
for n in ['readiness.json','unready.json','readiness-final.json','unready-final.json']:assert json.loads((b/n).read_text())['profileRemoved']
archive('runtime-and-checks.tar.gz',tree(b,'checks')+tree(Path('/private/tmp/blanc-codeql-final-static'),'static')+tree(Path('/private/tmp/blanc-codeql-final-csp'),'csp')+[(Path(__file__),'package.py')])
files=[]
for p in r.rglob('*'):
 rel=p.relative_to(r)
 if p.is_file() and not {'evidence','generated'}.intersection(rel.parts) and (p.suffix in ['.mjs','.cjs','.js','.cc','.h','.inc','.mojom','.py'] or p.name=='BUILD.gn'):files.append((p,str(p.relative_to(repo))))
archive('sources.tar.gz',files)
pin=json.loads((repo/'ublock/pinned.json').read_text());original={x['path']:x['sha256'] for x in pin['files']};items=[(repo/'ublock/pinned.json','pinned.json')];inventory={}
for dirname,alias in [('blanc-codeql-final-payload','final'),('blanc-codeql-final-unready','unready')]:
 root=Path('/private/tmp')/dirname;inventory[alias]=[]
 for p in root.rglob('*'):
  if not p.is_file():continue
  rel=str(p.relative_to(root));h=hashlib.sha256(p.read_bytes()).hexdigest();changed=h!=original.get(rel);inventory[alias].append({'path':rel,'sha256':h,'changedOrNew':changed})
  if changed or rel=='LICENSE.txt':items.append((p,alias+'/'+rel))
(b/'payload-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n');items.append((b/'payload-inventory.json','payload-inventory.json'));archive('payload-delta.tar.gz',items)
# Public source references supporting the code-literal remediation, no external assets.
archive('record.tar.gz',[(e/'README.md','README.md')])
for n in ['static-proof.json','csp-proof.json','binary-hashes.json','cleanup.json','invocations.jsonl']:shutil.copyfile(b/n,e/n)
(e/'archives.json').write_text(json.dumps(rows,indent=2)+'\n');dest=Path('/private/tmp/blanc-codeql-final-verified');dest.mkdir()
for row in rows:
 with tarfile.open(e/row['file']) as t:
  assert t.getnames()==[m['path'] for m in row['members']]
  for m in row['members']:
   data=t.extractfile(m['path']).read();assert hashlib.sha256(data).hexdigest()==m['sha256'];target=dest/m['path'];assert target.is_relative_to(dest);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
src=dest/'experiments/chromium-extension-spike'
for script,run,proof in [('static-integration-verify.mjs','static','static-proof.json'),('static-csp-verify.mjs','csp','csp-proof.json')]:assert json.loads(subprocess.check_output(['node',str(src/'fixtures/replay/synthetic'/script),str(dest/run)]))==json.loads((e/proof).read_text())
subprocess.check_call(['node',str(src/'ubo-readiness-verify.mjs'),str(dest/'checks/readiness-final.json'),str(dest/'checks/unready-final.json')])
summary={'verified':True,'archives':len(rows),'members':sum(len(x['members']) for x in rows),'compressedBytes':sum(x['bytes'] for x in rows),'independentProofs':3};(e/'archive-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
