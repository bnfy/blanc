from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-corrupt-session');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-corrupt-session-20261019'
a=json.loads((r/'matrix.json').read_text());b=json.loads((r/'matrix-both.json').read_text());assert len(a)==4 and len(b)==3
for x in a+b:assert x['startup']['pass'] and x['restart']['pass']
assert a[0]['startup']['regularPDFRestored'];assert json.loads((r/'cleanup.json').read_text())['profilesRemoved'];assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-anchor-fix/binary-hashes.json').read_text())
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps({'fatalOrDangling':errors,'pass':True},indent=2));(r/'guard.log').write_bytes(Path('/private/tmp/blanc-anchor-fix/corrupt-guard.log').read_bytes());(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());(r/'scope.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'nativeCodeChanged':False,'filesMutated':'Session_* only; Tabs_* and other profile stores untouched','firstMatrix':'plaintext only; encrypted counterpart retained','secondMatrix':'fresh seed, both stores','seedRecreated':'first matrix removed its seed at completion, fresh disposable seed used for second matrix','nativeInput':'pending unlock','latency':'deferred','electronDiagnosticBuild':'unapproved/unstarted'},indent=2))
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.pdf'] or p.name=='guard.log')];e.mkdir(parents=True,exist_ok=True);m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 corrupt-session checks

Seven bounded cases ran in offline copies of disposable regular/private PDF session seeds.
Mutations were made only after owned browser processes exited: invalid first eight bytes,
half-file truncation (retaining header), or deletion of Session_* files. Before/after sizes and
SHA-256 values are recorded. Intact control restores the regular PDF; private PDF never restores.
The first matrix damages only Default/Sessions while Sessions_Encrypted remains intact;
restoration there does not establish recovery from loss of both stores. A fresh seed supplies
three cases damaging both stores. Tabs_* and other profile data remain untouched.

| Case | Original regular PDF restored | New page/search and next clean restore |
| --- | --- | --- |
'''
for x in a+b:text+='| '+x['case']+' | '+str(x['startup']['regularPDFRestored'])+' | pass |\n'
text+='''
A fallback to New Tab is startup resilience with original-session data loss, not successful
restoration. Every case accepts a new authored page, native Find returns one match, and that
new page restores and searches on the next clean launch. No private URL appears. No fatal or
dangling-pointer diagnostic appears across the run. These are CDP/bridge checks; no recovery
button, filesystem permission failure, partial-write concurrency, Tabs_* corruption, encrypted
key loss, OS reboot or general profile-corruption resilience is claimed.

Evidence-only: no production changes or compilation; guard zero3.62s, binary hashes unchanged,
40files/97hunks not re-enumerated. Disposable profile copies/server removed, original preview
preserved. Native input pending unlock, latency deferred, Electron diagnostic build unapproved.
Plan item4 and broader F12/Task0 gates remain open; no cold-build column change.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hashed archive members; profiles/session binaries/raw logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-corrupt-session-20261019/`.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-corrupt-session-20261019/`.\n'+s[i:]);print(len(m),'verified members')
