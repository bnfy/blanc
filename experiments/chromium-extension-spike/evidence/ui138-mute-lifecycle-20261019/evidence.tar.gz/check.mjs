import fs from 'node:fs';import assert from 'node:assert/strict';import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const r='/private/tmp/blanc-mute-lifecycle',clients=[],proof={checks:[]};
const list=()=>fetch('http://127.0.0.1:9258/json/list').then(x=>x.json());
const api=(h,m,...a)=>h.eval(`BlancPrototypeHost.api.${m}(...${JSON.stringify(a)})`);
const attach=async t=>{const c=await connect(t);clients.push(c);return c};
const wait=async(fn,test)=>{for(let i=0;i<150;i++){let x=await fn().catch(()=>null);if(test(x))return x;await pause(100)}throw Error('timeout')};
try{
const b=await attach(await wait(()=>fetch('http://127.0.0.1:9258/json/version').then(x=>x.json()),Boolean));
await wait(list,x=>x?.some(t=>t.url.includes('host.html')));const h=await attach((await list()).find(t=>t.url.includes('host.html')));await wait(()=>h.eval('typeof BlancPrototypeHost!=="undefined"'),Boolean);
const url='http://127.0.0.1:9265/a';await api(h,'createTab',url);let s=await wait(()=>api(h,'getAllTabs'),s=>s.tabs.some(t=>t.url===url));const id=s.tabs.find(t=>t.url===url).id;
const check=async(label,muted,siteMuted)=>{const s=await wait(()=>api(h,'getAllTabs'),s=>{const t=s.tabs.find(t=>t.id===id);return t&&t.muted===muted&&t.siteMuted===siteMuted});proof.checks.push({label,tab:s.tabs.find(t=>t.id===id)});};
await api(h,'toggleSiteMute',id);await check('site enabled',true,true);
await api(h,'toggleTabMuted',id);await check('per-tab exemption',false,true);
await api(h,'navigate',id,url+'?same-host');await check('same-host exemption retained',false,true);
await api(h,'navigate',id,'http://localhost:9265/b');await wait(()=>api(h,'getAllTabs'),s=>s.tabs.find(t=>t.id===id)?.url==='http://localhost:9265/b');await check('different host',false,false);
await api(h,'navigate',id,url);await wait(()=>api(h,'getAllTabs'),s=>s.tabs.find(t=>t.id===id)?.url===url);await check('return resets exemption',true,true);
const page=await attach((await list()).find(t=>t.url===url));await page.send('Page.crash').catch(()=>{});await pause(500);await api(h,'navigate',id,url+'?recovered');await wait(()=>api(h,'getAllTabs'),s=>s.tabs.find(t=>t.id===id)?.url===url+'?recovered');await check('crash then navigation preserves site policy',true,true);
for(let cycle=0;cycle<2;cycle++){
 const {browserContextId}=await b.send('Target.createBrowserContext');await b.send('Target.createTarget',{url,browserContextId,newWindow:true});await pause(1000);
 let ph;for(const t of(await list()).filter(t=>t.url.includes('host.html'))){const c=await attach(t);if((await api(c,'getAllTabs')).tabs.some(t=>t.private)){ph=c;break}}assert(ph);
 const p=await wait(()=>api(ph,'getAllTabs'),s=>s.tabs.some(t=>t.url===url)),t=p.tabs.find(t=>t.url===url);assert.equal(t.muted,false);assert.equal(t.siteMuted,false);
 await api(ph,'toggleSiteMute',t.id);const changed=await api(ph,'getAllTabs');assert.equal(changed.tabs.find(x=>x.id===t.id).muted,true);
 proof.checks.push({label:'private fresh policy and disposal '+cycle,before:t,after:changed.tabs.find(x=>x.id===t.id)});
 await b.send('Target.disposeBrowserContext',{browserContextId});await check('regular survives private disposal '+cycle,true,true);
}
proof.pass=true;await b.send('Browser.close');
}catch(e){proof.pass=false;proof.error=String(e)}finally{clients.forEach(c=>c.close());fs.writeFileSync(r+'/result.json',JSON.stringify(proof,null,2));console.log({pass:proof.pass,error:proof.error,checks:proof.checks.length})}if(!proof.pass)process.exitCode=1;
