from pathlib import Path
import json,tarfile,io,gzip,hashlib,shutil
repo=Path('/private/tmp/blanc-chromium157-work');out=repo/'experiments/chromium-extension-spike/evidence/f12-codeql-20261017';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();inventory={'archives':[]}
for name,source in [('checks','/private/tmp/blanc-f12-codeql'),('engine','/private/tmp/blanc-f12-codeql-assets'),('native-full','/private/tmp/blanc-f12-codeql-native-full'),('native-no-referrer','/private/tmp/blanc-f12-codeql-native-no-referrer'),('paths','/private/tmp/blanc-f12-codeql-paths'),('failures','/private/tmp/blanc-f12-codeql-failures')]:
 root=Path(source);assert root.exists(),source
 buf=io.BytesIO();entries=[]
 with tarfile.open(fileobj=buf,mode='w') as tar:
  for p in sorted(root.rglob('*')):
   if not p.is_file():continue
   data=p.read_bytes();assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in data and (b'-----BEGIN RSA '+b'PRIVATE KEY-----') not in data
   rel=str(p.relative_to(root));info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));entries.append({'path':rel,'sha256':sha(data),'bytes':len(data)})
 data=gzip.compress(buf.getvalue(),mtime=0);(out/(name+'.tar.gz')).write_bytes(data);inventory['archives'].append({'file':name+'.tar.gz','sha256':sha(data),'bytes':len(data),'entries':entries})
 for f in ['report.json','comparison.json','result.json']:
  if (root/f).exists():shutil.copyfile(root/f,out/(name+'-'+f))
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for src,dst in [('review.md','review.md'),('fingerprints.json','fingerprints.json'),('budget.json','budget.json')]:shutil.copyfile(Path('/private/tmp/blanc-f12-codeql')/src,out/dst)
shutil.copyfile(repo/'experiments/chromium-extension-spike/fixtures/replay/NOTICE',out/'NOTICE')
for a in inventory['archives']:
 assert sha((out/a['file']).read_bytes())==a['sha256']
 with tarfile.open(out/a['file']) as tar:
  for e in a['entries']:assert sha(tar.extractfile(e['path']).read())==e['sha256']
print(json.dumps({'archives':len(inventory['archives']),'originalFiles':sum(len(a['entries']) for a in inventory['archives']),'compressedBytes':sum(a['bytes'] for a in inventory['archives'])}))
