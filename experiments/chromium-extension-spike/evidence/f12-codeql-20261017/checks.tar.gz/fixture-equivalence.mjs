import fs from 'node:fs';import assert from 'node:assert/strict';
import {authoredResponse} from '/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike/fixtures/replay/synthetic/generate.mjs';
import {pathFixtures} from '/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike/fixtures/replay/synthetic/paths-fixtures.mjs';
const manifest=JSON.parse(fs.readFileSync('/private/tmp/blanc-f12-expanded-09/candidate-manifest.json'));
const responses=new Map(JSON.parse(fs.readFileSync('/private/tmp/blanc-f12-expanded-09/responses.json')));
for(const c of manifest.candidates){const r=authoredResponse(c);assert.equal(r.body,responses.get(c.url).body);}
const old=new Map(JSON.parse(fs.readFileSync('/private/tmp/blanc-f12-paths-03/fixtures.json'))),fresh=pathFixtures().fixtures;
assert.equal(old.size,fresh.size);for(const [url,response] of fresh)assert.deepEqual(response,old.get(url));
console.log(JSON.stringify({candidateResponseBytesUnchanged:manifest.candidates.length,pathResponsesUnchanged:fresh.size}));
