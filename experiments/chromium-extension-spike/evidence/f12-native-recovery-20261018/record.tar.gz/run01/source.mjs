/* global chrome */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';
import {openSession,until,pause} from './session.mjs';import {startSynthetic} from './transport.mjs';import {createCertificateSet} from './certificate-set.mjs';
const [cfg,payload,evidence]=process.argv.slice(2),config=JSON.parse(fs.readFileSync(cfg));assert(!fs.existsSync(evidence));fs.mkdirSync(evidence);
const host='https://page.blanc-fixture.test',filters='page.blanc-fixture.test##+js(set-constant, raceFlag, true)\n||page.blanc-fixture.test/blocked^';
const body='<!doctype html><link rel="icon" href="data:,"><script>window.first=window.raceFlag===true;</script><div id="marker">clean</div>';
const fixtures=new Map(['/test','/blocked','/allowed'].map(p=>[host+p,{status:200,contentType:p==='/test'?'text/html':'text/plain',body:p==='/test'?body:'fixture'}]));
const root=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'blanc-native-recovery-'))),certificates=createCertificateSet(path.join(root,'certificates'),[new URL(host).hostname]),replay=await startSynthetic({fixtures,tlsMaterial:certificates});
const report={completed:false,checks:[],latencyMeasured:false,diagnosticScheduling:true};let session,cdp;
try{
 session=await openSession({config,browserKind:'chromium',kind:'regular',label:'native-recovery',root,transport:replay,certificates,provider:'ublock-origin',uboPayload:payload});await session.uboConfigure();await session.uboSetFilters(filters);
 let popup=session.page.context().pages().find(p=>p.url().includes('/popup-fenix.html'));assert(popup);const page=session.page;
 const snapshot=()=>popup.evaluate(async()=>{const b=chrome.extension.getBackgroundPage(),state=b.__blancDeliveryProbe.state(),r=await b.fetch('http://blanc-ubo-control.invalid/early-deliveries?'+state.generation);return {state,native:await r.json(),result:b.recoveryReload,events:b.__blancDeliveryProbe.events};});
 cdp=await page.context().newCDPSession(page);await cdp.send('Debugger.enable');let paused,crashed=false;cdp.on('Debugger.paused',e=>{paused=e;});page.on('crash',()=>{crashed=true;});
 await popup.evaluate(()=>{const b=chrome.extension.getBackgroundPage();b.__blancDeliveryProbe.armed='native';b.__blancDeliveryProbe.events.length=0;});
 const navigation=page.goto(host+'/test').then(()=>({ok:true}),e=>({error:String(e)}));await until(()=>paused);const before=await snapshot();assert.equal(before.native.pending,1);assert.equal(before.events[0].path,'native');
 await popup.evaluate(()=>{const b=chrome.extension.getBackgroundPage();b.recoveryReload={settled:false};b.µBlock.loadFilterLists().then(()=>{b.recoveryReload={settled:true};},e=>{b.recoveryReload={settled:true,error:String(e)};});});
 await until(async()=>!(await snapshot()).state.ready);const held=await snapshot();assert.equal(held.native.pending,1);assert.equal(held.result.settled,false);
 void cdp.send('Page.crash').catch(()=>{});await until(()=>crashed,10000);await navigation;
 await until(async()=>{const s=await snapshot();return s.result?.settled&&s.state.ready;},10000);const after=await snapshot();assert.equal(after.native.pending,0);assert(!after.result.error);
 const tab=await popup.evaluate(async()=> (await chrome.tabs.query({})).find(t=>t.url==='https://page.blanc-fixture.test/test').id);
 await popup.evaluate(({tab,url})=>chrome.tabs.update(tab,{url}),{tab,url:host+'/test'});await until(()=>page.evaluate(()=>window.first===true).catch(()=>false));
 report.checks.push({kind:'native-execution-crash',pauseBoundary:'inside-native-ExecuteScript',before,held,after,crashed,recovered:await page.evaluate(()=>({first:window.first,marker:document.querySelector('#marker').textContent}))});
 // Reload the actual background document, preserving the installed component and profile.
 const old=await popup.evaluate(()=>{const b=chrome.extension.getBackgroundPage();b.recoveryIdentity=crypto.randomUUID();return {identity:b.recoveryIdentity,state:b.__blancDeliveryProbe.state()};});
 await popup.evaluate(()=>chrome.extension.getBackgroundPage().location.reload());
 await until(()=>popup.evaluate(()=>Boolean(chrome.extension.getBackgroundPage()?.__blancDeliveryProbe?.state().ready)).catch(()=>false),30000);
 const recreated=await popup.evaluate(()=>{const b=chrome.extension.getBackgroundPage();return {oldIdentity:b.recoveryIdentity??null,state:b.__blancDeliveryProbe.state(),readyToFilter:b.µBlock.readyToFilter};});assert.equal(recreated.oldIdentity,null);assert(recreated.readyToFilter);
 await page.goto(host+'/test');const result=await page.evaluate(async()=>({first:window.first,allowed:await fetch('/allowed').then(r=>r.text()).catch(()=>null),blocked:await fetch('/blocked').then(()=>false).catch(()=>true)}));assert(result.first&&result.blocked);assert.equal(result.allowed,'fixture');
 report.checks.push({kind:'background-document-recreation',old,recreated,result});report.completed=true;
}catch(e){report.error=String(e);process.exitCode=1;}finally{if(cdp)await cdp.send('Debugger.resume').catch(()=>{});if(session)await session.close();report.faults=replay.faults;report.arrivals=replay.arrivals;await replay.close();fs.rmSync(root,{recursive:true,force:true});report.cleanup={removed:!fs.existsSync(root)};fs.writeFileSync(path.join(evidence,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({completed:report.completed,error:report.error}));}
