import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {comparePathRuns} from '/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike/fixtures/replay/synthetic/paths-compare.mjs';
for(const name of ['paths-06','controlled-07']){
 const dir='/private/tmp/blanc-f12-worker-identity/'+name,fixtures=new Map(JSON.parse(fs.readFileSync(path.join(dir,'fixtures.json')))),cases=JSON.parse(fs.readFileSync(path.join(dir,'cases.json'))),result={profiles:{},fullAcceptance:false};
 for(const kind of ['regular','private']){
  const read=label=>JSON.parse(fs.readFileSync(path.join(dir,label+'.json')));
  result.profiles[kind]=comparePathRuns(...['electron','chromium'].flatMap(b=>['a','b'].map(l=>read(b+'-'+kind+'-'+l))),fixtures,cases);
 }
 const old=JSON.parse(fs.readFileSync(path.join(dir,'comparison.json')));
 for(const kind of ['regular','private']){const r=result.profiles[kind];assert(r.valid);assert(!r.results.some(c=>c.status==='failed'));assert.deepEqual(JSON.parse(JSON.stringify(r.results)),old.profiles[kind].results);}
 fs.writeFileSync('/private/tmp/blanc-f12-worker-identity/'+name+'-final-comparison.json',JSON.stringify(result,null,2));console.log(name+': unchanged results with final comparator; both profiles valid, explicit gaps preserved');
}
