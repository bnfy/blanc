import net from 'node:net';
export async function freePort(){const s=net.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}
export async function observe(port){
 let endpoint;for(let i=0;i<100;i++){try{endpoint=(await(await fetch(`http://127.0.0.1:${port}/json/version`)).json()).webSocketDebuggerUrl;if(endpoint)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 if(!endpoint)throw Error('Owned browser CDP endpoint unavailable');
 const ws=new WebSocket(endpoint),pending=new Map(),sessions=new Map(),events=[],faults=[];let seq=0;
 await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
 const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},10000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});
 ws.onmessage=ev=>{const m=JSON.parse(ev.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}return;}
 events.push({...m,observedAt:Date.now()});
 if(m.method==='Target.attachedToTarget'){
  const {sessionId,targetInfo,waitingForDebugger}=m.params;sessions.set(sessionId,targetInfo);
  (async()=>{await send('Network.enable',{},sessionId);await send('Runtime.enable',{},sessionId);if(targetInfo.type==='page'){await send('Page.enable',{},sessionId);await send('ServiceWorker.enable',{},sessionId);}await send('Runtime.runIfWaitingForDebugger',{},sessionId);})().catch(e=>{faults.push(String(e));if(waitingForDebugger)send('Runtime.runIfWaitingForDebugger',{},sessionId).catch(()=>{});});
 }
 };
 await send('Target.setDiscoverTargets',{discover:true});
 await send('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:true,filter:[{type:'shared_worker'},{type:'service_worker'},{type:'worker'},{exclude:true}]});
 return {send,events,faults,sessions,close:async()=>{await send('Target.setAutoAttach',{autoAttach:false,waitForDebuggerOnStart:false,flatten:true});ws.close();}};
}
