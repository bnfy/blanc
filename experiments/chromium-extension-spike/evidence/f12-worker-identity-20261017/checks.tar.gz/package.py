from pathlib import Path
import json,hashlib,tarfile,gzip,io,shutil
root=Path('/private/tmp/blanc-f12-worker-identity')
out=Path('/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike/evidence/f12-worker-identity-20261017');out.mkdir(exist_ok=True)
h=lambda data:hashlib.sha256(data).hexdigest()
groups={p.name:sorted(x for x in p.rglob('*') if x.is_file()) for p in root.iterdir() if p.is_dir() and p.name!='capture-source'}
groups['checks']=sorted([p for p in root.iterdir() if p.is_file()]+list((root/'capture-source').iterdir()))
inventory={'scope':'worker context investigation; synthetic fixtures only; includes failed attempts','archives':{}}
for name,files in sorted(groups.items()):
 entries=[];archive=out/(name+'.tar.gz')
 with open(archive,'wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for p in files:
     data=p.read_bytes();assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in data and (b'-----BEGIN '+b'RSA PRIVATE KEY-----') not in data and (b'-----BEGIN '+b'EC PRIVATE KEY-----') not in data,p
     rel=str(p.relative_to(root));info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));entries.append({'path':rel,'bytes':len(data),'sha256':h(data)})
 with tarfile.open(archive,'r:gz') as tar:
  assert len(tar.getmembers())==len(entries)
  for e in entries:assert h(tar.extractfile(e['path']).read())==e['sha256']
 inventory['archives'][archive.name]={'sha256':h(archive.read_bytes()),'bytes':archive.stat().st_size,'files':entries}
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for name in ['budget.json','fingerprints.json','paths-06-final-comparison.json','controlled-07-final-comparison.json']:shutil.copyfile(root/name,out/name)
for name in ['paths-06','controlled-07','paths-04']:shutil.copyfile(root/name/'report.json',out/(name+'-report.json'))
shutil.copyfile(out.parent/'f12-worker-context-20261017/NOTICE',out/'NOTICE')
print(json.dumps({'archives':len(groups),'files':sum(len(v['files']) for v in inventory['archives'].values()),'compressedBytes':sum(v['bytes'] for v in inventory['archives'].values())}))
