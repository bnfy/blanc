import os,pathlib,subprocess,sys
r=pathlib.Path('/private/tmp/blanc-first-session');case=sys.argv[1];env={**os.environ,'ACK_CLEAR':'1','CASE':case,'INJECT':'1',**({'PREFS_FAIL':'1'} if case=='fail' else {})}
for n in ['release','prefs-marker.json','exit.json']:(r/n).unlink(missing_ok=True)
(r/'arm').write_text('1')
try:
 for name,args in [('start',['start.mjs']),('seed',['check.mjs','seed']),('proof',['fault.mjs'])]:subprocess.run(['python3',str(r/'invoke.py'),case+'-'+name,'node',str(r/args[0]),*args[1:]],env=env,check=True)
finally:
 (r/'release').write_text('1');subprocess.run(['python3',str(r/'invoke.py'),case+'-cleanup','node',str(r/'cleanup.mjs')],check=True)
