import os,pathlib,subprocess,sys
r=pathlib.Path('/private/tmp/blanc-first-session');stage=sys.argv[1];case=sys.argv[2];env={**os.environ,('ACK_ENCRYPTED' if stage=='encrypted' else 'ACK_CLEAR'):'1','CASE':case}
for n in ['arm','release','marker.json','exit.json']:(r/n).unlink(missing_ok=True)
try:
 for name,args in [('start',['start.mjs']),('seed',['check.mjs','seed']),('proof',['normal.mjs'])]:
  subprocess.run(['python3',str(r/'invoke.py'),stage+'-'+case+'-'+name,'node',str(r/args[0]),*args[1:]],env=env,check=True)
finally:
 subprocess.run(['python3',str(r/'invoke.py'),stage+'-'+case+'-cleanup','node',str(r/'cleanup.mjs')],check=True)
