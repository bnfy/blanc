#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
static int ren(const char*a,const char*b){const char*r=getenv("BLANC_PREFS_FAULT");char dest[4096],arm[4096],marker[4096],release[4096],msg[4600];if(r){snprintf(dest,sizeof(dest),"%s/chromium-profile/Default/Preferences",r);snprintf(arm,sizeof(arm),"%s/arm",r);if(!strcmp(b,dest)&&!unlink(arm)){snprintf(marker,sizeof(marker),"%s/prefs-marker.json",r);snprintf(release,sizeof(release),"%s/release",r);int fd=open(marker,O_CREAT|O_WRONLY|O_TRUNC,0600);int n=snprintf(msg,sizeof(msg),"{\"pid\":%d,\"destination\":\"%s\",\"operation\":\"rename\"}",getpid(),b);if(fd>=0){syscall(SYS_write,fd,msg,n);close(fd);}if(getenv("PREFS_FAIL")){errno=EIO;return -1;}time_t end=time(NULL)+45;while(access(release,F_OK)&&time(NULL)<end)usleep(10000);}}return syscall(SYS_rename,a,b);}
__attribute__((used,section("__DATA,__interpose")))static struct{const void*a;const void*b;}i[]={{(void*)ren,(void*)rename}};
