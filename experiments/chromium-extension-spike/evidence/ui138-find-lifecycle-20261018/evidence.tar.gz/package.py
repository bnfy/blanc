from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-find-lifecycle');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-lifecycle-20261018';e.mkdir(parents=True,exist_ok=True)
assert json.loads((r/'results.json').read_text())['pass'];assert json.loads((r/'binary-unchanged.json').read_text())['unchanged'];assert json.loads((r/'preview.json').read_text())['status']==''
(r/'production.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=w));(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
files=[p for p in r.iterdir() if p.is_file() and (p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.patch'] or p.name in ['guard.log','final-guard.log','prepare-assets.log','tests.log'])]
m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 18 BFCache/private find checkpoint

Regular A→B→back A→forward B restores the same document instance markers and records
pageshow.persisted=true in both documents. Find closes at each cross-document transition,
then finds the expected two/three matches after each actual BFCache restore. Private A→B→back A
also restores the same document with persisted pageshow and successful find. No forced BFCache
flags, Playwright browser defaults or assumed reload-as-cache pass were used.

A fresh private window exposed a theme gap: direct-open Find skipped the copied panel renderer's
private-theme application. The prototype host now applies or clears that scope from its active
native tab snapshot before opening Find. This is an assets-only integration fix; copied Electron
source is unchanged. The first failing theme assertion is retained, not counted as a pass.

Private search, cross-window and inactive-tab rejection, tab-switch/navigation resets, reopen,
BFCache restore and exact active private renderer crash/reload pass. Regular listeners receive
no private search results; private Recently Closed stays empty. Disposing the private context
removes its targets, regular find still works and the regular theme remains non-private. Crash
transport/dead-runtime timeouts are retained. This tests one bounded private context, not every
multi-window/subframe/process-sharing schedule or durable profile-forensics guarantee.

No native compilation. Assets-only prepare 0.05s; final guard zero actions (3.39s); native binary
hashes identical to the prior expanded-find checkpoint. Native patch footprint remains 40 files /
96 hunks because no native/preparation source changed. Four focused regressions, host syntax and
focused lint pass. Disposable profile/server removed; original preview's two tabs restored.

Native input remains pending unlock. PDF, IME/VoiceOver, physical focus/hover/display-scale,
BFCache eviction/ineligible pages, private forward restoration, private subframe crashes and full
composed visual parity remain gaps. No Electron comparison is claimed for these lifecycle runs;
installed Electron was not launched. Visual plan item4 remains incomplete. Latency deferred;
Electron diagnostic build unapproved/unstarted; prior F12/Task0 gates unchanged.
'''
(e/'README.md').write_text('# BFCache and private find evidence\n\n'+text+f'\nAll {len(m)} archive members hash verified against `manifest.json`. Profiles and browser crash logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (w/'experiments/chromium-extension-spike'/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-lifecycle-20261018/`. No change to the Task0 cold-build column.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''\n## October 18 BFCache/private find progress

Actual regular back/forward and private back-cache restoration now pass document-identity and
persisted-pageshow proofs, find reset and fresh search. Private isolation, navigation/tab reset
and renderer crash/reload pass. Fixed direct-open private find theme in host assets only.
No native build; guard zero; binary hashes unchanged; footprint remains 40 files /96 hunks.
Evidence: `evidence/ui138-find-lifecycle-20261018/`. Native input pending unlock; broader lifecycle
and visual gaps explicit, item4 incomplete. Latency deferred; Electron diagnostic build
unapproved/unstarted; earlier F12/Task0 gates unchanged.
\n'''+s[i:]);print(len(m),'verified members')
