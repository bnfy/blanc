const http=require('node:http');const pages={
'/a':'<!doctype html><title>Cache A</title><p>alphaprobe alphaprobe</p><script>window.instance=Math.random().toString(36);window.shows=[];addEventListener("pageshow",e=>shows.push(e.persisted))</script>',
'/b':'<!doctype html><title>Cache B</title><p>betaprobe betaprobe betaprobe</p><script>window.instance=Math.random().toString(36);window.shows=[];addEventListener("pageshow",e=>shows.push(e.persisted))</script>',
'/private':'<!doctype html><title>Private fixture</title><p>privateprobe privateprobe</p>',
'/empty':'<!doctype html><title>Empty</title><p>Nothing matching.</p>'};http.createServer((q,r)=>{r.setHeader('Content-Type','text/html; charset=utf-8');r.end(pages[new URL(q.url,'http://localhost').pathname]||pages['/empty']);}).listen(9265,'127.0.0.1');
