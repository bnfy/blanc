/* global vAPI */
// GPL-3.0-or-later with the generated pinned uBO payload.
import { upstreamDeliveries } from './blanc-static-delivery.js';
import { current } from './blanc-reload-guard.js';
import logger from './logger.js';
globalThis.__blancDeliveryProbe = {enableLogger:()=>logger.readAll('blanc-fixture'),armed:null, state:current, size:()=>upstreamDeliveries.size(), events:[],resume:null};
globalThis.__blancHelperDocuments=[];
chrome.runtime.onMessage.addListener((m,s)=>{if(m?.type==='blanc-helper-entry'&&s.id===chrome.runtime.id&&s.tab&&Number.isInteger(s.frameId)&&typeof s.documentId==='string')globalThis.__blancHelperDocuments.push({file:m.file,documentId:s.documentId,frameId:s.frameId,tabId:s.tab.id,url:s.url,origin:s.origin});});
// No await separates readiness, lease acquisition and the actual API dispatch.
// The pinned API settles after execution replies, refusal, or target destruction.
// It does not identify the exact document or cover asynchronous scriptlet effects.
export function executeScript(tabId, options) {
    if ( !current().ready ) { return Promise.resolve([]); }
    const sender = {id:'upstream-api', tab:{id:tabId}, frameId:options.frameId};
    const token = upstreamDeliveries.acquire(sender);
    if ( !token ) { return Promise.resolve([]); }
    const probe=globalThis.__blancDeliveryProbe;
    const hold=probe.armed==='upstream'||(['procedural','picker'].includes(probe.armed)&&options.file==='/js/contentscript-extra.js')||(probe.armed==='logger'&&options.file==='/js/scriptlets/cosmetic-logger.js')||(probe.armed==='noscript'&&options.file==='/js/scriptlets/noscript-spoof.js');const heldPath=probe.armed;if(hold) {probe.armed=null;probe.events.push({path:heldPath,tabId,frameId:options.frameId,file:options.file});}
    try {
        return Promise.resolve(vAPI.tabs.executeScript(tabId, options)).then(async result=>{if(hold){probe.events[probe.events.length-1].resultLength=result.length;await new Promise(resolve=>{probe.resume=resolve;});probe.resume=null;}return result;}).finally(() => {
            upstreamDeliveries.acknowledge(token, sender);
        }).catch(() => []);
    } catch {
        // A synchronous throw has not queued a browser API invocation.
        upstreamDeliveries.acknowledge(token, sender);
        return Promise.resolve([]);
    }
}
