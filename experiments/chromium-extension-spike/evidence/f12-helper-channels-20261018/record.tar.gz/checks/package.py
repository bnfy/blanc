from pathlib import Path
import hashlib,json,tarfile,io
repo=Path.cwd(); base=repo/'experiments/chromium-extension-spike'; out=base/'evidence/f12-helper-channels-20261018';out.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for label,root in [('failed01',Path('/private/tmp/blanc-helper-channels-run01')),('channels02',Path('/private/tmp/blanc-helper-channels-run02')),('channels-final',Path('/private/tmp/blanc-helper-channels-run03')),('navigation',Path('/private/tmp/blanc-helper-navigation-run01')),('checks',Path('/private/tmp/blanc-helper-channels-build'))]:
 for q in root.rglob('*'):
  if q.is_file():files[label+'/'+str(q.relative_to(root))]=q
sources=['fixtures/replay/synthetic/helper-channels-run.mjs','fixtures/replay/synthetic/helper-channels-verify.mjs','fixtures/replay/synthetic/delivery-order-payload.mjs','fixtures/replay/synthetic/session.mjs']

for name in sources:files['sources/'+name]=base/name
pin=json.loads((repo/'ublock/pinned.json').read_text()); pinned={f['path']:f['sha256'] for f in pin['files']};inventory={}
for label,root in [('ordinary',Path('/private/tmp/blanc-helper-delivery-payload')),('diagnostic01',Path('/private/tmp/blanc-helper-channels-diagnostic')),('diagnostic02',Path('/private/tmp/blanc-helper-channels-diagnostic02'))]:
 inventory[label]={}
 for p in root.rglob('*'):
  if not p.is_file():continue
  rel=str(p.relative_to(root));h=digest(p);inventory[label][rel]=h
  if pinned.get(rel)!=h or rel=='LICENSE.txt':files['payload/'+label+'/'+rel]=p
files['payload/pinned.json']=repo/'ublock/pinned.json'
archive=out/'record.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):
  data=p.read_bytes();assert (b'-----BEGIN '+b'PRIVATE KEY-----') not in data
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
manifest={name:{'sha256':digest(p),'bytes':p.stat().st_size} for name,p in files.items()}
with tarfile.open(archive) as t:
 for m in t:
  data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
(out/'inventory.json').write_text(json.dumps({'archiveSha256':digest(archive),'members':manifest,'payloadFiles':inventory},indent=2)+'\n')
old=json.loads((base/'evidence/f12-delivery-order-20261018/binary-hashes.json').read_text())
for item in old['files']:assert digest(Path(item['path']))==item['sha256']
old['nativeBuild']=False;old['unchangedFrom']='249b086c';(out/'binary-hashes.json').write_text(json.dumps(old,indent=2)+'\n')
print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'verified':True,'nativeUnchanged':True}))
