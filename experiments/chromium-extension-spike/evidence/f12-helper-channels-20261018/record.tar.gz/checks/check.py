import json,subprocess
rows=[json.loads(s) for s in open('/private/tmp/blanc-all-delivery-build/invocations.jsonl')]
a=next(r['argv'] for r in rows if r['name']=='tests-final')
a += ['experiments/chromium-extension-spike/fixtures/replay/synthetic/helper-delivery-test.mjs']
raise SystemExit(subprocess.call(['python3','/private/tmp/blanc-helper-channels-build/invoke.py','tests']+a))
