from pathlib import Path
import json,hashlib,tarfile,io
repo=Path('/private/tmp/blanc-chromium157-work');base=repo/'experiments/chromium-extension-spike';out=base/'evidence/ui138-retry-lifetime-20261020';out.mkdir(exist_ok=True)
roots=[Path('/private/tmp/blanc-retry-life-'+m+'-'+c) for m in ['clear','encrypted'] for c in ['long','destroy','change']]+[Path('/private/tmp/blanc-retry-lifetime')]
rows=[];data=[]
for r in roots:
 assert not (r/'chromium-profile').exists()
 if (r/'result.json').exists():assert json.loads((r/'result.json').read_text())['pass']
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ['.mjs','.cjs','.py','.c','.json','.jsonl','.log','.txt']:
   b=p.read_bytes();name=r.name+'/'+p.name;data.append((name,b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=Path('/private/tmp/blanc-cdp.mjs').read_bytes();data.append(('blanc-cdp.mjs',b));rows.append({'path':'blanc-cdp.mjs','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for n,b in data:
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(out/'evidence.tar.gz') as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
text='''### October 20 — Retry backoff and owner/window lifecycle checks

Six disposable clear/encrypted schedules test the unchanged automatic-retry implementation. Long-backoff schedules retain eight failed flush observations with monotonic timestamps, including consecutive30-second intervals, then remove the fault, await successful acknowledgement and crash/restart to verify the new UUID/URL and unchanged source/decoy. These measure retry scheduling, not the deferred performance/latency qualification.

Owner-destruction schedules first cause a save failure, then hold the next retry inside its fallback fsync. Closing that new window before release leaves the two original windows usable; release and later crash/restart do not resurrect the closed owner and preserve source/decoy UUIDs/URLs. Changed-window schedules navigate the retry owner while that flush is held, release it, await successful current capture acknowledgement and verify the changed URL under the same UUID after restart. These are bounded navigation and window-close schedules, not every mutation, entire-profile destruction, or direct observation of every callback rejection branch.

Fault injection is confined to disposable Session paths and validates the owning PID/path. The helper forces the macOS barrier call to fail so fallback fsync can be held; no product controls or native source edits. All task profiles/servers are removed. The first clear long-run cleanup completed owned cleanup but its read-only preview fetch returned ECONNREFUSED; original failure and follow-up are retained. Subsequent cleanup records preview unavailable. Preview untouched; its tabs were not reverified.

No native compilation; guard zero actions/5.32s. Prior measured footprint49 files/117 hunks unchanged within49/120. Native input pending, latency deferred, Electron diagnostic build unapproved/unstarted. Before-ack crashes, first-ever profile persistence, recent unpersisted edits, actual provider/hardware faults, long unattended soak, mutation variants and broader lifecycle remain gaps. Disposable restart alone uses the crash-bubble bypass; no native Restore or power-loss claim.
'''
(out/'README.md').write_text('# Retry backoff and lifecycle evidence\n\n'+text+'\nArchive members: '+str(len(rows))+'. SHA-256: `'+hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()+'`.\n')
for name in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=base/name;p.write_text(p.read_text()+'\n\n'+text+'\nEvidence: [initial save boundaries](evidence/ui138-retry-lifetime-20261020/README.md).\n')
print(len(rows),hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest())
