#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
static ssize_t rawwrite(int f,const void*b,size_t n){return syscall(SYS_write,f,b,n);}
static ssize_t hook(int fd,const void*b,size_t n){const char*r=getenv("BLANC_SPACE_WRITE_BARRIER");char path[4096],prefix[4096],arm[4096],mode[64];if(!r||fcntl(fd,F_GETPATH,path))return rawwrite(fd,b,n);snprintf(prefix,sizeof(prefix),"%s/chromium-profile/Default/",r);if(strncmp(path,prefix,strlen(prefix))||!strstr(path,".BlancPrototypeSpaces.json."))return rawwrite(fd,b,n);snprintf(arm,sizeof(arm),"%s/arm",r);int f=open(arm,O_RDONLY);if(f<0)return rawwrite(fd,b,n);ssize_t k=read(f,mode,63);close(f);if(k<=0)return rawwrite(fd,b,n);mode[k]=0;int backup=strstr(mode,"backup")!=NULL;if(backup!=(strstr(path,".backup.")!=NULL))return rawwrite(fd,b,n);int err=strstr(mode,"enospc")?ENOSPC:EIO;char marker[4096],record[4600];snprintf(marker,sizeof(marker),"%s/error.json",r);f=open(marker,O_WRONLY|O_CREAT|O_TRUNC,0600);k=snprintf(record,sizeof(record),"{\"pid\":%d,\"path\":\"%s\",\"mode\":\"%s\",\"errno\":%d}",getpid(),path,mode,err);if(f>=0){rawwrite(f,record,k);close(f);}errno=err;return -1;}
__attribute__((used,section("__DATA,__interpose")))static struct{const void*a;const void*b;}i={(void*)hook,(void*)write};
