from pathlib import Path
import json,hashlib,tarfile,gzip,io
r=Path('/private/tmp/blanc-spaces-errors');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-write-errors-20261019';d.mkdir(parents=True,exist_ok=True)
rows=[]
for m in ['backup-enospc','primary-enospc','backup-eio','primary-eio']:
 p=json.loads((r/(m+'.json')).read_text());assert p['pass'];rows.append({'mode':m,'pass':True,'marker':p['marker'],'reported_error':p['failed']['spaceAutosaveError']})
(d/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
s='''## Spaces disk-full and write-error recovery — October 19, 2026

Four controlled native write-error cases pass: ENOSPC and EIO at both backup and primary temporary-file writes. The test-only interposer restricts injection to the disposable profile's exact Spaces filenames and records actual browser PID/path/errno. It returns a real syscall-style failure to Chromium's writer; the disk was not physically filled.

Each failed autosave exposes the specific checkpoint or primary-write error, preserves the complete primary, and stops autosave while errored. Backup-write failures preserve the prior backup; primary-write failures leave the validated previous primary in the checkpoint. After removing injection, an explicit save clears the error and persists the previously unsaved navigation; a further navigation then autosaves successfully. All four error/recovery cases passed. No product repair was needed.

The first cleanup verifier failed because retained-preview CDP had no host.html target. Owned fixtures had already been stopped/removed; subsequent cleanup records observed targets rather than assuming the host exists. The retained preview was not modified, but original-tab identity was not reverified this checkpoint. The failed cleanup assertion is retained. All owned disposable profiles/servers were removed.

This tests injected ENOSPC/EIO write handling, not a physically full filesystem, flush/fsync errors, rename failures, permission failures, power-loss or concurrent writers. Test-helper syscall deprecation warning retained; no signing/security changes. No Chromium compile; final guard zero/5.24s; footprint unchanged from measured41files/100hunks. Native input pending, latency deferred, Electron diagnostic build unapproved. Plan item4 and broader gates remain open. Evidence: evidence/ui138-spaces-write-errors-20261019/.
'''
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+s)
ms=[]
with (d/'evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.suffix=='.dylib':continue
    b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members')
