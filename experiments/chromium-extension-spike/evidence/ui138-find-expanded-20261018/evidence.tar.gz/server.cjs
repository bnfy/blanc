const http=require('node:http');const pages={
'/expanded':'<!doctype html><meta charset="utf-8"><title>Expanded find</title><p>café résumé 日本語</p><p>visibleprobe</p><p hidden>hiddenprobe</p><input value="inputprobe"><textarea>textareaprobe</textarea><div id="shadow"></div><iframe src="http://127.0.0.1:9266/frame"></iframe><script>document.querySelector("#shadow").attachShadow({mode:"open"}).innerHTML="<p>shadowprobe</p>"</script>',
'/frame':'<!doctype html><title>Cross origin</title><p>crossprobe crossprobe</p>',
'/next':'<!doctype html><title>Next</title><p>replacement</p>',
'/empty':'<!doctype html><title>Empty</title><p>Empty fixture.</p>'};
for(const port of[9265,9266])http.createServer((q,r)=>{r.setHeader('Content-Type','text/html; charset=utf-8');r.end(pages[new URL(q.url,'http://localhost').pathname]||pages['/empty']);}).listen(port,'127.0.0.1');
