from pathlib import Path
import hashlib,json,tarfile,subprocess
r=Path('/private/tmp/blanc-find-expanded');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-expanded-20261018';e.mkdir(parents=True,exist_ok=True)
for n in ['results.json','crash-after.json','capture.json']:assert json.loads((r/n).read_text())['pass'],n
assert json.loads((r/'preview.json').read_text())['status']==''
(r/'production.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=w));(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
files=[p for p in r.iterdir() if p.is_file() and (p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.png','.patch'] or p.name in ['build.log','plan.log','prepare.log','guard.log','final-guard.log','tests.log'])]
m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 18 expanded find and visual checkpoint

An actual crash of the exact active disposable tab left its find capsule visible. The native
owner now retires the request ID and query/count state and resets the capsule when the primary
renderer exits, without sending StopFinding to a dead renderer. The before-fix regression fails;
the final binary closes the capsule and searches successfully after navigation reload. This is
bounded regular-tab recovery, not every crash/BFCache/private lifecycle combination.

Eight queries agree with installed Electron 1.38: cross-origin iframe (different local port),
open shadow DOM, hidden text exclusion, input/textarea text, Japanese, accented text and no match.
Six component style comparisons (1280/500px, light/dark/private diagnostic theme attributes)
match rendered dimensions, colors, borders, radii, fonts and shadows for the six capsule controls.
Empty, no-match and 300-character no-match states agree on count and outer bounds. Input client/
scroll metrics differ between Chromium152 and157 (24px client difference); recorded, not hidden
or presented as full pixel equivalence. Native CSS sizing and Electron viewport emulation are
explicitly distinct. Matching-DPR clipped component captures supplement the numeric checks;
these are diagnostic theme renders, not physical private-window/input or whole-window parity.

One guarded incremental build: 41.02s wrapper /37.23s Siso, six steps from a one-action plan.
Final guard zero; budget unchanged40 upstream files /96 hunks. Four focused tests pass. No cold
output, GN/toolchain change, latency test, or Electron diagnostic build. Binary hashes recorded.
Failed window-target harness attempt and overstrict client-metric comparison retained. The
first broad crash probe did not establish exact active-target identity; only crash-before/after
with unique URLs qualify that regression. CDP crash and dead-runtime timeouts are recorded.

Disposable profiles and fixture servers removed; original two preview tabs preserved and
reopened on the final binary. Native input stays pending unlock. PDF, BFCache/back-forward,
private crash, IME, VoiceOver, physical display-scale, hover/focus and complete composed visual
parity remain gaps. Plan visual item4 remains incomplete; prior F12/Task0 gates unchanged.
Latency deferred; Electron diagnostic build remains unapproved/unstarted.
'''
(e/'README.md').write_text('# Expanded find evidence\n\n'+text+f'\nAll {len(m)} archive members verified against `manifest.json`. Profiles, private keys and raw browser crash logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (w/'experiments/chromium-extension-spike'/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-expanded-20261018/`. Build time is routine incremental work, not Task0 cold cost.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''\n## October 18 expanded find progress

Eight cross-runtime query comparisons, six component style pairs and three result states now
have bounded automated evidence. Fixed stale find UI on an exact active renderer crash; reload
recovery passes. Client/scroll metric differences are recorded; no whole-window pixel claim.
One41.02s incremental build, finalguard0,40files96hunks. Item4 remains incomplete, native input
pending unlock. Evidence: `evidence/ui138-find-expanded-20261018/`. Latency deferred; Electron
diagnostic build unapproved/unstarted; prior F12/Task0 gates unchanged.
\n'''+s[i:]);print(len(m),'verified members')
