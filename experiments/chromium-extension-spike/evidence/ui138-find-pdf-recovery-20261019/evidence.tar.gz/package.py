from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-find-pdf-recovery');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-pdf-recovery-20261019'
assert json.loads((r/'results.json').read_text())['pass']
assert json.loads((r/'cleanup.json').read_text())['status']==''
assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-find-pdf/binary-hashes.json').read_text())
(r/'source-head.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productionCodeChanged':False,'binaryUnchanged':True},indent=2))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());e.mkdir(parents=True,exist_ok=True)
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.pdf'] or p.name=='guard.log')]
m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 PDF reload/crash checkpoint

Regular and private selectable-text PDF find each return three matches before reload, after
Page.reload, after an actual outer-page renderer crash and recovery navigation, and after switching
away and reselecting the PDF tab. Reload/crash/tab transitions reset the capsule. The crashed target
rejects/times out a Runtime evaluation; crash command responses are retained. Private theme stays
private, closing the searched private PDF resets find, private Recently Closed remains empty and
private context disposal succeeds. Page.crash selected the PDF URL's outer page target: this does
not prove independent PDF plugin-process crash recovery. No physical keyboard/mouse acceptance.

No production changes or compilation. Guard zero actions (3.59s); native hashes match the prior
PDF checkpoint. Footprint remains 40 upstream files/96 hunks (not re-enumerated for evidence-only
work). Setup failures were a sandbox ps denial and immediate CDP-readiness race; both occurred
before test cases and are recorded in attempts.json. Final browser results are in results.json.
Disposable profile/server removed; existing preview tabs and empty host status verified without
relaunching the preview. No new Electron comparison, unit suite or PDF visual comparison claimed.

Remaining: independently selected PDF plugin failure, scanned/encrypted/forms and selection/wrap,
cache eviction/ineligible pages, private subframe crashes/process-sharing, IME/accessibility/full
visual parity. Native input pending unlock, latency deferred, Electron diagnostic build unapproved
and unstarted. Visual item4 and previous F12/Task0 gates remain incomplete/unchanged.
'''
(e/'README.md').write_text(text+f'\n{len(m)} archive members hash verified; profiles/raw browser logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (w/'experiments/chromium-extension-spike'/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-pdf-recovery-20261019/`. No Task0 cold-cost change.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-find-pdf-recovery-20261019/`.\n'+s[i:]);print(len(m),'verified archive members')
