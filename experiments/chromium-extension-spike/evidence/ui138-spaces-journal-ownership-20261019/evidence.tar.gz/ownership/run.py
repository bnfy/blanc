import pathlib,subprocess,json
r=pathlib.Path('/private/tmp/blanc-spaces-ownership');items=json.loads(pathlib.Path('/private/tmp/blanc-spaces-auto/remove-all-crash.json').read_text())['before']['items']
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True)
for m in ['regular','identical','private','owner-closed']:
 for n in ['arm','release','barrier.json']:(r/n).unlink(missing_ok=True)
 d=r/'chromium-profile/Default';d.mkdir(parents=True,exist_ok=True)
 (d/'BlancPrototypeSpaces.json').write_text(json.dumps({'version':1,'items':items}))
 (d/'BlancPrototypeSpaces.json.switch').write_text(json.dumps({'version':1,'id':'00000000-0000-4000-8000-000000000001','source_name':'A','source':items['A'],'destination':items['B']}))
 (r/'arm').write_text('1');run(m+'-start','node',str(r/'start.mjs'));run(m+'-check','node',str(r/'check.mjs'),m);run(m+'-cleanup','node',str(r/'cleanup.mjs'))
