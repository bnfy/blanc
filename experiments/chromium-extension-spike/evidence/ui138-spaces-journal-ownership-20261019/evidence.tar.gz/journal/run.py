import subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-spaces-journal')
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True)
for m in ['write-enospc','write-eio','flush','rename','ack']:
 for n in ['arm','error.json','events.jsonl']:(r/n).unlink(missing_ok=True)
 run(m+'-start','node',str(r/'start.mjs'));run(m+'-check','node',str(r/'check.mjs'),m)
 if m=='ack':
  run('ack-stop','node',str(r/'stop.mjs'));run('ack-restart','node',str(r/'launch.mjs'));run('ack-recover','node',str(r/'recover.mjs'))
 run(m+'-cleanup','node',str(r/'cleanup.mjs'))
