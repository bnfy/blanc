from pathlib import Path
import json,hashlib,tarfile,io,gzip
base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-journal-ownership-20261019';d.mkdir(parents=True,exist_ok=True)
r=Path('/private/tmp/blanc-spaces-journal');o=Path('/private/tmp/blanc-spaces-ownership')
results={'journal':{},'ownership':{}}
for m in ['write-enospc','write-eio','flush','rename','ack']:
 a=json.loads((r/(m+'.json')).read_text());assert a['pass'];results['journal'][m]={'pass':True,'events':a['events']}
assert json.loads((r/'ack-recover.json').read_text())['pass'];results['ack_restart_source_recovery']=True
for m in ['regular','identical','private','owner-closed']:
 a=json.loads((o/(m+'.json')).read_text());assert a['pass'] and a['savedStoreUnchanged'];results['ownership'][m]={'pass':True,'saved_store_unchanged':True,'kind':'synthetic valid intent with actual journal-read barrier'}
(d/'results.json').write_text(json.dumps(results,indent=2)+'\n')
s='''## Spaces journal failures and multiwindow ownership — October 19, 2026

Five native journal fault cases pass: ENOSPC/EIO on the actual intent temporary write, both F_BARRIERFSYNC and fallback fsync EIO, final intent rename EIO, and completion unlinkat EIO. All markers identify the disposable browser PID and exact profile-local path. The four intent failures leave source tab IDs/URLs and saved records unchanged, expose an error, then successfully switch on retry with journal clearance. Completion-clear failure retains the journal and complete saved records, refuses another save, then restores the source and clears intent on a normal uninjected restart. This is injected syscall-failure evidence, not a physically full disk, power-loss or hardware-durability claim.

Four controlled startup ownership cases pass using a synthetic valid journal plus complete saved A/B store, holding the actual journal fread while windows change. A second regular window and an identical empty regular window cause refusal: neither window changes and intent remains. A private window stays unchanged while the sole regular window automatically restores the source. Closing the candidate window before the read completes leaves the other regular window and intent unchanged. Saved A/B store bytes are unchanged in all four cases. This qualifies safe refusal/private isolation, **not successful multiwindow recovery or identification of the original restored window**. Candidate closure currently leaves recovery pending until another startup; no in-process reassignment is claimed.

Initial acknowledgement helper intercepted unlink rather than Chromium's unlinkat and missed the fault; its timeout is retained. The corrected probe observes actual unlinkat EIO. The first restart assertion ran before host initialization; retained failure, readiness wait corrected, subsequent source recovery passed. Initial intent-only ownership probes are also retained, followed by the four stronger complete-store runs. Earlier switch/restore acceptance remains unchanged.

No product code changed and no Chromium compilation ran. Final guard: zero actions / 3.72 s. Existing footprint remains 41 files / 100 hunks (no new source edits; not freshly recounted). Test helper dylibs were scoped to owned profiles and are excluded from the evidence archive; source/build logs remain. Disposables removed; retained preview untouched, host unavailable so original tabs not reverified. Plan, results and routine ledger updated; public Spaces controls remain hidden. Latency deferred; native input and Electron diagnostic build pending. Task 0/F12/visual acceptance gates remain open.

Remaining: exact durable window identity across session rebuild and both restore paths, live multiwindow recovery rather than refusal, repeated startup ordering, failure around deletion/crash/powerloss, recovery group/pin and unsaved state. Source audit below identifies the integration points; this checkpoint does not expand the patch ceiling or claim them implemented.

Evidence: `evidence/ui138-spaces-journal-ownership-20261019/`.
'''
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md','spaces-automatic-recovery.md']:
 with(base/n).open('a')as f:f.write('\n'+s)
audit='''# Durable window ownership audit — Chromium 157.0.8103.6

Source checkout pristine revision 41520584daa68d0040db7746ae562a0ff82187f6. Read-only audit; no upstream changes in this checkpoint.

- `chrome/browser/sessions/session_restore.cc:1335` receives restored window extra_data. Lines 1353–1355 assign restore_id only under IS_OZONE. Mac cannot use that ID as the prior-session identity. The subsequent extra-data handling recognizes individual existing features, not a generic Blanc token.
- `chrome/browser/sessions/session_service.cc:376` exposes AddWindowExtraData for incremental command storage. Writing a custom token once is insufficient: session rebuild must retain it too.
- `chrome/browser/sessions/session_service_base.cc:764` explicitly appends existing feature window metadata during rebuilding. A Blanc UUID would need corresponding rebuild coverage here.
- `chrome/browser/ui/browser_live_tab_context.cc:208` enumerates closed-window extra data, and the restore path around line 509 consumes named features. Both collection and restoration must retain a token if Recently Closed/window restoration can intersect pending intent.

Candidate implementation: generate an opaque browser-owned regular-window UUID; include it in intent and session window extra_data, retain it during session rebuild, and attach it to the restored BrowserWindowInterface before recovery considers that window. Reject missing/duplicate/unknown UUIDs and defer until session restoration settles. Do not reuse title, workspace, window order, URL similarity, or active focus as identity. A session save acknowledgement/durable ordering also needs proof before claiming the token survives a process crash.

Likely upstream touch points are session_service_base.cc, session_restore.cc and browser_live_tab_context.cc, none present in the current 41-file inventory. The native helper can call the existing AddWindowExtraData API without editing session_service.cc. Exact diff/hunk cost is not measured; a straightforward design would add three paths (44 total), so the present 41-file ceiling is unchanged and this implementation is not started. A patch-consolidation audit or explicit bounded budget change must precede that approach. This is a candidate integration design, not proof that three changes alone suffice.
'''
(d/'ownership-audit.md').write_text(audit)
with(base/'spaces-automatic-recovery.md').open('a')as f:f.write('\n'+audit)
ms=[]
with(d/'evidence.tar.gz').open('wb')as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for label,root in [('journal',r),('ownership',o)]:
    for p in sorted(root.iterdir()):
     if not p.is_file() or p.suffix=='.dylib':continue
     b=p.read_bytes();name=label+'/'+p.name;i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz')as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');print(len(ms),'verified members')
