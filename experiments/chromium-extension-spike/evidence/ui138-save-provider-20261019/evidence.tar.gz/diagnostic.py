from pathlib import Path
import sys,json,hashlib,difflib
r=Path('/private/tmp/blanc-save-provider');p=Path('/Users/anthonyjloria/Projects/BlancChromium157/src/components/sessions/core/command_storage_manager.cc');b=r/'manager.before.cc'
if sys.argv[1]=='restore':
 p.write_bytes(b.read_bytes());(r/'source-restored.json').write_text(json.dumps({'equal':p.read_bytes()==b.read_bytes(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}));sys.exit()
s=p.read_text();b.write_text(s)
s=s.replace('#include "base/threading/thread.h"','#include "base/threading/thread.h"\n#include "base/threading/thread_restrictions.h"')
a='CommandStorageManager::~CommandStorageManager() = default;'
c='''CommandStorageManager::~CommandStorageManager() {
  if (session_type_ == SessionType::kSessionRestore &&
      file_path_.value() == "/private/tmp/blanc-save-provider/chromium-profile/Default") {
    base::ScopedAllowBlockingForTesting allow_blocking;
    base::WriteFile(base::FilePath("/private/tmp/blanc-save-provider/manager-destroyed"),
        std::to_string(pending_encrypted_ops_.size()));
  }
}'''
assert s.count(a)==1;s=s.replace(a,c)
a='  CHECK(ShouldWriteEncryptedFiles());\n  CHECK(encrypted_backend_ == nullptr);'
c='''  // Temporary diagnostic restricted to one disposable profile.
  if (session_type_ == SessionType::kSessionRestore &&
      file_path_.value() == "/private/tmp/blanc-save-provider/chromium-profile/Default") {
    base::ScopedAllowBlockingForTesting allow_blocking;
    std::string mode;
    base::ReadFileToString(base::FilePath("/private/tmp/blanc-save-provider/diagnostic-mode"), &mode);
    if (mode == "hold") {
      base::WriteFile(base::FilePath("/private/tmp/blanc-save-provider/encryptor-held"),
          std::to_string(pending_encrypted_ops_.size()));
      base::SequencedTaskRunner::GetCurrentDefault()->PostDelayedTask(
          FROM_HERE, base::BindOnce(&CommandStorageManager::OnEncryptorReady,
              weak_factory_.GetWeakPtr(), start_time, std::move(encryptor)),
          base::Milliseconds(100));
      return;
    }
    if (mode == "empty") {
      encryptor = base::MakeRefCounted<os_crypt_async::Encryptor>(mojo::DefaultConstruct::Tag{});
      CHECK(!encryptor->IsEncryptionAvailable());
      CHECK(!encryptor->EncryptString("session-probe").has_value());
      base::WriteFile(base::FilePath("/private/tmp/blanc-save-provider/provider-unavailable"),
          "no keys; encryption unavailable; EncryptString returned nullopt");
    }
  }
'''+a
assert s.count(a)==1;s=s.replace(a,c);p.write_text(s)
(r/'diagnostic.patch').write_text(''.join(difflib.unified_diff(b.read_text().splitlines(True),s.splitlines(True),fromfile='a/components/sessions/core/command_storage_manager.cc',tofile='b/components/sessions/core/command_storage_manager.cc')))
