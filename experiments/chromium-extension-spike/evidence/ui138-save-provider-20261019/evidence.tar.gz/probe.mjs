import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const r='/private/tmp/blanc-save-provider',mode=process.argv[2],p={mode},cs=[],disk=r+'/chromium-profile/Default/BlancPrototypeSpaces.json';
const wait=async(fn,test)=>{for(let i=0;i<500;i++){const v=await fn().catch(()=>null);if(test(v))return v;await pause(50)}throw Error('timeout')};
const api=(h,m,...a)=>h.eval(`BlancPrototypeHost.api.${m}(...${JSON.stringify(a)})`);
const hosts=async()=>{const ts=await fetch('http://127.0.0.1:9258/json/list').then(x=>x.json());const a=[];for(const t of ts.filter(t=>t.url.includes('host.html'))){const h=await connect(t);cs.push(h);const s=await api(h,'getAllTabs').catch(()=>null);if(s)a.push({h,s})}return a};
try {
 const seed=JSON.parse(fs.readFileSync(r+'/seed.json'));const hs=await wait(hosts,v=>v?.length===2),source=hs.find(v=>v.s.spaceWindowIdentity===seed.source.spaceWindowIdentity);assert(source);await api(source.h,'previewSpaceSave','A');
 if(mode==='normal') {await api(source.h,'previewSpaceOpen','B');p.normalSwitch=await wait(()=>api(source.h,'getAllTabs'),s=>s?.spaceName==='B'&&s.tabs.length===2&&!s.tabs.some(t=>t.isLoading)&&!fs.existsSync(disk+'.switch'));}else if(mode==='provider-empty') {
  p.provider=fs.readFileSync(r+'/provider-unavailable','utf8');p.errors=[];assert(!fs.existsSync(r+'/chromium-profile/Default/Sessions')||!fs.readdirSync(r+'/chromium-profile/Default/Sessions').some(n=>n.startsWith('Session_')));p.noCleartextSessionFallback=true;
  for(let i=0;i<2;i++){let err;try{await api(source.h,'previewSpaceOpen','B')}catch(e){err=String(e)}assert(err?.includes('Session metadata save failed'));p.errors.push(err);assert.deepEqual((await api(source.h,'getAllTabs')).tabs.map(t=>t.url),seed.source.tabs.map(t=>t.url));assert(!fs.existsSync(disk+'.switch'));await pause(200);}
 }else{
  await source.h.eval("globalThis.ackOutcome='pending';BlancPrototypeHost.api.previewSpaceOpen('B').then(()=>ackOutcome='success',e=>ackOutcome=String(e));true");await pause(700);assert.equal(await source.h.eval('ackOutcome'),'pending');assert(!fs.existsSync(disk+'.switch'));
  if(mode==='profile-encryptor'){p.queued=Number(fs.readFileSync(r+'/encryptor-held','utf8'));assert(p.queued>=2);}
  else{p.marker=JSON.parse(fs.readFileSync(r+'/marker.json'));assert.equal(p.marker.pid,Number(fs.readFileSync(r+'/chromium.pid')));assert.equal(fs.statSync(p.marker.path).size,0);}
 }
 assert.deepEqual(JSON.parse(fs.readFileSync(disk)),seed.store);
 const b=await connect(await fetch('http://127.0.0.1:9258/json/version').then(x=>x.json()));cs.push(b);b.send('Browser.close').catch(()=>{});
 if(mode!=='normal')p.managerDestroyed=await wait(async()=>fs.readFileSync(r+'/manager-destroyed','utf8'),v=>typeof v==='string');
 if(mode==='profile-encryptor')assert(Number(p.managerDestroyed)>=2);
 if(mode==='profile-write')fs.writeFileSync(r+'/release','1');
 p.exit=await wait(async()=>JSON.parse(fs.readFileSync(r+'/exit.json')),v=>v&&Number.isInteger(v.returncode));assert.equal(p.exit.returncode,0);
 assert(!fs.existsSync(disk+'.switch'));p.storeAfterExit=JSON.parse(fs.readFileSync(disk));assert.deepEqual(p.storeAfterExit,seed.store);
 fs.rmSync(r+'/diagnostic-mode',{force:true});fs.rmSync(r+'/exit.json',{force:true});
 execFileSync(process.execPath,[r+'/launch.mjs'],{env:{...process.env,ACK_ENCRYPTED:'1'}});
 const next=await wait(hosts,v=>v?.length>=1);const h=next[0].h;await wait(()=>api(h,'getAllTabs'),s=>s?.tabs.length>0&&!s.tabs.some(t=>t.isLoading));await pause(700);assert.deepEqual(JSON.parse(fs.readFileSync(disk)),seed.store);await api(h,'previewSpaceSave','C');await api(h,'previewSpaceOpen','B');p.restart=await wait(()=>api(h,'getAllTabs'),s=>s?.spaceName==='B'&&s.tabs.length===2&&!s.tabs.some(t=>t.isLoading)&&!fs.existsSync(disk+'.switch'));p.pass=true;
}catch(e){p.pass=false;p.error=String(e);p.stack=e.stack;fs.writeFileSync(r+'/release','1');fs.rmSync(r+'/diagnostic-mode',{force:true});}
finally{cs.forEach(c=>c.close());fs.writeFileSync(r+'/'+mode+'.json',JSON.stringify(p,null,2));console.log({mode,pass:p.pass,error:p.error})}
if(!p.pass)process.exitCode=1;
