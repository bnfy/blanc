import subprocess,sys,pathlib,json
r=pathlib.Path("/private/tmp/blanc-save-provider")
p=subprocess.Popen(sys.argv[1:]);(r/"chromium.pid").write_text(str(p.pid));code=p.wait();(r/"exit.json").write_text(json.dumps({"pid":p.pid,"returncode":code}))
