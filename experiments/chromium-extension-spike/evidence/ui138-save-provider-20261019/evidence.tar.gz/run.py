import os,pathlib,subprocess,sys,shutil
r=pathlib.Path('/private/tmp/blanc-save-provider');mode=sys.argv[1]
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),mode+'-'+n,*a],check=True,env=env)
for n in ['arm','release','marker.json','diagnostic-mode','encryptor-held','provider-unavailable','manager-destroyed','exit.json','chromium.pid']:(r/n).unlink(missing_ok=True)
env={**os.environ,'ACK_ENCRYPTED':'1'}
if mode=='profile-write':(r/'arm').write_text('1');env.update(INJECT='1',SESSION_MODE='write')
elif mode!='normal':(r/'diagnostic-mode').write_text('empty' if mode=='provider-empty' else 'hold')
run('start','node',str(r/'start.mjs'),env=env);run('seed','node',str(r/'check.mjs'),'seed');run('proof','node',str(r/'probe.mjs'),mode);run('cleanup','node',str(r/'cleanup.mjs'));shutil.copyfile(r/'cleanup.json',r/(mode+'-cleanup.json'))
