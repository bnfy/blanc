import subprocess
b='/private/tmp/blanc-static-recovery-build';r='experiments/chromium-extension-spike';config='/private/tmp/blanc-codeql-final-build/config.json';payload='/private/tmp/blanc-static-recovery-payload'
for name,args in [
 ('race-proof',['node',r+'/fixtures/replay/synthetic/static-race-verify.mjs','/private/tmp/blanc-static-recovery-race-final']),
 ('integration',['node',r+'/fixtures/replay/synthetic/static-integration-run.mjs',config,payload,'/private/tmp/blanc-static-recovery-integration']),
 ('policy',['node',r+'/fixtures/replay/synthetic/static-policy-run.mjs',config,payload,'/private/tmp/blanc-static-recovery-policy']),
 ('readiness',['node',r+'/ubo-readiness-probe.mjs',config,payload,b+'/readiness.json']),
 ('unready',['node',r+'/ubo-readiness-probe.mjs',config,'/private/tmp/blanc-codeql-final-unready',b+'/unready.json','--unready']),
 ('guard',['node',r+'/build.mjs','/Users/anthonyjloria/Projects/BlancChromium157/src','--check'])]:
 subprocess.run(['python3',b+'/invoke.py',name]+args,check=True)
