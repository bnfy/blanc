const http=require('node:http'),fs=require('node:fs');const pdf=fs.readFileSync('/private/tmp/blanc-find-plugin/fixture.pdf');const marker='<script>window.instance=Math.random().toString(36);window.shows=[];addEventListener("pageshow",e=>shows.push(e.persisted))</script>';const pages={
'/a':'<!doctype html><title>Private A</title><p>alphaprobe alphaprobe</p>'+marker,
'/b':'<!doctype html><title>Private B</title><p>betaprobe betaprobe betaprobe</p>'+marker,
'/parent':'<!doctype html><title>Frame parent</title><p>parentprobe</p><iframe src="http://localhost:9266/child"></iframe>',
'/child':'<!doctype html><title>Child</title><p>childprobe childprobe</p>'};
for(const port of[9265,9266])http.createServer((q,r)=>{const path=new URL(q.url,'http://localhost').pathname;if(path==='/fixture.pdf'){r.writeHead(200,{'Content-Type':'application/pdf','Content-Length':pdf.length});return r.end(pdf);}r.setHeader('Content-Type','text/html; charset=utf-8');r.end(pages[path]||pages['/a']);}).listen(port,'127.0.0.1');
