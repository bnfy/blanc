from pathlib import Path
import json,hashlib,tarfile,io
repo=Path('/private/tmp/blanc-chromium157-work');base=repo/'experiments/chromium-extension-spike';out=base/'evidence/ui138-retry-profile-20261020';out.mkdir(exist_ok=True)
roots=[Path('/private/tmp/blanc-retry-wide-'+m+'-'+c) for m in ['clear','encrypted'] for c in ['profile','tabs','pin']]+[Path('/private/tmp/blanc-retry-profile')]
rows=[];data=[]
for r in roots:
 assert not (r/'chromium-profile').exists()
 if (r/'result.json').exists():assert json.loads((r/'result.json').read_text())['pass']
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ['.mjs','.cjs','.py','.c','.json','.jsonl','.log','.txt']:
   b=p.read_bytes();name=r.name+'/'+p.name;data.append((name,b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=Path('/private/tmp/blanc-cdp.mjs').read_bytes();data.append(('blanc-cdp.mjs',b));rows.append({'path':'blanc-cdp.mjs','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for n,b in data:
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(out/'evidence.tar.gz') as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
text='''### October 20 — Retry-specific profile shutdown and tab mutations

Six clear/encrypted disposable schedules exercise the unchanged normal binary. Each first forces initial-window flush failure, then holds the next retry's fallback fsync. Full-browser shutdown is requested while held; releasing the flush allows the process to exit. Restart restores source, decoy and new window UUIDs/URLs. This covers full-browser shutdown and its profile lifetime, not hot deletion of one profile while another remains alive, nor a directly instrumented Profile destructor ordering claim.

Mutation schedules add two tabs and remove the captured original tab during the held retry, or add two tabs and pin the last tab (moving it to the front). After release, a current-state save acknowledgement is observed. An abrupt process crash followed by restart retains exact ordered URLs and pinned flags under the same window UUID, while source/decoy UUIDs and URLs stay unchanged. The pin schedule also requests active-tab selection, but active selection is not asserted across restart and is not qualified here. These are bounded structural changes, not arbitrary grouping, split/move-window, beforeunload, mutation during callback dispatch or every stale-callback branch.

All six task profiles/servers removed; retained preview untouched and unavailable to read-only verification, so its tabs were not reverified. Tests use cleanly primed disposable profiles, explicit clear/encrypted feature flags and disposable restart crash-bubble bypass. No native input claim. No native source change or compilation; final guard zero actions/5.17s. Previous measured footprint49 files/117 hunks unchanged within49/120. Latency deferred; Electron diagnostic build unapproved/unstarted. Hot profile deletion, actual provider/hardware failures, before-ack crash loss, first-ever profile initialization, unpersisted recent edits and broader mutation/lifecycle remain open.
'''
(out/'README.md').write_text('# Retry profile shutdown and mutation evidence\n\n'+text+'\nArchive members: '+str(len(rows))+'. SHA-256: `'+hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()+'`.\n')
for name in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=base/name;p.write_text(p.read_text()+'\n\n'+text+'\nEvidence: [initial save boundaries](evidence/ui138-retry-profile-20261020/README.md).\n')
print(len(rows),hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest())
