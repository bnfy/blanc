import sys,subprocess,time,datetime,json,os
root='/private/tmp/blanc-f12-shared-lifecycle'
name=sys.argv[1];argv=sys.argv[2:]
start=time.monotonic();row={'stage':name,'argv':argv,'cwd':os.getcwd(),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'tranche-2 routine harness; never Task0 cold or latency'}
with open(root+'/invocations.jsonl','a') as file:file.write(json.dumps(row)+'\n')
with open(root+'/'+name+'.log','w') as log:
 process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 for line in process.stdout:log.write(line);log.flush();print(line,end='',flush=True)
 code=process.wait()
row.update(end=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,exit_code=code)
with open(root+'/invocations.jsonl','a') as file:file.write(json.dumps(row)+'\n')
print(json.dumps(row),flush=True);sys.exit(code)
