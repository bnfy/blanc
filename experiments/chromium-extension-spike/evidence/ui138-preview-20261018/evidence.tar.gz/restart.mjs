import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const ts=await fetch('http://127.0.0.1:9248/json/list').then(r=>r.json());const h=await connect(ts.find(t=>t.url.includes('host.html')));
await h.eval(`(async()=>{const a=BlancPrototypeHost.api;const s=await a.getAllTabs();for(const t of s.tabs.slice(1))await a.closeTab(t.id);})()`);
try{await h.send('Browser.close')}catch{}h.close();await pause(500);
