import { ESLint } from '/private/tmp/blanc-electron-drag-fix/node_modules/eslint/lib/api.js';
import js from '/private/tmp/blanc-electron-drag-fix/node_modules/@eslint/js/src/index.js';
import globals from '/private/tmp/blanc-electron-drag-fix/node_modules/globals/index.js';
const e=new ESLint({overrideConfigFile:true,overrideConfig:[{files:['**/*.js','**/*.mjs'],languageOptions:{globals:{...globals.node,...globals.browser,chrome:'readonly',state:'writable',renderLedgerFavorites:'readonly',invalidate:'readonly',applyLayout:'readonly'}},rules:{...js.configs.recommended.rules,'no-unused-vars':'off'}}]});
const r=await e.lintFiles(['experiments/chromium-extension-spike/prototype/{host,adapter,newtab-adapter}.js','experiments/chromium-extension-spike/prepare.mjs']);console.log((await e.loadFormatter('stylish')).format(r));console.log(JSON.stringify({files:r.length,errors:r.reduce((n,x)=>n+x.errorCount,0)}));process.exitCode=r.some(x=>x.errorCount)?1:0;
