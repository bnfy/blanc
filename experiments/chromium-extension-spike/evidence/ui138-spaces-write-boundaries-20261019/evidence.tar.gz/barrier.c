#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static ssize_t rawwrite(int f,const void*b,size_t n){return syscall(SYS_write,f,b,n);}
static const char* root(void){return getenv("BLANC_SPACE_WRITE_BARRIER");}
static int armed(char*mode){char p[4096];if(!root())return 0;snprintf(p,sizeof(p),"%s/arm",root());int f=open(p,O_RDONLY);if(f<0)return 0;ssize_t n=read(f,mode,63);close(f);if(n<=0)return 0;mode[n]=0;return 1;}
static int consume(void){char p[4096];snprintf(p,sizeof(p),"%s/arm",root());return unlink(p)==0;}
static void stop(const char*mode,const char*path,size_t requested,ssize_t written){char p[4096],b[5000];snprintf(p,sizeof(p),"%s/barrier.json",root());int f=open(p,O_CREAT|O_TRUNC|O_WRONLY,0600);int n=snprintf(b,sizeof(b),"{\"pid\":%d,\"mode\":\"%s\",\"path\":\"%s\",\"requested\":%zu,\"written\":%zd}",getpid(),mode,path,requested,written);if(f>=0){rawwrite(f,b,n);fsync(f);close(f);}snprintf(p,sizeof(p),"%s/release",root());time_t end=time(NULL)+30;while(access(p,F_OK)&&time(NULL)<end)usleep(10000);}
static ssize_t hookwrite(int f,const void*b,size_t n){char mode[64],path[4096],prefix[4096];if(n<4||!armed(mode)||strcmp(mode,"backup-write")||fcntl(f,F_GETPATH,path))return rawwrite(f,b,n);snprintf(prefix,sizeof(prefix),"%s/chromium-profile/Default/",root());if(strncmp(path,prefix,strlen(prefix))||!strstr(path,".BlancPrototypeSpaces.json.backup.")||!consume())return rawwrite(f,b,n);ssize_t w=rawwrite(f,b,n/2);stop(mode,path,n,w);return w;}
static int hookrename(const char*from,const char*to){char mode[64],expected[4096];if(!armed(mode)||!strncmp(mode,"backup-write",12))return syscall(SYS_rename,from,to);int backup=strstr(mode,"backup")!=NULL;snprintf(expected,sizeof(expected),"%s/chromium-profile/Default/BlancPrototypeSpaces.json%s",root(),backup?".backup":"");if(strcmp(to,expected)||!consume())return syscall(SYS_rename,from,to);if(!strncmp(mode,"before-",7)){stop(mode,from,0,0);return syscall(SYS_rename,from,to);}int rc=syscall(SYS_rename,from,to);if(rc==0)stop(mode,to,0,0);return rc;}
__attribute__((used,section("__DATA,__interpose"))) static struct{const void*replacement;const void*replacee;} hooks[]={{(void*)hookwrite,(void*)write},{(void*)hookrename,(void*)rename}};
