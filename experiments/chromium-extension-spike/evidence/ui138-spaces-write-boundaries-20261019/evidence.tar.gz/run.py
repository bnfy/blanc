import subprocess,pathlib,sys
r=pathlib.Path('/private/tmp/blanc-spaces-boundaries')
def run(name,*args):subprocess.run(['python3',str(r/'invoke.py'),name,*args],check=True)
for mode in ['backup-write','before-backup','after-backup','before-primary','after-primary']:
 for n in ['arm','release','barrier.json']:(r/n).unlink(missing_ok=True)
 run(mode+'-start','node',str(r/'start.mjs'))
 run(mode+'-interrupt','node',str(r/'check.mjs'),mode,'interrupt')
 run(mode+'-restart','node',str(r/'launch.mjs'))
 run(mode+'-recover','node',str(r/'check.mjs'),mode,'recover')
 run(mode+'-cleanup','node',str(r/'cleanup.mjs'))
 (r/(mode+'-cleanup.json')).write_bytes((r/'cleanup.json').read_bytes())
