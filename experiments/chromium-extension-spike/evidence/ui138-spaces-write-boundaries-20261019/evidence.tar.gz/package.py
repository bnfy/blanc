from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-spaces-boundaries');base=Path('experiments/chromium-extension-spike');d=base/'evidence/ui138-spaces-write-boundaries-20261019';d.mkdir(parents=True,exist_ok=True)
modes=['backup-write','before-backup','after-backup','before-primary','after-primary'];rows=[]
for m in modes:
 a=json.loads((r/(m+'-interrupt.json')).read_text());b=json.loads((r/(m+'-recover.json')).read_text());assert a['pass'] and b['pass'];rows.append(dict(mode=m,interruption_pass=True,restart_reopen_resave_pass=True,barrier=a['barrier']))
(d/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
s='''## Spaces backup and atomic-replacement boundaries — October 19, 2026

Five actual disposable-process interruption cases pass, each followed by restart without injection, native Space listing/reopening and a subsequent successful save:

- Backup temporary write interrupted at94/188bytes: complete primary and previous backup unchanged.
- Immediately before backup rename: complete primary and previous backup unchanged.
- Immediately after successful backup rename: primary unchanged and backup equals the previous primary.
- Immediately before primary rename: primary unchanged and backup equals it.
- Immediately after successful primary rename: new complete primary retained, backup equals old primary; restart restores the new navigation.

The test-only interposer matches the exact owned profile path and backup/primary destination, consumes a one-shot arm and emits a PID/path marker before waiting. The harness verifies the owned PID and on-disk generations before SIGKILL. These are controlled before/after rename boundaries, not a kill inside the kernel rename operation. Partial backup size is checked on disk. All five cases passed on the first attempt in this checkpoint. Helper direct-syscall deprecation warnings remain in the archive; no signing/security settings were changed.

This qualifies bounded process-crash recovery, not power-loss durability, fsync failure, disk-full/I/O errors, concurrent writers or switch-mid-transaction recovery. No product changes or Chromium compilation; final guard zero actions/3.61s. Footprint unchanged from measured41files/100hunks. Five owned profiles/servers cleaned and retained preview tabs preserved. Native input pending, latency deferred, Electron diagnostic build unapproved. Plan item4 and broader acceptance remain open. Evidence: evidence/ui138-spaces-write-boundaries-20261019/.
'''
(d/'README.md').write_text(s)
for n in ['tranche2-request.md','results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+s)
ms=[]
with (d/'evidence.tar.gz').open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.suffix=='.dylib':continue
    b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b));ms.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n')
(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes())
print(len(ms),'verified members; five interruption and five restart/reopen/resave cases pass')
