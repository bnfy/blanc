from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-group-persist-runtime');b=Path('/private/tmp/blanc-group-persist-fix');w=Path('/private/tmp/blanc-chromium157-work');base=w/'experiments/chromium-extension-spike';e=base/'evidence/ui138-group-persistence-fix-20261019'
for state in ['true','false']:
 for phase in ['cross','closed-crash','window-crash']:
  x=json.loads((r/f'{phase}-{state}.json').read_text());assert x['completed'] and x['pass'] and x['collapsedMatches']
assert json.loads((r/'cleanup.json').read_text())['profilesRemoved'];p=json.loads((r/'preview.json').read_text());assert p['tabs']==['blanc://newtab/','https://chromewebstore.google.com/category/extensions'] and not p['status']
q=json.loads((b/'patch-budget.json').read_text());assert q['within_budget'] and q['upstream_files']==41
errors=[x for x in (r/'chromium.log').read_text().splitlines() if 'FATAL' in x or 'DanglingPtr' in x];assert not errors;(r/'log-check.json').write_text(json.dumps(dict(errors=errors)))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
(b/'native.patch').write_bytes(subprocess.check_output(['git','diff','--','components/sessions/core/tab_restore_service_impl.cc'],cwd='/Users/anthonyjloria/Projects/BlancChromium157/src'))
files={}
for root,prefix in [(r,'runtime'),(b,'build')]:
 for p in root.iterdir():
  if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.patch'] or (prefix=='build' and p.suffix=='.log')):files[prefix+'/'+p.name]=p
m={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())};e.mkdir(parents=True,exist_ok=True)
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text=f'''## October 19 closed-group persistence repair

The pinned closed-group writer now appends the collapsed boolean after its existing timestamp.
The reader optionally reads that trailing field, initialized false for legacy records. The
existing record prefix/command ID is unchanged; old readers ignore the extra field. This
compatibility conclusion is source-backed, not a legacy-binary runtime acceptance claim.
Already-written old records have no recoverable collapse bit and still restore expanded.
The transform has exact anchors and independent presence markers for repeat preparation.

All six strict final-binary native bridge cases pass: collapsed blue and expanded pink,
each restored cross-window, from a persisted closed-group entry after SIGKILL, and as a
saved whole window after a second SIGKILL. Exact colors/names/two-tab membership survive;
the same-named decoy stays unchanged. Four kills verify the owned profile and Crashed marker,
with bounded six-second persistence waits. This repairs the previously archived failing
collapsed closed-group case. No native-button, power-loss or mid-write syscall claim.

One guarded incremental build:30.42s Siso/35.98s wrapper,six steps. Final guard0/6.00s.
Fresh footprint **41 upstream files / {q['hunks']} hunks**, within the narrow October19 amendment
(41/120) applying the owner's earlier allowance to raise the40-file ceiling if needed.
Only new upstream path:components/sessions/core/tab_restore_service_impl.cc. No other budget,
scope, GN/toolchain/cache or acceptance relaxation. Future patch-consolidation audit remains.
Eleven patch-counter tests and two-module scoped ESLint pass; syntax and whitespace pass.
Initial npx ESLint attempt could not resolve the registry; existing local ESLint was used.

Disposable profile/server removed; final preview restarted with original two tabs/empty status.
Native input pending unlock, latency deferred, Electron diagnostic build unapproved/unstarted.
Legacy/malformed trailing field runtime, private/multi-profile/unsaved/multiple concurrent
restores, mid-write/OS reboot and broader lifecycle/visual cases remain gaps. EarlierF12/Task0
and planitem4 remain open. Cold-build column unchanged; this is routine repair/testing.
'''
(e/'README.md').write_text(text+f'\n{len(m)} hash-verified archive members; profiles/raw browser logs excluded.\n')
for n in ['results.md','rebase-ledger.md','ui-refresh-20261018.md']:
 with (base/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-group-persistence-fix-20261019/`.\n')
p=base/'tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-group-persistence-fix-20261019/`.\n'+s[i:]);print(len(m),'verified members',q['hunks'],'hunks')
