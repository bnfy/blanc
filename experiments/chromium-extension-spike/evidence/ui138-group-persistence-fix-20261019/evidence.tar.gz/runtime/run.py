from pathlib import Path
import subprocess,json,time
r=Path('/private/tmp/blanc-group-persist-runtime')
def run(script,*args):
 t=time.time();p=subprocess.run(['node','--experimental-websocket',str(r/script),*args],capture_output=True,text=True)
 with (r/'invocations.jsonl').open('a') as f:f.write(json.dumps(dict(script=script,args=args,seconds=time.time()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 print(script,args,p.returncode,p.stdout,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for collapse in ['true','false']:
 if (r/'chromium.pid').exists():run('cleanup.mjs')
 run('start.mjs');run('check.mjs','cross',collapse);run('kill.mjs');(r/f'kill-closed-{collapse}.json').write_bytes((r/'kill.json').read_bytes());run('normal-relaunch.mjs');run('check.mjs','closed-crash',collapse);run('kill.mjs');(r/f'kill-window-{collapse}.json').write_bytes((r/'kill.json').read_bytes());run('normal-relaunch.mjs');run('check.mjs','window-crash',collapse)
run('cleanup.mjs')
