import pathlib,subprocess,os,json,copy
r=pathlib.Path('/private/tmp/blanc-preserve-negatives');env={**os.environ,'ACK_ENCRYPTED':'1','PATH':'/Users/anthonyjloria/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
def run(name,*args,restore=False):
 subprocess.run(['python3',str(r/'invoke.py'),name,*args],env={**env,**({'RESTORE':'1'} if restore else {})},check=True)
try:
 run('start','node',str(r/'start.mjs'));run('seed','node',str(r/'check.mjs'),'seed');run('seed-close','node',str(r/'close.mjs'))
 disk=r/'chromium-profile/Default/BlancPrototypeSpaces.json';s=json.loads((r/'seed.json').read_text());(r/'store-before.txt').write_bytes(disk.read_bytes())
 base=dict(version=2,id='journal-validation',source_window=s['source']['spaceWindowIdentity'],source_name='A',source=s['store']['items']['A'],destination=s['store']['items']['B'])
 cases={}
 cases['truncated']='{"version":2,'
 for mode in ['unknown-version','missing-identity','wrong-identity-type','invalid-active','unsafe-url','invalid-group','valid']:
  x=copy.deepcopy(base)
  if mode=='unknown-version':x['version']=99
  if mode=='missing-identity':del x['source_window']
  if mode=='wrong-identity-type':x['source_window']=17
  if mode=='invalid-active':x['source']['active']=999
  if mode=='unsafe-url':x['source']['tabs'][0]['url']='file:///etc/passwd'
  if mode=='invalid-group':x['source']['tabs'][0]['group']=99
  cases[mode]=json.dumps(x)
 for mode,data in cases.items():
  pathlib.Path(str(disk)+'.switch').write_text(data);(r/'journal-before.txt').write_text(data)
  run(mode+'-restart','node',str(r/'launch.mjs'),restore=True)
  run(mode+'-proof','node',str(r/'verify.mjs'),mode)
  run(mode+'-close','node',str(r/'close.mjs'))
finally:
 run('cleanup','node',str(r/'cleanup.mjs'))
