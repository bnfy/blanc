import os,subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-state-preserve');env={**os.environ,'PATH':'/Users/anthonyjloria/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
def run(n,*a):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
try:
 run('start','node',str(r/'start.mjs'));run('seed','node',str(r/'check.mjs'),'seed');run('prime-close','node',str(r/'close.mjs'));env['RESTORE']='1';run('prime-restart','node',str(r/'launch.mjs'));run('state-proof','node',str(r/'state.mjs'))
finally:run('cleanup','node',str(r/'cleanup.mjs'))
