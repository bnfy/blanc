from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/private/tmp/blanc-state-preserve');o=Path('/private/tmp/blanc-overlap-immediate');n=Path('/private/tmp/blanc-preserve-negatives');e=Path('/private/tmp/blanc-chromium157-work/experiments/chromium-extension-spike');d=e/'evidence/ui138-state-preservation-20261019';d.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
a=read(r/'baseline.json');b=read(r/'before-fix-state.json');f=read(r/'fixed-state.json');assert a['unsavedFormRecovered'] and a['scrollRecovered'];assert not b['unsavedFormRecovered'] and not b['scrollRecovered'];assert f['unsavedFormRecovered'] and f['scrollRecovered'];assert all(read(n/(x+'.json'))['pass'] for x in ['truncated','unknown-version','missing-identity','wrong-identity-type','invalid-active','unsafe-url','invalid-group','valid'])
for root in [r,o,n]:assert not(root/'chromium-profile').exists()
rows=[json.loads(x) for x in (r/'invocations.jsonl').read_text().splitlines()];guard=round(next(x['seconds'] for x in rows if x['name']=='final-guard'),2)
summary={'ordinary_settled_state':{'form':a['unsavedFormRecovered'],'scroll':a['scrollRecovered']},'old_rollback':{'form':b['unsavedFormRecovered'],'scroll':b['scrollRecovered']},'fixed_rollback':{'form':f['unsavedFormRecovered'],'scroll':f['scrollRecovered']},'immediate_crash':'structure recovers, recent edits absent in both ordinary and Spaces cases; prior timeout not reproduced/cause unresolved','negative_regressions':8,'unit_tests':5,'incremental_wrapper_seconds':42.84,'siso_seconds':36.46,'guard_seconds':guard,'upstream_footprint':'prior49/114 unchanged; only Blanc-owned source changed','native_input':'pending','latency':'deferred','electron_diagnostic_build':'unapproved','remaining':['partial source reconstruction has only saved structural state','edits not yet persisted by Chromium cannot be recovered','original immediate timeout remains unresolved','broader lifecycle and power loss']}
(r/'results.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile('/private/tmp/blanc-cdp.mjs',r/'blanc-cdp.mjs')
text=f'''## Preserve session-restored page state during Spaces rollback — October 19, 2026

The old rollback reopened every source URL even when Chromium had already restored the exact source window, destroying its restored page state. After the existing durable UUID, SessionRestore-in-progress, capture and live-tab-ID guards, a complete matching session-restored window is now retained. Its existing tab IDs enter the same completion/journal-clear checks. Mismatching/partially staged windows continue through the existing source reconstruction path. No renderer form extraction or extra plaintext form storage is introduced.

A named authored form populated through CDP Input.insertText and a 700px scroll establish the regression: ordinary settled session restoration retains both; old Spaces rollback loses both; the fixed binary retains both. The earlier fixture used autocomplete=off and direct value assignment, so it was not an adequate guarantee of Chromium form serialization; that limitation is corrected explicitly rather than rewriting historical evidence. beforeunload refusal remains passing. Eight malformed/valid-journal regressions and five focused capture/identity tests pass.

Immediate-crash investigation: cleanly primed two-window and held-read/overlapping three-window repeats recover the expected structural state without the four-second settling pause, but lose very recent form/scroll updates. A no-Spaces immediate control loses those updates too. Source audit records Chromium's delayed page-state synchronization and 2.5-second session-save timer. This explains the unpersisted-state limitation, not the original timeout: **that earlier timeout was not reproduced and its cause remains unresolved**. A separate unprimed control timed out with one new window, retained as a profile-initialization limitation; it must not be substituted as proof of the historical timeout's cause.

This fix preserves state Chromium actually restored. It does not serialize arbitrary DOM state, recover edits lost before session persistence, or retain forms when a partially staged window must be reconstructed from URL/group/pin records. Full unsaved-state and lifecycle acceptance remains open. Password/disabled-autocomplete semantics remain Chromium-owned. Nonowner recovery-status errors remain a separate gap.

One guarded incremental build:42.84s wrapper/36.46s Siso/six steps. Final guard zero/{guard}s. Only Blanc-owned source changes; prior measured49files/114hunks unchanged within49/120, not re-enumerated. Test interposer compilation is separate from native build cost. No cold output, GN or toolchain changes. Disposable profiles/servers removed; retained preview untouched/unavailable. Test-only crash-bubble bypass is not native input acceptance. Latency deferred; native input pending; Electron diagnostic build unapproved/unstarted. Evidence: `evidence/ui138-state-preservation-20261019/`.
'''
files=[]
for label,root in [('state',r),('overlap',o),('negative',n)]:
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix in ['.json','.jsonl','.log','.mjs','.cjs','.py','.c','.cc','.txt']:files.append((label+'/'+p.name,p))
manifest=[dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in files]
with tarfile.open(d/'evidence.tar.gz','w:gz') as t:
 for name,p in files:t.add(p,arcname=name)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in manifest:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copyfile(r/'results.json',d/'results.json');shutil.copyfile(r/'invocations.jsonl',d/'invocations.jsonl')
text+=f'\n{len(files)} archived members SHA-256 verified; failed/control results remain included.\n';(d/'README.md').write_text(text)
for name in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=e/name;p.write_text(p.read_text()+'\n'+text)
print(len(files))
