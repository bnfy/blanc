from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image
from pypdf import PdfReader,PdfWriter
import random,json
r=Path('/private/tmp/blanc-find-password');c=canvas.Canvas(str(r/'plain.pdf'))
for i in range(2):
 c.drawString(60,780,'Password fixture');c.drawString(60,720,'secretprobe');c.showPage()
c.save();w=PdfWriter();w.append(str(r/'plain.pdf'));w.encrypt('fixture-only-729',owner_password='fixture-owner-729',algorithm='AES-256');w.write(str(r/'protected.pdf'))
p=PdfReader(r/'protected.pdf');assert p.is_encrypted;assert not p.decrypt('wrong');assert p.decrypt('fixture-only-729');assert len(p.pages)==2
im=Image.frombytes('RGB',(2000,2000),random.Random(729).randbytes(12000000));c=canvas.Canvas(str(r/'large.pdf'))
for i in range(250):
 c.setFont('Helvetica',12);c.drawString(60,790,f'Large fixture page {i+1}');c.drawString(60,760,'pageprobe')
 if i==0:c.drawImage(ImageReader(im),60,100,width=480,height=480)
 else:
  for k in range(40):c.drawString(60,730-k*15,f'Authored body row {k+1} on page {i+1}')
 if i==249:c.drawString(60,90,'lastpageprobe')
 c.showPage()
c.save();p=PdfReader(r/'large.pdf');assert len(p.pages)==250
(r/'structure.json').write_text(json.dumps({'protectedPages':2,'encryption':'AES-256','fixturePassword':'fixture-only-729','largePages':250,'largeBytes':(r/'large.pdf').stat().st_size,'protectedBytes':(r/'protected.pdf').stat().st_size},indent=2))
