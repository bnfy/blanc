from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-find-pdf');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-pdf-20261019';e.mkdir(parents=True,exist_ok=True)
assert json.loads((r/'results.json').read_text())['pass'];assert json.loads((r/'binary-unchanged.json').read_text())['unchanged'];assert json.loads((r/'preview.json').read_text())['status']==''
(r/'source-head.json').write_text(json.dumps({'testedHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productionCodeChanged':False},indent=2));(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes())
files=[p for p in r.iterdir() if p.is_file() and (p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.pdf','.png','.conf'] or p.name in ['guard.log','render.log'])]
m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 PDF and private lifecycle find checkpoint

An authored two-page text PDF contains three occurrences of needle. Chromium's real PDF viewer
loads it and native Find reports all three matches in regular and private windows. Regular next/
previous returns 1→2→1; no-match returns zero in both windows. PDF→HTML navigation resets the
capsule and HTML search succeeds. Private theme and cross-window rejection pass; private search
produces no regular-window result events. PDF fixture pages and the actual viewer capture were
visually inspected. This is a simple selectable-text PDF, not OCR, encrypted or form-document coverage.

Private A→B→back A→forward B preserves each document instance and reports persisted pageshow;
find resets at transitions and returns the expected three matches after forward restoration.
Removing a cross-origin iframe during an open find session leaves zero child matches on a fresh
query while parent text remains searchable. Closing the active searched tab resets the capsule;
private Recently Closed remains empty. Context disposal removes its targets and regular host
status remains empty. These are real bridge/engine checks, not physical key or pointer events.

No production code changes, preparation or compilation were needed. Build guard zero actions
(5.38s); native hashes unchanged from the expanded-find checkpoint, footprint remains 40 files /
96 hunks. Focused host lint passes. No repeat unit suite is claimed for this evidence-only change.
Disposable profile/server removed; original two preview tabs restored. Initial Poppler rendering
emitted Fontconfig configuration/cache warnings; a fixture-local config/cache rerender completed
and both pages were inspected. No system font configuration changed.

Remaining: PDF wrap/end-page selection, PDF reload/crash/plugin lifecycle, scanned/encrypted/forms,
cache eviction/ineligible pages, private subframe crashes/process sharing, IME/VoiceOver/physical
focus/display scale and full composed visual parity. No new Electron comparison was run. Native
input remains pending unlock; latency deferred; Electron diagnostic build unapproved/unstarted.
Visual plan item4 remains incomplete; previous F12/Task0 gates unchanged.
'''
(e/'README.md').write_text('# PDF and private lifecycle evidence\n\n'+text+f'\nAll {len(m)} archive members hash verified against `manifest.json`. Authored PDF and screenshots included; profiles and raw browser logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (w/'experiments/chromium-extension-spike'/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-pdf-20261019/`. No change to Task0 cold-build costs.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'''\n## October 19 PDF/private lifecycle progress

Simple two-page PDF find passes regular/private counts, regular next/previous, no-match and
PDF→HTML reset. Private forward BFCache restoration, iframe removal and active find-tab closure
pass bounded checks. Evidence: `evidence/ui138-find-pdf-20261019/`. No code change/build; guard
zero, native hashes unchanged, footprint remains 40 files /96 hunks. Broader PDF/cache/private/
accessibility cases remain gaps; native input pending unlock and visual item4 incomplete.
Latency deferred; Electron diagnostic build unapproved/unstarted; prior F12/Task0 unchanged.
\n'''+s[i:]);print(len(m),'verified members')
