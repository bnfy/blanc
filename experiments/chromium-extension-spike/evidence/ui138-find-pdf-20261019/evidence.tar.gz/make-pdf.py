from reportlab.pdfgen import canvas
from pathlib import Path
r=Path('/private/tmp/blanc-find-pdf');c=canvas.Canvas(str(r/'fixture.pdf'),pagesize=(612,792),invariant=1);c.setTitle('Blanc find fixture')
for n,text in [(1,'needle needle'),(2,'needle')]:
 c.setFont('Helvetica',22);c.drawString(72,720,'PDF search fixture');c.setFont('Helvetica',16);c.drawString(72,660,text);c.drawString(72,620,'Page '+str(n));c.showPage()
c.save()
