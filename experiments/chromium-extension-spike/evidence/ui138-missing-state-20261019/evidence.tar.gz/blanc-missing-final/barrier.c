#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static int hookrename(const char*a,const char*b){int result=rename(a,b);const char*r=getenv("BLANC_SPACE_WRITE_BARRIER");char want[4096],arm[4096],marker[4096],msg[4600];if(!r||result)return result;snprintf(want,sizeof(want),"%s/chromium-profile/Default/BlancPrototypeSpaces.json.switch",r);snprintf(arm,sizeof(arm),"%s/arm",r);if(strcmp(b,want)||unlink(arm))return result;snprintf(marker,sizeof(marker),"%s/intent-written.json",r);int f=open(marker,O_CREAT|O_TRUNC|O_WRONLY,0600);int n=snprintf(msg,sizeof(msg),"{\"pid\":%d,\"path\":\"%s\",\"rename_result\":%d}",getpid(),b,result);if(f>=0){syscall(SYS_write,f,msg,n);close(f);}time_t end=time(NULL)+30;while(time(NULL)<end)usleep(10000);return result;}
__attribute__((used,section("__DATA,__interpose")))static struct{const void*a;const void*b;}i={(void*)hookrename,(void*)rename};
