from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image,ImageDraw
from pypdf import PdfReader
from pathlib import Path
import json
r=Path('/private/tmp/blanc-find-complex');c=canvas.Canvas(str(r/'fixture.pdf'))
c.setFont('Helvetica',16);c.drawString(60,780,'Complex find fixture - columns');c.setFont('Helvetica',12)
c.drawString(60,700,'columnprobe left');c.drawString(320,700,'columnprobe right');c.showPage()
c.setFont('Helvetica',16);c.drawString(60,780,'Rotated text');c.saveState();c.translate(180,300);c.rotate(90);c.drawString(0,0,'rotateprobe');c.restoreState();c.showPage()
im=Image.new('RGB',(800,300),'white');ImageDraw.Draw(im).text((40,100),'rasterprobe',fill='black',font_size=52);im.save(r/'raster.png');c.drawImage(ImageReader(im),60,450,width=480,height=180);c.showPage()
c.setFont('Helvetica',16);c.drawString(60,780,'Interactive form');c.setFont('Helvetica',12);c.drawString(60,710,'formlabelprobe');c.acroForm.textfield(name='sample',value='fieldvalueprobe',x=60,y=650,width=300,height=30);c.showPage();c.save()
p=PdfReader(r/'fixture.pdf');assert len(p.pages)==4;assert p.get_fields()['sample']['/V']=='fieldvalueprobe';assert 'rasterprobe' not in (p.pages[2].extract_text() or '')
(r/'structure.json').write_text(json.dumps({'pages':4,'pageText':[x.extract_text() for x in p.pages],'formValue':p.get_fields()['sample']['/V'],'widgets':len(p.pages[3]['/Annots'])},indent=2))
