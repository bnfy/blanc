from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/private/tmp/blanc-find-complex');w=Path('/private/tmp/blanc-chromium157-work');e=w/'experiments/chromium-extension-spike/evidence/ui138-find-complex-20261019'
assert json.loads((r/'results.json').read_text())['pass']
assert json.loads((r/'cleanup.json').read_text())['status']==''
assert json.loads((r/'binary-hashes.json').read_text())==json.loads(Path('/private/tmp/blanc-find-plugin-fix/binary-hashes.json').read_text())
(r/'source-head.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productionCodeChanged':False,'binaryUnchanged':True},indent=2))
(r/'cdp.mjs').write_bytes(Path('/private/tmp/blanc-cdp.mjs').read_bytes());e.mkdir(parents=True,exist_ok=True)
files=[p for p in r.iterdir() if p.is_file() and(p.suffix in ['.mjs','.cjs','.py','.json','.jsonl','.pdf','.png'] or p.name=='guard.log')]
m={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(e/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
with tarfile.open(e/'evidence.tar.gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
text='''## October 19 complex PDF/concurrent crash checkpoint

An authored four-page PDF adds two-column text, 90-degree rotated text, an image-only page and
an interactive AcroForm field. Structure checks confirm four pages, field value and widget; all
four Poppler page renders were visually inspected. Regular/private native Find each returns two
column matches, one rotated match and one form-label match. The actual form-field value and
image-only text both return final zero matches in both profiles: these are observed limitations,
not OCR or full form-content acceptance. No password-protected PDF check is claimed.

With regular and private PDFs open together, exactly two owned --pdf-renderer processes are
selected from the isolated profile and SIGKILL is sent in one host-clock-millisecond batch. Both
processes exit; both outer-page markers survive; each capsule closes. Reopened no-reload search
completes with zero matches, and reload independently restores two column/one rotated matches.
The kill calls share a batch, not a claim of simultaneous OS scheduling or exhaustive concurrent
crash coverage. Private context disposal succeeds. No main-plus-plugin or browser/GPU failure.

No production changes or compilation; guard zero actions (3.53s), binary hashes match the PDF
reset fix. Footprint remains40 files/96 hunks (not re-enumerated for evidence-only work). Disposable
profile/server removed; preview original tabs/empty status verified without restart. No new unit
suite, Electron comparison, physical input or performance claim. The source PDF, structural checks,
rendered pages, runtime observations and harness are archived.

Remaining: encrypted/password documents, XFA and form edits, OCR, embedded fonts/large PDFs,
main-plus-plugin and wider concurrent failure schedules, cache/process sharing/accessibility/full
visual coverage. Native input pending unlock; latency deferred; Electron diagnostic build remains
unapproved/unstarted. Plan item4 and previous F12/Task0 gates unchanged.
'''
(e/'README.md').write_text(text+f'\n{len(m)} archive members hash verified; profiles/raw browser logs excluded.\n')
for n in ['ui-refresh-20261018.md','results.md','rebase-ledger.md']:
 with (w/'experiments/chromium-extension-spike'/n).open('a') as f:f.write('\n'+text+'\nEvidence: `evidence/ui138-find-complex-20261019/`. No Task0 cold-cost change.\n')
p=w/'experiments/chromium-extension-spike/tranche2-request.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+text+'\nEvidence: `evidence/ui138-find-complex-20261019/`.\n'+s[i:]);print(len(m),'verified archive members')
