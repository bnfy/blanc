from pathlib import Path
import hashlib,json
r=Path('/private/tmp/blanc-find-session');base=Path('/Users/anthonyjloria/Projects/BlancChromium157/src/out/BlancPrototype')
files=[base/'Blanc Prototype.app/Contents/MacOS/Blanc Prototype',base/'Blanc Prototype.app/Contents/Frameworks/Blanc Prototype Framework.framework/Versions/157.0.8103.6/Blanc Prototype Framework']
(r/'binary-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
