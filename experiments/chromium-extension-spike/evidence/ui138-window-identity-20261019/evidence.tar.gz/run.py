import os,subprocess,pathlib
r=pathlib.Path('/private/tmp/blanc-window-identity')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
run('start','node',str(r/'start.mjs'));run('seed','node',str(r/'check.mjs'),'seed');run('stop','node',str(r/'stop.mjs'))
run('restore-injected','node',str(r/'launch-injected.mjs'),env={**os.environ,'RESTORE':'1'});run('crash','node',str(r/'check.mjs'),'crash')
run('restore','node',str(r/'launch.mjs'),env={**os.environ,'RESTORE':'1'});run('recover','node',str(r/'check.mjs'),'recover')
