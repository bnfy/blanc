from pathlib import Path
import subprocess,sys
r=Path('/private/tmp/blanc-save-rotation-fixed');failure=None
def call(name,args):subprocess.run(['python3',str(r/'invoke.py'),name,*args],check=True)
try:subprocess.run(['python3',str(r/'run.py')],check=True)
except Exception as e:failure=e
finally:
 call('diagnostic-remove',['python3',str(r/'diagnostic.py'),'restore'])
 call('normal-build',['node','experiments/chromium-extension-spike/build.mjs','/Users/anthonyjloria/Projects/BlancChromium157/src','--build'])
if failure:raise failure
subprocess.run(['python3',str(r/'normal-run.py')],check=True)
call('final-guard',['node','experiments/chromium-extension-spike/build.mjs','/Users/anthonyjloria/Projects/BlancChromium157/src'])
