import fs from 'node:fs';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const r='/private/tmp/blanc-save-rotation-fixed',mode=process.argv[2],cs=[],p={mode,encrypted:!!process.env.ACK_ENCRYPTED},disk=r+'/chromium-profile/Default/BlancPrototypeSpaces.json';
const wait=async(fn,test)=>{for(let i=0;i<240;i++){const x=await fn().catch(()=>null);if(test(x))return x;await pause(50);}throw Error('timeout');};
const api=(h,m,...a)=>h.eval(`BlancPrototypeHost.api.${m}(...${JSON.stringify(a)})`);
const hosts=async()=>{const all=[];for(const t of(await fetch('http://127.0.0.1:9258/json/list').then(x=>x.json())).filter(t=>t.url.includes('host.html'))){const h=await connect(t);cs.push(h);const s=await api(h,'getAllTabs').catch(()=>null);if(s)all.push({h,s});}p.lastHosts=all.map(x=>({identity:x.s.spaceWindowIdentity,tabs:x.s.tabs.map(t=>({url:t.url,loading:t.isLoading}))}));return all;};
const diagnostic=(h,op)=>h.eval(`new Promise((resolve,reject)=>{const old=window.blancPrototypeReply,id='rotation-diagnostic';window.blancPrototypeReply=(i,ok,v)=>{if(i===id){window.blancPrototypeReply=old;ok?resolve(v):reject(Error(v));}else old(i,ok,v);};chrome.send('blancPrototype',[id,'saveAckDiagnostic',[${JSON.stringify(op)}]]);})`);
const files=()=>Object.fromEntries(['Sessions','Sessions_Encrypted'].map(d=>[d,fs.existsSync(r+'/chromium-profile/Default/'+d)?fs.readdirSync(r+'/chromium-profile/Default/'+d).filter(n=>n.startsWith('Session_')).map(n=>({name:n,bytes:fs.statSync(r+'/chromium-profile/Default/'+d+'/'+n).size})):[]]));
try {
const seed=JSON.parse(fs.readFileSync(r+'/seed.json'));let hs=await wait(hosts,x=>x?.length===2),source=hs.find(x=>x.s.spaceWindowIdentity===seed.source.spaceWindowIdentity),decoy=hs.find(x=>x.s.spaceWindowIdentity===seed.decoy.spaceWindowIdentity);assert(source&&decoy);
p.marker=await wait(async()=>JSON.parse(fs.readFileSync(r+'/marker.json')),Boolean);assert.equal(p.marker.pid,Number(fs.readFileSync(r+'/chromium.pid')));assert.equal(fs.statSync(p.marker.path).size,0);p.before=source.s;p.filesBefore=files();let storeBefore;
await api(source.h,'previewSpaceSave','A');storeBefore=fs.readFileSync(disk,'utf8');
if(mode.endsWith('-before'))p.operationResult=await diagnostic(source.h,mode.split('-')[0]);
await source.h.eval("globalThis.ackOutcome='pending';BlancPrototypeHost.api.previewSpaceOpen('B').then(()=>ackOutcome='success',e=>ackOutcome=String(e));true");await pause(250);assert.equal(await source.h.eval('ackOutcome'),'pending');assert(!fs.existsSync(disk+'.switch'));
if(mode==='identity')p.newIdentity=await diagnostic(source.h,'replace');
else if(mode.endsWith('-during'))p.operationResult=await diagnostic(source.h,mode.split('-')[0]);
if(mode==='identity')assert.notEqual(p.newIdentity,p.before.spaceWindowIdentity);
fs.writeFileSync(r+'/release','1');p.outcome=await wait(()=>source.h.eval('ackOutcome'),x=>x!=='pending');
if(mode==='identity'){
 assert(p.outcome.includes('source changed'));p.afterReject=await wait(()=>api(source.h,'getAllTabs'),s=>s?.spaceWindowIdentity===p.newIdentity);assert.deepEqual(p.afterReject.tabs.map(t=>t.url),p.before.tabs.map(t=>t.url));assert(!fs.existsSync(disk+'.switch'));assert.equal(fs.readFileSync(disk,'utf8'),storeBefore);assert.equal(p.afterReject.spaceWindowIdentity,p.newIdentity);
 await api(source.h,'previewSpaceSave','A');await api(source.h,'previewSpaceOpen','B');
}else assert.equal(p.outcome,'success');
p.after=await wait(()=>api(source.h,'getAllTabs'),s=>s?.spaceName==='B'&&!s.tabs.some(t=>t.isLoading)&&!fs.existsSync(disk+'.switch'));p.decoy=await api(decoy.h,'getAllTabs');assert.deepEqual(p.decoy.tabs.map(t=>t.url),seed.decoy.tabs.map(t=>t.url));
await pause(4000);p.filesAfter=files();if(mode.startsWith('rotate'))assert(Object.keys(p.filesBefore).some(d=>p.filesAfter[d].some(n=>!p.filesBefore[d].some(o=>o.name===n.name))));
const pid=Number(fs.readFileSync(r+'/chromium.pid'));assert(execFileSync('ps',['-p',String(pid),'-o','command='],{encoding:'utf8'}).includes('--user-data-dir='+r+'/chromium-profile'));p.crashPid=pid;process.kill(pid,'SIGKILL');await pause(700);execFileSync(process.execPath,[r+'/launch.mjs'],{env:{...process.env,RESTORE:'1'}});
hs=await wait(hosts,x=>x?.length===2&&x.every(y=>!y.s.tabs.some(t=>t.isLoading)));p.restored=hs.map(x=>x.s);const restoredSource=hs.find(x=>x.s.spaceWindowIdentity===p.after.spaceWindowIdentity);assert(restoredSource);assert.deepEqual(restoredSource.s.tabs.map(t=>t.url),p.after.tabs.map(t=>t.url));const restoredDecoy=hs.find(x=>x.s.spaceWindowIdentity===seed.decoy.spaceWindowIdentity);assert(restoredDecoy);assert.deepEqual(restoredDecoy.s.tabs.map(t=>t.url),seed.decoy.tabs.map(t=>t.url));assert(!fs.existsSync(disk+'.switch'));p.pass=true;
}catch(e){p.pass=false;p.error=String(e);p.stack=e.stack;fs.writeFileSync(r+'/release','1');}finally{cs.forEach(c=>c.close());fs.writeFileSync(r+'/'+(p.encrypted?'encrypted-':'clear-')+mode+'.json',JSON.stringify(p,null,2));console.log({mode,pass:p.pass,error:p.error});}if(!p.pass)process.exitCode=1;
