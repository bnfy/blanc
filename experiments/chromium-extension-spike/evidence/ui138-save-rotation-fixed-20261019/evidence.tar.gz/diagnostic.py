from pathlib import Path
import sys,hashlib,json,difflib
r=Path('/private/tmp/blanc-save-rotation-fixed');p=Path('/Users/anthonyjloria/Projects/BlancChromium157/src/chrome/browser/ui/blanc_prototype_ui.cc');b=r/'native.before.cc'
if sys.argv[1]=='restore':
 p.write_bytes(b.read_bytes());(r/'source-restored.json').write_text(json.dumps({'equal':p.read_bytes()==b.read_bytes(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}));sys.exit()
s=p.read_text();b.write_text(s)
a='    const base::ListValue& args = message[2].GetList();\n'
c=a+'''    // Temporary test control, exact disposable profile only.
    if (method == "saveAckDiagnostic" &&
        profile->GetPath().value() == "/private/tmp/blanc-save-rotation-fixed/chromium-profile/Default" &&
        args.size() == 1 && args[0].is_string()) {
      auto* service = SessionServiceFactory::GetForProfile(profile);
      const auto operation = args[0].GetString();
      if (operation == "replace") {
        RestoreWindowIdentity(browser, {{kWindowIdentityKey,
            base::Uuid::GenerateRandomV4().AsLowercaseString()}});
      } else if (operation == "reset") {
        service->ResetFromCurrentBrowsers();
      } else if (operation == "rotate") {
        service->MoveCurrentSessionToLastSession();
      } else { reply(false, base::Value("unknown diagnostic")); return; }
      reply(true, base::Value(WindowIdentity(browser))); return;
    }
'''
assert s.count(a)==1;s=s.replace(a,c);p.write_text(s)
(r/'diagnostic.patch').write_text(''.join(difflib.unified_diff(b.read_text().splitlines(True),s.splitlines(True),fromfile='a/chrome/browser/ui/blanc_prototype_ui.cc',tofile='b/chrome/browser/ui/blanc_prototype_ui.cc')))
