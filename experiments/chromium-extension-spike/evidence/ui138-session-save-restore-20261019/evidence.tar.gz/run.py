import os,subprocess,pathlib,json
r=pathlib.Path('/private/tmp/blanc-session-boundaries')
def run(n,*a,env=None):subprocess.run(['python3',str(r/'invoke.py'),n,*a],check=True,env=env)
(r/'arm').write_text('1')
run('write-start','node',str(r/'start.mjs'),env={**os.environ,'INJECT':'1','SESSION_MODE':'write'});run('write-seed','node',str(r/'check.mjs'),'seed');run('write-proof','node',str(r/'probe.mjs'),'write');run('write-cleanup','node',str(r/'cleanup.mjs'))
for n in ['arm','release','marker.json']:(r/n).unlink(missing_ok=True)
run('read-start','node',str(r/'start.mjs'));run('read-seed','node',str(r/'check.mjs'),'seed');run('read-stop','node',str(r/'stop.mjs'))
seed=json.loads((r/'seed.json').read_text());store=seed['store'];p=r/'chromium-profile/Default/BlancPrototypeSpaces.json.switch';p.write_text(json.dumps(dict(version=2,id='test-late-restore',source_name='A',source_window=seed['source']['spaceWindowIdentity'],source=store['items']['A'],destination=store['items']['B'])))
(r/'arm').write_text('1');run('read-restart','node',str(r/'launch-injected.mjs'),env={**os.environ,'RESTORE':'1','SESSION_MODE':'read'});run('read-proof','node',str(r/'probe.mjs'),'read');run('read-cleanup','node',str(r/'cleanup.mjs'))
