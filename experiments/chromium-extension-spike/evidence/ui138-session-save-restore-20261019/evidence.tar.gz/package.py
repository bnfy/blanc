from pathlib import Path
import json,hashlib,tarfile,io,gzip
r=Path('/private/tmp/blanc-session-boundaries');b=Path('experiments/chromium-extension-spike');d=b/'evidence/ui138-session-save-restore-20261019';d.mkdir(parents=True,exist_ok=True)
w=json.loads((r/'write.json').read_text());q=json.loads((r/'read.json').read_text());assert w['pass'] and q['pass'] and w['switchAcceptedBeforeSessionWrite'] and w['sessionFileBytes']==0
assert 'Dry-run scheduled actions: 0' in (r/'guard.log').read_text()
s='''## Metadata save ordering and delayed session restore — October 19, 2026

**Save acknowledgement remains an observed failure/gap, not a pass.** The disposable browser's first Session-file write (8-byte header) was held before the syscall. UI initialization, distinct window UUID generation, saving A/B and a complete Spaces switch to B all succeeded while that Session file remained zero bytes. The hook was then released and the disposable browser shut down normally. This directly proves that queued identity registration is not a prerequisite completion acknowledgement for switching. The experiment did not simulate power loss or claim a lost-data recovery outcome; it identifies the missing ordering gate. The harness's `pass` means it reproduced this observation, not that the feature meets durability acceptance.

Source audit: `components/sessions/core/command_storage_manager.cc` Save() invalidates its timer, posts AppendCommands to a sequenced backend and provides only an error callback. HasPendingSave() reflects timer state, not completed IO. Clear/encrypted backends have staged selection rules and delayed encryptor availability. `command_storage_backend.cc` AppendCommandsToFile returns write status internally; no success acknowledgement is propagated through the inspected SessionService path. A delay, an empty pending queue, or AddWindowExtraData returning cannot be treated as durable completion.

**One delayed-restore schedule passes.** With two previously saved windows and a valid synthetic v2 intent, a real Session-file read was held on the backend. A third unrelated regular window was opened via CDP while the read remained held. Its snapshot had no recovery mutation/error and the journal remained. After release, the two real session windows restored; the UUID-matching source recovered, both original saved records and the original decoy remained unchanged, the new third window remained, and the journal cleared. Nonowner windows retained the already-known status error after recovery; this is not a full overlapping/late-duplicate restore qualification.

No product source change or native build. A scoped diagnostic dylib intercepted only owned disposable Session paths; public mock keychain, no real profile/keychain access. Zero-action final guard. Prior measured44files/107hunks unchanged, not re-enumerated. Owned profiles/server removed; retained preview untouched, host unavailable so original tabs not reverified. Evidence includes actual syscall paths/PIDs, before/after snapshots and invocation records.

Required next implementation: carry an identity-generation-specific successful save result from the authoritative session backend to the browser owner; define write-vs-flush guarantees explicitly; refuse/defer destructive switching until that generation is acknowledged; keep errors, encryptor delay and owner destruction fail-closed. This needs a concrete upstream patch inventory before changing the44/120 ceiling; no budget increase or acknowledgement implementation is claimed here. Also still open: late duplicate restoration, multiple overlapping restorer lifetimes, save failures, rebuild/rotation ordering and power-loss durability. Native input pending, latency deferred, Electron diagnostic build unapproved. Plan remains in progress; cold-build accounting and other Task0/F12 gates unchanged.

Evidence: `evidence/ui138-session-save-restore-20261019/`.
'''
(d/'README.md').write_text(s);(d/'results.json').write_text(json.dumps({'metadata_save_acknowledgement':{'status':'gap reproduced','switch_accepted_before_first_session_write':True,'held_file_bytes':0},'delayed_restore_with_new_window':{'status':'bounded pass'}},indent=2)+'\n')
for n in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 with(b/n).open('a')as f:f.write('\n'+s)
ms=[]
with(d/'evidence.tar.gz').open('wb')as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for p in sorted(r.iterdir()):
    if not p.is_file() or p.suffix=='.dylib':continue
    data=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data));ms.append(dict(path=p.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(d/'evidence.tar.gz')as t:
 for m in ms:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
(d/'manifest.json').write_text(json.dumps(ms,indent=2)+'\n');(d/'invocations.jsonl').write_bytes((r/'invocations.jsonl').read_bytes());print(len(ms),'verified members')
