from pathlib import Path
for mode in ['clear','encrypted']:
 for case in ['failure','crash','release']:
  old=Path(f'/private/tmp/blanc-initial-{mode}-{case}');new=Path(f'/private/tmp/blanc-retry-{mode}-{case}');new.mkdir()
  for p in old.iterdir():
   if p.suffix in ['.mjs','.cjs','.py','.c']:(new/p.name).write_text(p.read_text().replace(str(old),str(new)))
  p=new/'scenario.mjs';s=p.read_text();start=s.index("if(kind==='failure'){");end=s.index("\nif(kind==='release')",start)
  s=s[:start]+'''if(kind==='failure'){
await pause(3500);p.persistentFailure=await late();assert.equal(p.persistentFailure.initialWindowSaved,false);assert.equal(p.persistentFailure.initialWindowSaveFailed,true);
p.events=fs.readFileSync(r+'/events.jsonl','utf8').trim().split('\\n').map(JSON.parse);assert(p.events.filter(x=>x.op==='fsync').length>=2);assert(p.events.filter(x=>x.op==='fsync').length<=6);
fs.unlinkSync(r+'/arm');p.afterFaultRemoved=await wait(late,s=>s?.initialWindowSaved);assert.equal(p.afterFaultRemoved.initialWindowSaveFailed,false);p.automaticRetryObserved=true;
}'''+s[end:];s=s.replace("if(kind==='release')assert(p.newWindowRestored)","if(kind!=='crash')assert(p.newWindowRestored)");p.write_text(s)
