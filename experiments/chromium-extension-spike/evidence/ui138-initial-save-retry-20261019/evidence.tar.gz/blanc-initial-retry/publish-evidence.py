from pathlib import Path
import json,hashlib,tarfile,io
repo=Path('/private/tmp/blanc-chromium157-work');base=repo/'experiments/chromium-extension-spike';out=base/'evidence/ui138-initial-save-retry-20261019';out.mkdir(exist_ok=True)
roots=[Path('/private/tmp/blanc-retry-'+m+'-'+c) for m in ['clear','encrypted'] for c in ['failure','crash','release']]+[Path('/private/tmp/blanc-initial-retry')]
rows=[];data=[]
for r in roots:
 assert not (r/'chromium-profile').exists()
 if (r/'result.json').exists():assert json.loads((r/'result.json').read_text())['pass']
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ['.mjs','.cjs','.py','.c','.json','.jsonl','.log','.txt']:
   b=p.read_bytes();name=r.name+'/'+p.name;data.append((name,b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
b=Path('/private/tmp/blanc-cdp.mjs').read_bytes();data.append(('blanc-cdp.mjs',b));rows.append({'path':'blanc-cdp.mjs','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for n,b in data:
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(out/'evidence.tar.gz') as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
text='''### October 19 — Automatic retry of initial-window save failures

Failed initial-window Session save/flush attempts now retry from the existing host refresh with exponential delays of1,2,4,8,16 and then30 seconds. The cap bounds retry frequency, not the number of attempts. Only one save may be in flight. Each attempt rechecks regular-profile, restore, settled-navigation and capture eligibility and re-enqueues current same-profile window/tab identities. A weak browser callback and unchanged capture remain required before acknowledgement. The failure flag stays visible until a successful acknowledgement; successful windows stop retrying. Private/restored-window exclusions remain unchanged.

Six normal-binary disposable schedules pass in explicit clear and encrypted modes. Persistent injected flush EIO remains failed/not saved through repeated attempts (three fsync failures observed in each bounded fault window). Removing the fault automatically retries to saved/not failed without an explicit Space command. SIGKILL after that acknowledgement restores the new UUID plus the saved source and decoy UUIDs/URLs. Held-write regressions still report neither success nor failure while pending: killing before the syscall loses the unacknowledged new window, while releasing the write acknowledges and restores it. Pre-flush crash protection is not claimed.

Five focused capture/identity tests pass. One guarded incremental build39.83s wrapper/34.08s Siso, six steps. Fresh footprint49 files/117 hunks within49/120, no new upstream files/hunks. Final guard zero actions/5.11s. No cold build or Task0 benchmark change. All owned profiles/servers removed; preview untouched, host unavailable and tabs not reverified. Profiles were primed; disposable restart alone bypasses the crash bubble. Native input pending, latency deferred, Electron diagnostic build unapproved/unstarted. Long-duration30-second backoff, retry-specific owner destruction or changed-capture schedules, actual provider/hardware failures, first-ever profile persistence and unpersisted recent edits remain unqualified.
'''
(out/'README.md').write_text('# Initial-window automatic retry evidence\n\n'+text+'\nArchive members: '+str(len(rows))+'. SHA-256: `'+hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()+'`.\n')
for name in ['tranche2-request.md','spaces-automatic-recovery.md','rebase-ledger.md','results.md','ui-refresh-20261018.md']:
 p=base/name;p.write_text(p.read_text()+'\n\n'+text+'\nEvidence: [initial save boundaries](evidence/ui138-initial-save-retry-20261019/README.md).\n')
print(len(rows),hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest())
