import subprocess,time,sys,json,datetime,pathlib
root=pathlib.Path('/private/tmp/blanc-initial-retry');name=sys.argv[1];args=sys.argv[2:];t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
with (root/'invocations.jsonl').open('a') as f:f.write(json.dumps(dict(name=name,argv=args,started=start,seconds=time.monotonic()-t,exit_code=r.returncode))+'\n')
print(name,r.returncode,round(time.monotonic()-t,2));print((root/(name+'.log')).read_text()[-7000:]);sys.exit(r.returncode)
