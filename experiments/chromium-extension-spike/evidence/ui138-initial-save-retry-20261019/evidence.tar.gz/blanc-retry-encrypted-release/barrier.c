#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static void hold(int fd,const char*mode,size_t count){const char*r=getenv("BLANC_SPACE_WRITE_BARRIER"),*wantmode=getenv("SESSION_MODE");char p[4096],prefix[4096],arm[4096],release[4096],marker[4096],msg[4600];if(!r||!wantmode||strcmp(mode,wantmode)||fcntl(fd,F_GETPATH,p))return;snprintf(prefix,sizeof(prefix),"%s/chromium-profile/Default/Sessions_Encrypted/",r);snprintf(arm,sizeof(arm),"%s/arm",r);if(strncmp(p,prefix,strlen(prefix))||!strstr(p,"/Session_")||unlink(arm))return;snprintf(marker,sizeof(marker),"%s/marker.json",r);snprintf(release,sizeof(release),"%s/release",r);int out=open(marker,O_CREAT|O_WRONLY|O_TRUNC,0600);int n=snprintf(msg,sizeof(msg),"{\"pid\":%d,\"path\":\"%s\",\"mode\":\"%s\",\"count\":%zu}",getpid(),p,mode,count);if(out>=0){syscall(SYS_write,out,msg,n);close(out);}time_t end=time(NULL)+60;while(access(release,F_OK)&&time(NULL)<end)usleep(10000);}
static ssize_t w(int f,const void*b,size_t n){hold(f,"write",n);return syscall(SYS_write,f,b,n);}
static ssize_t rd(int f,void*b,size_t n){hold(f,"read",n);return syscall(SYS_read,f,b,n);}
__attribute__((used,section("__DATA,__interpose")))static struct{const void*a;const void*b;}i[]={{(void*)w,(void*)write},{(void*)rd,(void*)read}};
