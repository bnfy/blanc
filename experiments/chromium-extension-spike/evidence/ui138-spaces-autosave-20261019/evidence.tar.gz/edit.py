from pathlib import Path
p=Path('experiments/chromium-extension-spike/native/blanc_prototype_ui.cc');s=p.read_text().replace('#include "chrome/browser/ui/browser_commands.h"','#include "chrome/browser/ui/browser_commands.h"\n#include "chrome/app/chrome_command_ids.h"')
s=s.replace('  std::optional<base::DictValue> space_saved;','''  std::optional<base::DictValue> space_saved;
  std::optional<base::DictValue> space_candidate;
  base::TimeTicks space_candidate_at;
  std::string space_error;''')
s=s.replace('  if (base::PathExists(path)) {\n    std::string bytes;', '''  const bool recover = method == "previewSpaceRecover";
  const auto load_path = recover ? path.AddExtensionASCII("backup") : path;
  if (recover && !base::PathExists(load_path))
    return base::DictValue().Set("error", "No previous space checkpoint exists.");
  if (base::PathExists(load_path)) {
    std::string bytes;''').replace('base::ReadFileToStringWithMaxSize(path, &bytes, 4 * 1024 * 1024)', 'base::ReadFileToStringWithMaxSize(load_path, &bytes, 4 * 1024 * 1024)')
s=s.replace('    items->Set(name, std::move(capture));','''    // Preserve the validated previous generation before replacing the main
    // file. Recovery is explicit; corrupt data is never silently overwritten.
    auto previous = base::WriteJson(store);
    if (!previous || !base::ImportantFileWriter::WriteFileAtomically(path.AddExtensionASCII("backup"), *previous))
      return base::DictValue().Set("error", "Previous space checkpoint write failed.");
    items->Set(name, std::move(capture));''')
s=s.replace('  if (method == "previewSpaceOpen") {','''  if (recover) {
    auto json = base::WriteJson(store);
    if (!json || !base::ImportantFileWriter::WriteFileAtomically(path, *json))
      return base::DictValue().Set("error", "Space recovery write failed.");
  }
  if (method == "previewSpaceOpen") {''',1)
s=s.replace('.Set("extensionsWidth", extension_width)', '''.Set("spaceName", owner->space_name)
      .Set("spaceAutosaveError", owner->space_error)
      .Set("spaceBusy", owner->space_busy)
      .Set("extensionsWidth", extension_width)''')
needle='  void SpaceReady(std::string id, std::string method, std::string name,'
methods='''  void AutosaveReady(base::DictValue capture, base::DictValue result) {
    auto* owner = GetOwner(web_ui()->GetWebContents());
    if (!owner) return;
    owner->space_busy = false;
    if (const auto* error = result.FindString("error")) owner->space_error = *error;
    else owner->space_saved = std::move(capture);
  }
  void MaybeAutosave(Owner* owner) {
    auto* profile = owner->browser->GetProfile();
    if (profile->IsOffTheRecord() || owner->space_name.empty() || owner->space_busy || !owner->space_error.empty()) return;
    for (auto* other : Owner::Live())
      if (other != owner && other->browser->GetProfile() == profile && other->space_busy) return;
    auto capture = CaptureNativeSpace(owner->browser);
    if (!capture) { owner->space_candidate.reset(); return; }
    if (owner->space_saved && *capture == *owner->space_saved) return;
    if (!owner->space_candidate || *capture != *owner->space_candidate) {
      owner->space_candidate = capture->Clone();
      owner->space_candidate_at = base::TimeTicks::Now();
      return;
    }
    if (base::TimeTicks::Now() - owner->space_candidate_at < base::Seconds(1)) return;
    owner->space_busy = true;
    SpaceRunner()->PostTaskAndReplyWithResult(FROM_HERE,
        base::BindOnce(&SpaceDisk, profile->GetPath().AppendASCII("BlancPrototypeSpaces.json"),
            "previewSpaceSave", owner->space_name, capture->Clone()),
        base::BindOnce(&Handler::AutosaveReady, weak_factory_.GetWeakPtr(), std::move(*capture)));
  }
'''
s=s.replace(needle,methods+needle)
s=s.replace('    if (method == "previewSpaceList") { Reply(id, true, base::Value(std::move(result))); return; }','''    if (method == "previewSpaceList" || method == "previewSpaceRecover") {
      if (method == "previewSpaceRecover") {
        for (auto* live : Owner::Live()) if (live->browser->GetProfile() == browser->GetProfile()) {
          live->space_name.clear(); live->space_saved.reset(); live->space_candidate.reset(); live->space_error.clear();
        }
      }
      Reply(id, true, base::Value(std::move(result))); return;
    }''')
s=s.replace('      owner->space_name = name;\n      owner->space_saved', '      owner->space_error.clear();\n      owner->space_name = name;\n      owner->space_saved')
s=s.replace('method == "previewSpaceOpen" || method == "previewSpaceList") {', 'method == "previewSpaceOpen" || method == "previewSpaceList" || method == "previewSpaceRecover") {')
s=s.replace('const bool list = method == "previewSpaceList";', 'const bool list = method == "previewSpaceList" || method == "previewSpaceRecover";')
s=s.replace('    if (method == "snapshot") {\n      reply', '    if (method == "snapshot") {\n      MaybeAutosave(owner);\n      reply')
needle='    // Native split foundation only:'
s=s.replace(needle,'''    if (method == "previewPageCommand" && args.size() == 1 && args[0].is_string()) {
      const std::map<std::string, int> commands = {
        {"hardReload", IDC_RELOAD_BYPASSING_CACHE}, {"close", IDC_CLOSE_TAB},
        {"zoomIn", IDC_ZOOM_PLUS}, {"zoomOut", IDC_ZOOM_MINUS},
        {"zoomReset", IDC_ZOOM_NORMAL}, {"print", IDC_PRINT}};
      const auto command = commands.find(args[0].GetString());
      if (command == commands.end()) { reply(false, base::Value("Unknown page command.")); return; }
      // Browser commands already target the focused native WebContents. Do
      // not rewrite explicit row close actions or main-scoped navigation IDs.
      reply(true, base::Value(chrome::ExecuteCommand(browser, command->second)));
      return;
    }
'''+needle)
p.write_text(s)
p=Path('experiments/chromium-extension-spike/prototype/host.js');s=p.read_text().replace("    previewSpaceSave: name", "    previewPageCommand: command => request('previewPageCommand', [command]),\n    previewSpaceRecover: () => request('previewSpaceRecover'),\n    previewSpaceSave: name");p.write_text(s)
