import fs from 'node:fs';import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const ts=await fetch('http://127.0.0.1:9250/json/list').then(r=>r.json());const h=await connect(ts.find(t=>t.url.includes('host.html')));const call=(m,...a)=>h.eval(`BlancPrototypeHost.api[${JSON.stringify(m)}](...${JSON.stringify(a)})`);const snap=async()=>{await h.eval('BlancPrototypeHost.refresh()');await pause(200);return call('getAllTabs')};
for(const name of ['Pinned one','Pinned two','Alpha','Beta','Gamma','Delta']){await call('createTab','http://127.0.0.1:9261/'+name.replaceAll(' ','-'));await pause(150);}
let s=await snap();for(const t of s.tabs.filter(t=>t.url.includes('Pinned')))await call('toggleTabPinned',t.id);
for(const t of s.tabs.filter(t=>/Alpha|Beta/.test(t.url)))await call('groupTabByName',t.id,'Research');
for(const t of s.tabs.filter(t=>/Gamma/.test(t.url)))await call('groupTabByName',t.id,'Reading');
await call('setTabLayout','vertical');await call('setVerticalTabsWidth',248);
const p=await connect(ts.find(t=>t.type==='page'));const w=await p.send('Browser.getWindowForTarget');await p.send('Browser.setWindowBounds',{windowId:w.windowId,bounds:{width:1200,height:900}});p.close();
fs.writeFileSync('/private/tmp/blanc-ui138-accept/initial.json',JSON.stringify(await snap(),null,2));h.close();
