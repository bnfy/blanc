import fs from 'node:fs';import {spawn} from 'node:child_process';
const root='/private/tmp/blanc-ui138-accept';const c=JSON.parse(fs.readFileSync('/private/tmp/blanc-prerender-followup-build/config.json'));
const log=fs.openSync(root+'/chromium.log','a');const p=spawn(c.chromium,[`--user-data-dir=${root}/chromium-profile`,'--remote-debugging-port=9250',`--blanc-prototype-assets=${c.ui}`,'--no-first-run','--no-default-browser-check','--use-mock-keychain','--restore-last-session'],{detached:true,stdio:['ignore',log,log]});p.unref();fs.writeFileSync(root+'/chromium.pid',String(p.pid));
