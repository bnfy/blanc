import fs from 'node:fs';import {connect,pause} from '/private/tmp/blanc-cdp.mjs';
const root='/private/tmp/blanc-ui138-accept';const list=p=>fetch(`http://127.0.0.1:${p}/json/list`).then(r=>r.json());
const et=(await list(9252)).find(t=>t.url==='blanc-chrome://index/');const e=await connect(et);console.log('electron',await e.eval('(async()=>({state:await window.browserAPI.getAllTabs(),keys:Object.keys(window.browserAPI)}))()').catch(x=>String(x)));
e.close();
