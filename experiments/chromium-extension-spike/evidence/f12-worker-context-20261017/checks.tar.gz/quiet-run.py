import os,sys,json,time,signal,subprocess,datetime
from pathlib import Path
root=Path('/private/tmp/blanc-f12-worker-context')
state=root/'pause-state.json'
def identity(pid):
 p=subprocess.run(['ps','-p',str(pid),'-o','lstart=,comm='],capture_output=True,text=True)
 return p.stdout.strip() if p.returncode==0 else None
def restore():
 if not state.exists():return
 data=json.loads(state.read_text());events=[]
 for item in data['targets']:
  if item.get('paused') is False:
   events.append({'pid':item['pid'],'notPaused':True});continue
  if identity(item['pid'])==item['identity']:
   try:os.kill(item['pid'],signal.SIGCONT);events.append({'pid':item['pid'],'resumed':True})
   except ProcessLookupError:events.append({'pid':item['pid'],'exited':True})
   except PermissionError:events.append({'pid':item['pid'],'resumed':False,'reason':'signal-permission-denied; pause also denied'})
  else:events.append({'pid':item['pid'],'identityChangedOrExited':True})
 (root/('restore-watchdog.json' if '--watchdog' in sys.argv else 'restore.json')).write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'events':events},indent=2))
if '--watchdog' in sys.argv:
 time.sleep(1800);restore();sys.exit(0)
lines=subprocess.check_output(['ps','-axo','pid=,stat=,comm='],text=True).splitlines();targets=[]
for name in ['spotlightknowledged','logioptionsplus_updater']:
 found=[]
 for line in lines:
  fields=line.strip().split(None,2)
  if len(fields)==3 and os.path.basename(fields[2])==name:
   pid=int(fields[0]);assert 'T' not in fields[1], 'Already stopped; do not take ownership'
   found.append({'pid':pid,'identity':identity(pid),'name':name})
 assert len(found)<=1, 'Ambiguous process selection'
 targets+=found
state.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targets':targets},indent=2))
watchdog=None
try:
 watchdog=subprocess.Popen([sys.executable,__file__,'--watchdog'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
 for item in targets:
  assert identity(item['pid'])==item['identity']
  try:
   os.kill(item['pid'],signal.SIGSTOP);item['paused']=True
  except PermissionError:
   item['paused']=False;item['reason']='signal-permission-denied; passwordless sudo unavailable'
  state.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targets':targets},indent=2))
 print(json.dumps({'paused':targets,'watchdogPid':watchdog.pid}),flush=True)
 code=subprocess.call(sys.argv[1:])
finally:
 restore()
 if watchdog:watchdog.terminate();watchdog.wait()
sys.exit(code)
